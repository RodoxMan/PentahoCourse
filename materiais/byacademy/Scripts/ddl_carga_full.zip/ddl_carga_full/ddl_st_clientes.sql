
CREATE TABLE st_clientes (
	cd_cliente integer,
	nome_cliente varchar(255) ,
	email_cliente varchar(255) ,
	dt_carga timestamp not null
);
