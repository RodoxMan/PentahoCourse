CREATE TABLE st_produtos (
  cd_produto varchar(255) ,
  nome_produto varchar(255) ,
  cat_produto varchar(255) ,
  preco_produto numeric (12,4) ,
  status_produto varchar(255) ,
  dt_carga timestamp not null
) ;
