/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Lookup filter
 *
 * @class LookupFilterDashboardsModal
 */
var LookupFilterDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'lookup',

    /**
     * Property with main template of modal
     *
     * @property message
     * @type {String}
     * @private
     */
    message: '<form class="form-group-inline">' +
                '<div class="form-group clearfix">' +
                    '<label><input type="radio" class="i18n" name="type-level" id="current-level" value="currentLevel"> Current Level</label>' +
                    '<label><input type="radio" class="i18n" name="type-level" id="override" value="override"> Override</label>' +
                '</div>' +
                '<div class="form-group">' +
                    '<label for="select-schema" class="i18n">Schemas:</label>' +
                    '<select class="form-control" id="select-schema" disabled></select>' +
                '</div>' +
                '<div class="form-group">' +
                    '<label for="select-cube" class="i18n">Cubes:</label>' +
                    '<select class="form-control" id="select-cube" disabled></select>' +
                '</div>' +
                '<div class="form-group">' +
                    '<label for="select-dimension" class="i18n">Dimensions:</label>' +
                    '<select id="select-dimension" class="form-control" disabled></select>' +
                '</div>' +
                '<div class="form-group">' +
                    '<label for="select-hierarchy" class="i18n">Hierarchies:</label>' +
                    '<select id="select-hierarchy" class="form-control" disabled></select>' +
                '</div>' +
                '<div class="form-group">' +
                    '<label for="select-level" class="i18n">Levels:</label>' +
                    '<select id="select-level" class="form-control" disabled></select>' +
                '</div>' +
             '</form>',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Save', method: 'save' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click  .dialog_footer a'  : 'call',
        'click  #current-level'    : 'disable_select',
        'click  #override'         : 'disable_select',
        'change #select-schema'    : 'select_schema',
        'change #select-cube'      : 'select_cube',
        'change #select-dimension' : 'select_dimension',
        'change #select-hierarchy' : 'select_hierarchy'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Lookup';
        var self = this;
        var htmlObject = this.dialog.$el.find('.sidebar-filter').find('form').data('htmlobject');
        var parameter = this.dialog.$el.find('.sidebar-filter').find('form').data('parameter');
        // var getMondrianVersion;
        this.mondrianVersion = 'mondrianVersion4';
        this.currentLevel = this.dialog.$el.find('.sidebar-filter').find('form').data('currentLevel');
        this.filterModel = this.dialog.dashboardsModel.get('filters').get(htmlObject + '_-_' + parameter);
        this.dataCubes;
        this.bind('open', function() {
            // getMondrianVersion = new MondrianVersion({}, { dialog: this });
            // getMondrianVersion.fetch();
            self.check_radio_buttons();
        });
    },

    /**
     * Template for create element <option>
     *
     * @method option_template
     * @private
     * @param  {Object} data Data with names of schemas, cubes and etc
     * @return {String}      HTML template
     */
    option_template: function(data) {
        return _.template(
            '<option value="">-- Select --</option>' +
            '<% _.each(obj.repoObjects, function(value) { %>' +
                '<% if (value.keys) { %>' +
                    '<option value="<%= value.keys %>"><%= value.cubes %></option>' +
                '<% } else { %>' +
                    '<option value="<%= value %>"><%= value %></option>' +
                '<% } %>' +
            '<% }); %>'
        )({ repoObjects: data });
    },

    /**
     * Check radio buttons if current level selected or override
     *
     * @method check_radio_buttons
     * @private
     */
    check_radio_buttons: function() {
        this.objFilter = this.filterModel.toJSON();

        // console.log(this.objFilter);

        if (this.objFilter.typeLevelLookup && this.objFilter.typeLevelLookup === 'currentLevel') {
            this.$el.find('#current-level').prop('checked', true);
            this.$el.find('select').prop('disabled', true);
        }
        else if (this.objFilter.typeLevelLookup && this.objFilter.typeLevelLookup === 'override') {
            this.$el.find('#override').prop('checked', true);
            this.$el.find('select').prop('disabled', false);
            var schemasObject = new SchemasObject({}, { dialog: this });
            schemasObject.fetch();
            Saiku.ui.block('Loading Schemas...');
        }
    },

    /**
     * Disable fields select
     *
     * @method disable_select
     * @private
     */
    disable_select: function() {
        if (this.$el.find('#current-level').is(':checked')) {
            this.$el.find('select').prop('disabled', true);
        }
        else {
            this.$el.find('select').prop('disabled', false);
            var schemasObject = new SchemasObject({}, { dialog: this });
            schemasObject.fetch();
            Saiku.ui.block('Loading Schemas...');
        }
    },

    /**
     * Select schema
     *
     * @method select_schema
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    select_schema: function(event) {
        if (event) {
            event.preventDefault();
            var $currentTarget = $(event.currentTarget);
            this.populate_cubes($currentTarget.val());
        }
        else {
            var selectedSchema = this.objFilter.contentLookup.split('/')[2];
            this.populate_cubes(selectedSchema);
        }
    },

    /**
     * Select cube
     *
     * @method select_cube
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    select_cube: function(event) {
        if (event) {
            event.preventDefault();
            var $currentTarget = $(event.currentTarget);
            var dimensionsObject = new DimensionsObject({}, { dialog: this, key: $currentTarget.val() });
            dimensionsObject.fetch();
            Saiku.ui.block('Loading Dimensions...');
        }
        else {
            var selectedCube = this.objFilter.contentLookup.split('/')[0] + '/' + this.objFilter.contentLookup.split('/')[1] + '/' +
                               this.objFilter.contentLookup.split('/')[2] + '/' + this.objFilter.contentLookup.split('/')[3];
            var dimensionsObject = new DimensionsObject({}, { dialog: this, key: selectedCube });
            dimensionsObject.fetch();
        }
    },

    /**
     * Select dimension
     *
     * @method select_dimension
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    select_dimension: function(event) {
        if (event) {
            event.preventDefault();
            var $currentTarget = $(event.currentTarget);
            var key = this.$el.find('#select-cube option:selected').val();
            var hierarchiesObject = new HierarchiesObject({}, { dialog: this, key: key, dimension: $currentTarget.val() });
            hierarchiesObject.fetch();
            Saiku.ui.block('Loading Hierarchies...');
        }
        else {
            var key = this.$el.find('#select-cube option:selected').val();
            var selectedDimension = this.objFilter.contentLookup.split('/')[5];
            var hierarchiesObject = new HierarchiesObject({}, { dialog: this, key: key, dimension: selectedDimension });
            hierarchiesObject.fetch();
        }
    },

    /**
     * Select hierarchy
     *
     * @method select_hierarchy
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    select_hierarchy: function(event) {
        if (event) {
            event.preventDefault();
            var $currentTarget = $(event.currentTarget);
            var key = this.$el.find('#select-cube option:selected').val();
            var dimension = this.$el.find('#select-dimension option:selected').val();
            var levelsObject = new LevelsObject({}, { dialog: this, key: key, dimension: dimension, hierarchy: $currentTarget.val() });
            levelsObject.fetch();
            Saiku.ui.block('Loading Levels...');
        }
        else {
            var key = this.$el.find('#select-cube option:selected').val();
            var dimension = this.$el.find('#select-dimension option:selected').val();
            var selectedHierarchy = this.objFilter.contentLookup.split('/')[7];
            var levelsObject = new LevelsObject({}, { dialog: this, key: key, dimension: dimension, hierarchy: selectedHierarchy });
            levelsObject.fetch();
        }
    },

    /**
     * Populate schemas
     *
     * @method populate_schemas
     * @private
     * @param  {Object} data Schemas data
     */
    populate_schemas: function(data) {
        var len = data.schemas.length;
        var schemas = [];
        var $options;
        var i;

        Saiku.ui.unblock();

        for (i = 0; i < len; i++) {
            schemas.push(data.schemas[i]);
        }

        $options = this.option_template(schemas);

        this.$el.find('#select-schema').empty();
        this.$el.find('#select-schema').append($options);

        if (this.objFilter.typeLevelLookup && this.objFilter.typeLevelLookup === 'override') {
            var selectedSchema = this.objFilter.contentLookup.split('/')[2];
            this.$el.find('#select-schema option[value="' + selectedSchema + '"]').prop('selected', true);
            this.select_schema();
        }
    },

    /**
     * Populate cubes
     *
     * @method populate_cubes
     * @private
     * @param  {Object} data Cubes data
     */
    populate_cubes: function(schema) {
        var len = this.dataCubes.cubes.length;
        var cubes = [];
        var $options;
        var i;

        for (i = 0; i < len; i++) {
            if (this.dataCubes.cubes[i].schema === schema) {
                cubes.push({
                    cubes: this.dataCubes.cubes[i].cube,
                    keys: this.dataCubes.cubes[i].key
                });
            }
        }

        $options = this.option_template(cubes);

        this.$el.find('#select-cube').empty();
        this.$el.find('#select-cube').append($options);

        if (this.objFilter.typeLevelLookup && this.objFilter.typeLevelLookup === 'override') {
            var selectedCube = this.objFilter.contentLookup.split('/')[0] + '/' + this.objFilter.contentLookup.split('/')[1] + '/' +
                               this.objFilter.contentLookup.split('/')[2] + '/' + this.objFilter.contentLookup.split('/')[3];
            this.$el.find('#select-cube option[value="' + selectedCube + '"]').prop('selected', true);
            this.select_cube();
        }
    },

    /**
     * Populate dimensions
     *
     * @method populate_dimensions
     * @private
     * @param  {Object} data Dimensions data
     */
    populate_dimensions: function(data) {
        var len = data.length;
        var dimensions = [];
        var $options;
        var i;

        Saiku.ui.unblock();

        for (i = 0; i < len; i++) {
            dimensions.push(data[i].name);
        }

        $options = this.option_template(dimensions);

        this.$el.find('#select-dimension').empty();
        this.$el.find('#select-dimension').append($options);

        if (this.objFilter.typeLevelLookup && this.objFilter.typeLevelLookup === 'override') {
            var selectedDimension = this.objFilter.contentLookup.split('/')[5];
            this.$el.find('#select-dimension option[value="' + selectedDimension + '"]').prop('selected', true);
            this.select_dimension();
        }
    },

    /**
     * Populate hierarchies
     *
     * @method populate_hierarchies
     * @private
     * @param  {Object} data Hierarchies data
     */
    populate_hierarchies: function(data) {
        var len = data.length;
        var hierarchies = [];
        var $options;
        var i;

        Saiku.ui.unblock();

        for (i = 0; i < len; i++) {
            hierarchies.push(data[i].name);
        }

        $options = this.option_template(hierarchies);

        this.$el.find('#select-hierarchy').empty();
        this.$el.find('#select-hierarchy').append($options);

        if (this.objFilter.typeLevelLookup && this.objFilter.typeLevelLookup === 'override') {
            var selectedHierarchy = this.objFilter.contentLookup.split('/')[7];
            this.$el.find('#select-hierarchy option[value="' + selectedHierarchy + '"]').prop('selected', true);
            this.select_hierarchy();
        }
    },

    /**
     * Populate levels
     *
     * @method populate_levels
     * @private
     * @param  {Object} data Levels data
     */
    populate_levels: function(data) {
        var len = data.length;
        var levels = [];
        var $options;
        var i;

        Saiku.ui.unblock();

        for (i = 0; i < len; i++) {
            levels.push(data[i].name);
        }

        $options = this.option_template(levels);

        this.$el.find('#select-level').empty();
        this.$el.find('#select-level').append($options);

        if (this.objFilter.typeLevelLookup && this.objFilter.typeLevelLookup === 'override') {
            var selectedLevel = this.objFilter.contentLookup.split('/')[9];
            this.$el.find('#select-level option[value="' + selectedLevel + '"]').prop('selected', true);
        }
    },

    /**
     * Create path name
     *
     * @method create_pathname
     * @private
     * @param  {String|Object} data Data with connection, catalog, schema and etc
     * @return {String}             Path name
     */
    create_pathname: function(data) {
        var objLevel;
        var pathName;
        var currentLevel;

        // This "replace" is a hack for work in BI Server.
        // See this example of the problem: https://jsfiddle.net/Lkq4v12n/1/
        // Please, fix me after :)

        if (typeof data === 'string') {
            // var currentLevel = data.replace(/[\[\]]/gi, '').split('.');
            currentLevel = data.split('].');
            if (currentLevel.length === 7) {
                objLevel = {
                    connection: currentLevel[0].replace(/[\[\]]/gi, ''),
                    catalog: currentLevel[1].replace(/[\[\]]/gi, ''),
                    schema: currentLevel[2].replace(/[\[\]]/gi, ''),
                    cube: currentLevel[3].replace(/[\[\]]/gi, ''),
                    dimension: currentLevel[4].replace(/[\[\]]/gi, ''),
                    hierarchy: currentLevel[5].replace(/[\[\]]/gi, ''),
                    level: currentLevel[6].replace(/[\[\]]/gi, '')
                };
            }
            else {
                objLevel = {
                    connection: currentLevel[0].replace(/[\[\]]/gi, ''),
                    catalog: currentLevel[1].replace(/[\[\]]/gi, ''),
                    schema: currentLevel[2].replace(/[\[\]]/gi, ''),
                    cube: currentLevel[3].replace(/[\[\]]/gi, ''),
                    dimension: currentLevel[4].replace(/[\[\]]/gi, ''),
                    hierarchy: currentLevel[4].replace(/[\[\]]/gi, ''),
                    level: currentLevel[5].replace(/[\[\]]/gi, '')
                }
            }
        }
        else {
            objLevel = data;
        }

        // if (this.mondrianVersion === 'mondrianVersion3') {
        //     pathName = objLevel.connection + '/' + objLevel.catalog + '/' + objLevel.schema + '/' + objLevel.cube +
        //                    '/dimensions/' + objLevel.dimension + '/hierarchies/' + objLevel.dimension + '.' + objLevel.hierarchy + '/levels/' + objLevel.level;
        // }
        // else {
            pathName = objLevel.connection + '/' + objLevel.catalog + '/' + objLevel.schema + '/' + objLevel.cube +
                           '/dimensions/' + objLevel.dimension + '/hierarchies/' + objLevel.hierarchy + '/levels/' + objLevel.level;
        // }

        return pathName;
    },

    /**
     * Save lookup
     *
     * @method save
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    save: function(event) {
        event.preventDefault();
        var typeLevel;

        if (this.$el.find('#current-level').is(':checked')) {
            typeLevel = 'currentLevel';
            this.filterModel.set({
                typeLevelLookup: typeLevel,
                contentLookup: this.create_pathname(this.currentLevel)
            });
        }
        else {
            var key = this.$el.find('#select-cube option:selected').val();
            var dimension = this.$el.find('#select-dimension option:selected').val();
            var hierarchy = this.$el.find('#select-hierarchy option:selected').val();
            var level = this.$el.find('#select-level option:selected').val();

            key = key.split('/');

            var objLevel = {
                connection: key[0],
                catalog: key[1],
                schema: key[2],
                cube: key[3],
                dimension: dimension,
                hierarchy: hierarchy,
                level: level
            };

            typeLevel = 'override';
            this.filterModel.set({
                typeLevelLookup: typeLevel,
                contentLookup: this.create_pathname(objLevel)
            });
        }

        this.$el.dialog('close');
    }
});
