/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Create a list of values for a filter
 *
 * @class CreateListFilterDashboardsModal
 */
var CreateListFilterDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'create-list',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Save', method: 'save' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click .dialog_footer a' : 'call',
        'click #add-new'         : 'add_new',
        'keyup #new-value'       : 'remove_error',
        'click .delete-item'     : 'delete_item'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Create List';
        var htmlObject = this.dialog.$el.find('.sidebar-filter').find('form').data('htmlobject');
        var parameter = this.dialog.$el.find('.sidebar-filter').find('form').data('parameter');
        var $list;

        this.filterModel = this.dialog.dashboardsModel.get('filters').get(htmlObject + '_-_' + parameter);

        $list = this.filterModel.attributes.contentList;
        $list = this.list_template($list);

        this.message = _.template(
            '<form class="form-group-inline">' +
                '<label for="new-value" class="i18n">Add new:</label>' +
                '<input type="text" id="new-value">' +
                '<a class="form_button i18n" id="add-new">Add</a><br>' +
                '<span class="error i18n" hidden>This field is required</span>' +
            '</form>' +
            '<div class="group-list">' +
                '<ul class="list"><%= obj %></ul>' +
            '</div>'
        )($list);

        this.bind('open');
    },

    /**
     * Template with list of values
     *
     * @method list_template
     * @private
     * @param  {Object} list List of values
     * @return {String}      HTML template
     */
    list_template: function(list) {
        return _.template(
            '<% _.each(obj, function(value) { %>' +
                '<li><%= value %><a href="#delete_item" class="delete-item">x</a></li>' +
            '<% }); %>'
        )(list);
    },

    /**
     * Button for add a new value in list
     *
     * @method add_new
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    add_new: function(event) {
        event.preventDefault();

        var newValue = this.$el.find('#new-value').val();
        var $li;

        if (this.check_fields(newValue)) {
            $li = ('<li>' + newValue + '<a href="#delete_item" class="delete-item">x</a></li>');
            this.$el.find('.list').append($li);
            this.$el.find('#new-value').val('').focus();
        }
    },

    /**
     * Get a list of values
     *
     * @method get_list
     * @private
     * @return {Array} List of values
     */
    get_list: function() {
        var list = [];

        this.$el.find('.list > li').each(function(key, value) {
            list.push(($(value).text()).substring(0, $(value).text().length - 1));
        });

        return list;
    },

    /**
     * Delete a item of list
     *
     * @method delete_item
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    delete_item: function(event) {
        event.preventDefault();
        var $currentTarget = $(event.currentTarget);
        $currentTarget.closest('li').remove();
    },

    /**
     * Check the fields of form
     *
     * @method check_fields
     * @private
     * @param  {String} newValue Value for add in list
     * @return {Boolean}         If element input contains a value
     */
    check_fields: function(newValue) {
        var isPassed = false;

        if (newValue) {
            isPassed = true;
        }
        else {
            isPassed = false;
            this.$el.find('.form-group-inline .error').show();
        }

        return isPassed;
    },

    /**
     * Remove message of error
     *
     * @method remove_error
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    remove_error: function(event) {
        var $currentTarget = $(event.currentTarget);

        if ($currentTarget.attr('id') === 'new-value') {
            this.$el.find('.form-group-inline .error').hide();
        }
    },

    /**
     * Save list in filter
     *
     * @method save
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    save: function(event) {
        event.preventDefault();

        var list = this.get_list();

        if (list && !(_.isEmpty(list))) {
            this.filterModel.set({
                contentList: list
            });
        }

        this.$el.dialog('close');
    }
});
