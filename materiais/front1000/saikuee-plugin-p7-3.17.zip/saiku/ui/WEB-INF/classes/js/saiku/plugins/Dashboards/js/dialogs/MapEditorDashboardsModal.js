/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * @dependencies
 * - leaflet/leaflet-heat.js
 * - plugins/CCC_Chart/map_editor.css
 * - plugins/CCC_Chart/plugin.js
 * - plugins/views/MapEditor.js
 * - render/SaikuMapRenderer.js
 * - views/QueryToolbar.js
 * - views/Workspace.js
 * - Saiku.js
 * - Settings.js
 */

/**
 * Class for edit maps
 *
 * @class MapEditorDashboardsModal
 */
var MapEditorDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'map-editor',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Save', method: 'save_map' },
        { text: 'Cancel', method: 'close_dialog' },
        { text: 'Help', method: 'help' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click  .dialog_footer a' : 'call'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        // console.log(this);
        var self = this;
        var queryFileObject;
        this.options.title = 'Map Settings';
        this.mapEditor = new MapEditor(this.$el);
        this.message = this.mapEditor.template_editor();

        if (this.mapDefinition && _.has(this.mapDefinition, 'mapDefinition')) {
            this.mapProperties = this.mapDefinition;
            this.mapType = this.mapProperties ? this.mapProperties.mapDefinition.type : '';
        }

        // Maintain `this` in callbacks
        _.bindAll(this, 'set_render_type');

        this.bind('open', function() {
            this.mapEditor.post_render();
            this.mapEditor.show_map_type();
            this.get_query();
            // Add function for button Close `x`
            this.$el.parent().find('.ui-dialog-titlebar-close').bind('click', this.set_render_type);
        });
    },

    get_query: function() {
        queryFileObject = new QueryFileObject({}, { dialog: this, file: this.file });
        queryFileObject.fetch();
        Saiku.ui.block('Loading...');
    },

    populate_select: function(data) {
        Saiku.ui.unblock();
        this.mapEditor.get_rows(data.query);
        this.mapEditor.get_map_properties(this.mapProperties, this.mapType);
        this.$el.find('select').chosen({ allow_single_deselect: true });
    },

    set_render_type: function() {
        if (this.oldRender === 'table') {
            this.currentTarget.closest('.context-menu-list > li.context-menu-item').parent().find('input[value="renderTypeKey1"]').prop('checked', true);
            this.contextMenuOptions.data('radio', 'renderTypeKey1');
        }
        else if (this.oldRender === 'chart') {
            this.currentTarget.closest('.context-menu-list > li.context-menu-item').parent().find('input[value="renderTypeKey2"]').prop('checked', true);
            this.contextMenuOptions.data('radio', 'renderTypeKey2');
        }
    },

    close_dialog: function(event) {
        event.preventDefault();
        this.set_render_type();
        this.$el.dialog('close');
    },

    /**
     * Save map options
     *
     * @method save
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    save_map: function(event) {
        event.preventDefault();
        var mapType = this.$el.find('#map-type').val();
        var mapProperties = {};
        var saikuMapRenderer;
        var search;

        mapProperties.mapDefinition = {};
        mapProperties.mapDefinition.type = mapType;

        if (mapType === 'map_geo') {
            mapProperties.mapDefinition.lookupfields = this.$el.find('#select-country').val();
        }
        else {
            if (this.$el.find('#geo-lookup').is(':checked')) {
                mapProperties.mapDefinition.lookupfields = this.$el.find('#lookups').val();
                mapProperties.mapDefinition.latfield = null;
                mapProperties.mapDefinition.lonfield = null;
                mapProperties.mapDefinition.bias = this.$el.find('#geo-bias').val();
            }
            else {
                mapProperties.mapDefinition.latfield = this.$el.find('#lat').val();
                mapProperties.mapDefinition.lonfield = this.$el.find('#lon').val();
                mapProperties.mapDefinition.lookupfields = null;
            }
        }

        // mapProperties.mapDefinition.maptype = mapType;
        mapProperties.mapDefinition.geolookup = this.$el.find('#geo-lookup').is(':checked');
        mapProperties.mapDefinition.metric = this.$el.find('#select-metric').val();
        mapProperties.mapDefinition.search = {};
        mapProperties.mapDefinition.search.street = this.$el.find('#street-lookups').val();
        mapProperties.mapDefinition.search.city = this.$el.find('#city-lookups').val();
        mapProperties.mapDefinition.search.county = this.$el.find('#county-lookups').val();
        mapProperties.mapDefinition.search.state = this.$el.find('#state-lookups').val();
        mapProperties.mapDefinition.search.country = this.$el.find('#country-lookups').val();
        mapProperties.hasProcessed = false;
        search = mapProperties.mapDefinition.search;

        if ((search.street !== '' || search.city !== '' || search.county !== '' || search.state !== '' || search.country !== '') ||
            (mapProperties.mapDefinition.latfield !== null || mapProperties.mapDefinition.lonfield !== null)) {

            // TODO: Add icon loading of Saiku when OSM this processing "lat" and "lon"
            if (mapProperties.mapDefinition.latfield === null && mapProperties.mapDefinition.lonfield === null) {
                Saiku.ui.block('Loading map...');
            }

            this.dialog.saikuClient.execute({
                file: this.file,
                htmlObject: this.htmlObject,
                render: 'map',
                mode: mapType,
                mapDefinition: mapProperties
            });

            this.dialog.$el.find('.gs-w').find(this.htmlObject).parent().data('render', 'map');
            this.dialog.$el.find('.gs-w').find(this.htmlObject).parent().data('mode', mapType);
            this.dialog.$el.find('.gs-w').find(this.htmlObject).parent().data('mapDefinition', JSON.stringify(mapProperties));
            this.dialog.dashboardsModel.get('panels').set(this.dialog.gridster.serialize());
        }

        this.$el.dialog('close');
    }
});
