/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Dialog with options
 *
 * @class OptionsDashboardsModal
 */
var OptionsDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'options-dashboards',

    /**
     * Property with main template of modal
     *
     * @property message
     * @type {String}
     * @private
     */
    message: '<p>Create a new dashboard or open an existing project?</p>',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'New', method: 'new' },
        { text: 'Open', method: 'open_dashboards' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Dashboards';
        this.bind('open');
    },

    /**
     * Open dialog `Setup Grid`
     *
     * @method new
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    new: function(event) {
        event.preventDefault();
        (new SetupGridsDashboardsModal({ dialog: this })).render().open();
        this.$el.dialog('close');
    },

    /**
     * Open dialog `Open Dashboards`
     *
     * @method open_dashboards
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    open_dashboards: function(event) {
        event.preventDefault();
        (new OpenDashboardsModal({ dialog: this.dialog })).render().open();
        this.$el.dialog('close');
    }
});
