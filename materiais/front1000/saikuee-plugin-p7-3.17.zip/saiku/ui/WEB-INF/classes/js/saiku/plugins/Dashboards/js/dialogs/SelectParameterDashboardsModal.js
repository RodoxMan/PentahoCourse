/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Select Parameter
 *
 * @class SelectParameterDashboardsModal
 */
var SelectParameterDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'select-parameter',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Open Filter', method: 'open_filter' },
        { text: 'Cancel', method: 'close' },
        { text: 'Help', method: 'help' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click .dialog_footer a'   : 'call',
        'change #select-parameter' : 'remove_error'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Select Parameter';

        var $parameters = this.option_template(this.parameters);

        this.message = _.template(
            '<form class="form-group-inline">' +
                '<label for="select-parameter" class="i18n">Select a parameter:</label>' +
                '<select id="select-parameter"><%= obj %></select>' +
                '<span class="error i18n" hidden>This field is required</span>' +
            '</form>'
        )($parameters);

        this.bind('open');
    },

    /**
     * Redirect for link in wiki
     *
     * @method help
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    help: function(event) {
        event.preventDefault();
        window.open('http://wiki.meteorite.bi/display/SAIK/Dashboards');
    },

    /**
     * Template for create element <option>
     *
     * @method option_template
     * @private
     * @param  {Object} parameters Name parameter
     * @return {String}            HTML template
     */
    option_template: function(parameters) {
        return _.template(
            '<option value="">-- Select --</option>' +
            '<% _.each(obj.parameters, function(value, parameter) { %>' +
                '<option value="<%= parameter %>" data-value="<%= value %>"><%= parameter %></option>' +
            '<% }); %>'
        )({ parameters: parameters });
    },

    /**
     * Check the fields of form
     *
     * @method check_fields
     * @private
     * @param  {String} selectParameter Parameter selected
     * @return {Boolean}                If element input contains a value
     */
    check_fields: function(selectParameter) {
        var isPassed = false;

        if (selectParameter) {
            isPassed = true;
        }
        else {
            isPassed = false;
            this.$el.find('.form-group-inline .error').show();
        }

        return isPassed;
    },

    /**
     * Remove message of error
     *
     * @method remove_error
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    remove_error: function(event) {
        var $currentTarget = $(event.currentTarget);

        if ($currentTarget.attr('id') === 'select-parameter') {
            this.$el.find('.form-group-inline .error').hide();
        }
    },

    /**
     * Get levels
     *
     * @method get_levels
     * @private
     * @param  {Array}  data              Data levels
     * @param  {String} selectedParameter Selected parameter
     * @return {String}                   Current level
     */
    get_levels: function(data, selectedParameter) {
        var len = data.length;
        var level;
        var i;

        for (i = 0; i < len; i++) {
            if (data[i].parameterName === selectedParameter) {
                level = data[i].levels;
            }
        }

        return level;
    },

    /**
     * Open filter
     *
     * @method open_filter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    open_filter: function(event) {
        event.preventDefault();

        var selectedParameter = this.$el.find('#select-parameter option:selected').val();
        var selectedLevel = this.get_levels(JSON.parse(this.levels), selectedParameter);
        var objFilter;

        this.filterModel = this.dialog.dashboardsModel.get('filters').get(this.htmlObject + '_-_' + selectedParameter);

        if (this.check_fields(selectedParameter)) {
            if (this.filterModel === undefined) {
                this.dialog.dashboardsModel.get('filters').add(new FilterModel({
                    id: this.htmlObject + '_-_' + selectedParameter,
                    parameter: selectedParameter
                }));
            }
            else {
                objFilter = this.dialog.dashboardsModel.get('filters').get(this.htmlObject + '_-_' + selectedParameter).toJSON();

                if (objFilter.parameter !== selectedParameter) {
                    this.dialog.dashboardsModel.get('filters').add(new FilterModel({
                        id: this.htmlObject + '_-_' + selectedParameter,
                        parameter: selectedParameter
                    }));
                }
                else {
                    this.filterModel.set({
                        parameter: selectedParameter
                    });
                }
            }

            this.dialog.$el.find('.sidebar-filter').find('form').data('htmlobject', this.htmlObject);
            this.dialog.$el.find('.sidebar-filter').find('form').data('parameter', selectedParameter);
            this.dialog.$el.find('.sidebar-filter').find('form').data('currentLevel', selectedLevel);
            this.dialog.$el.find('.sidebar-filter').addClass('on');
            this.dialog.$el.find('.sidebar-filter').toggle('slide');
            this.dialog.edit_filter();
            this.$el.dialog('close');
        }
    }
});
