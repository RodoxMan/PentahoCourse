/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Add JS code for execute external source
 *
 * @class EmbedCodeDashboardsModal
 */
var EmbedCodeDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'embed-code',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Run', method: 'run' },
        { text: 'Cancel', method: 'close' },
        { text: 'Help', method: 'help' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click .dialog_footer a'        : 'call',
        'click #add-external-resources' : 'add_external_resources',
        'keyup #external-resources'     : 'remove_error',
        'click .delete-item'            : 'delete_item'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Embed Code';
        this.embedCodeCollection = this.dialog.dashboardsModel.get('panels').embedCode;
        this.embedCodeModel = this.embedCodeCollection.get(this.htmlObject);
        this.id = _.uniqueId('editor-js-');
        var objEmbedCode = this.embedCodeCollection.get(this.htmlObject);
        var $list;

        objEmbedCode = objEmbedCode ? objEmbedCode.toJSON() : '';

        if (objEmbedCode) {
            $list = this.list_template(objEmbedCode.uris);
            this.codeJS = objEmbedCode.codeJS;
        }

        // Maintain `this` in callbacks
        _.bindAll(this, 'start_editor');

        this.message = _.template(
            '<form class="form-group-inline">' +
                '<label for="external-resources" class="i18n">External Resources:</label>' +
                '<input type="text" id="external-resources" class="i18n" placeholder="JavaScript URI">' +
                '<a class="form_button" class="i18n" id="add-external-resources">Add</a><br>' +
                '<span class="error i18n" hidden>This field is required</span>' +
                '<div class="group-list">' +
                    '<ul class="list"><%= obj %></ul>' +
                '</div>' +
                '<label class="i18n" for="' + this.id + '">JavaScript:</label>' +
                '<div class="editor-js" id="' + this.id + '"></div>' +
             '</form>'
        )($list);

        this.bind('open', function() {
            this.$el.parents('.ui-dialog').css({ width: '550px' });
        });

        Saiku.ui.block('Loading...');

        // start editor JS
        _.delay(this.start_editor, 1000);
    },

    /**
     * Redirect for link in wiki
     *
     * @method help
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    help: function(event) {
        event.preventDefault();
        window.open('http://wiki.meteorite.bi/display/SAIK/Dashboards');
    },

    /**
     * Start editor ace.js
     *
     * @method start_editor
     * @public
     */
    start_editor: function() {
        this.editorJS = ace.edit(this.id);
        this.editorJS.getSession().setMode('ace/mode/text');
        this.editorJS.getSession().setUseWrapMode(true);
        this.editorJS.setValue(this.codeJS);
        Saiku.ui.unblock();
    },

    /**
     * Template with list of URIs
     *
     * @method list_template
     * @private
     * @param  {Object} list List of URIs
     * @return {String}      HTML template
     */
    list_template: function(list) {
        return _.template(
            '<% _.each(obj, function(value) { %>' +
                '<li><%= value %><a href="#delete_item" class="delete-item">x</a></li>' +
            '<% }); %>'
        )(list);
    },

    /**
     * Button for add a URI
     *
     * @method add_external_resources
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    add_external_resources: function(event) {
        event.preventDefault();

        var externalResources = this.$el.find('#external-resources').val();

        if (this.check_fields(externalResources) && this.check_external_uri(externalResources)) {
            var $li = ('<li>' + externalResources + '<a href="#delete_item" class="delete-item" data-info="new">x</a></li>');
            this.$el.find('.list').append($li);
            this.$el.find('#external-resources').val('').focus();
        }
    },

    check_external_uri: function(uri) {
        if (uri.substring((uri.length - 2), uri.length) === 'js') {
            this.$el.find('.form-group-inline .error').hide();
            return true;
        }
        else {
            this.$el.find('.form-group-inline .error').text('Add a JavaScript source valid');
            this.$el.find('.form-group-inline .error').show();
            return false;
        }
    },

    /**
     * Check if external URI is valid
     *
     * @method check_external_uri
     * @private
     * @param  {String}  uri URI link
     * @return {Boolean}     If URI is valid
     */
    check_external_uri: function(uri) {
        if (uri.substring((uri.length - 2), uri.length) === 'js') {
            this.$el.find('.form-group-inline .error').hide();
            return true;
        }
        else {
            this.$el.find('.form-group-inline .error').text('Add a JavaScript source valid');
            this.$el.find('.form-group-inline .error').show();
            return false;
        }
    },

    /**
     * Get list of URIs
     *
     * @method get_list
     * @private
     * @return {[type]} List of URIs
     */
    get_list: function() {
        var list = [];

        this.$el.find('.list > li').each(function(key, value) {
            list.push(($(value).text()).substring(0, $(value).text().length - 1));
        });

        return list;
    },

    /**
     * Delete a item of list
     *
     * @method delete_item
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    delete_item: function(event) {
        event.preventDefault();
        var $currentTarget = $(event.currentTarget);
        var scriptName;

        if ($currentTarget.data('info') === 'new') {
            $currentTarget.closest('li').remove();
        }
        else {
            scriptName = $currentTarget.closest('li').text();
            scriptName = scriptName.substring(0, (scriptName.length - 1));
            $currentTarget.closest('li').remove();
            this.delete_script(scriptName);
        }
    },

    /**
     * Delete script
     *
     * @method delete_script
     * @private
     * @param  {String} script URI link
     */
    delete_script: function(script) {
        var scripts = window.document.getElementsByTagName('script');
        var len = scripts.length;
        var i;

        for (i = 0; i < len; i++) {
            if (scripts[i] && scripts[i].src === script) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
        }
    },

    /**
     * Check the fields of form
     *
     * @method check_fields
     * @private
     * @param  {String} externalResources External resource for add in list
     * @return {Boolean}                  If element input contains a external resource
     */
    check_fields: function(externalResources) {
        var isPassed = false;

        if (externalResources) {
            isPassed = true;
        }
        else {
            isPassed = false;
            this.$el.find('.form-group-inline .error').text('This field is required');
            this.$el.find('.form-group-inline .error').show();
        }

        return isPassed;
    },

    /**
     * Remove message of error
     *
     * @method remove_error
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    remove_error: function(event) {
        var $currentTarget = $(event.currentTarget);

        if ($currentTarget.attr('id') === 'external-resources') {
            this.$el.find('.form-group-inline .error').hide();
        }
    },

    /**
     * Execute JS code
     *
     * @method run
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    run: function(event) {
        event.preventDefault();

        var uris = this.get_list();
        var codeJS = this.editorJS.getValue();

        if (_.isEmpty(this.embedCodeModel)) {
            this.embedCodeCollection.add(new EmbedCodeModel({
                id: this.htmlObject,
                file: this.file,
                oldRender: this.oldRender,
                uris: uris,
                codeJS: codeJS
            }));
        }
        else {
            if (this.embedCodeModel.attributes.oldRender && !(_.isEmpty(this.embedCodeModel.attributes.oldRender))) {
                this.oldRender = this.embedCodeModel.attributes.oldRender;
            }

            this.embedCodeModel.set({
                file: this.file,
                oldRender: this.oldRender,
                uris: uris,
                codeJS: codeJS
            });
        }

        this.dialog.saikuClient.execute({
            file: this.file,
            htmlObject: this.htmlObject,
            render: 'playground',
            uris: uris,
            codeJS: codeJS
        });

        this.$el.dialog('close');
    }
});
