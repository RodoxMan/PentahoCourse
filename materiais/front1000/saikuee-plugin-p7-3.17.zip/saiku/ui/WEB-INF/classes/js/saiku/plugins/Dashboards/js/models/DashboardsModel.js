/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Dashboards Model
 *
 * @class DashboardsModel
 */
var DashboardsModel = Backbone.Model.extend({
    /**
     * The defaults hash (or function) can be used to specify the default attributes for your model
     *
     * @property defauts
     * @type {Object}
     * @private
     */
	defauts: {
		title: '',
		panels: '',
		filters: ''
	}
});

/**
 * Panels Model
 *
 * @class PanelsModel
 */
var PanelsModel = Backbone.Model.extend({
    /**
     * The defaults hash (or function) can be used to specify the default attributes for your model
     *
     * @property defauts
     * @type {Object}
     * @private
     */
	defauts: {
		title: '',
		file: '',
		htmlObject: '',
		render: '',
		col: '',
		row: '',
		size_x: '',
		size_y: ''
	},

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
    initialize: function() {
        this.embedCode = new EmbedCodeCollection();
        this.embedCode.parent = this;
    },

    /**
     * Return a shallow copy of the model's attributes for JSON
     *
     * @method toJSON
     * @public
     * @return {Object} Return attributes
     */
    toJSON: function() {
        var attr = _.clone(this.attributes);
        attr.embedCode = this.embedCode;
        return attr;
    }
});

/**
 * Embed Code Collection
 *
 * @class EmbedCodeCollection
 */
var EmbedCodeCollection = Backbone.Collection.extend({
    /**
     * Raw access to the JavaScript array of models inside of the collection
     *
     * @property model
     * @type {Object}
     * @private
     */
	model: EmbedCodeModel
});

/**
 * Embed Code Model
 *
 * @class EmbedCodeModel
 */
var EmbedCodeModel = Backbone.Model.extend({
    /**
     * The defaults hash (or function) can be used to specify the default attributes for your model
     *
     * @property defauts
     * @type {Object}
     * @private
     */
	defauts: {
		file: '',
        oldRender: '',
		uris: '',
		codeJS: ''
	}
});

/**
 * Filters Collection
 *
 * @class FiltersCollection
 */
var FiltersCollection = Backbone.Collection.extend({
    /**
     * Raw access to the JavaScript array of models inside of the collection
     *
     * @property model
     * @type {Object}
     * @private
     */
	model: FilterModel
});

/**
 * Filter Model
 *
 * @class FilterModel
 */
var FilterModel = Backbone.Model.extend({
    /**
     * The defaults hash (or function) can be used to specify the default attributes for your model
     *
     * @property defauts
     * @type {Object}
     * @private
     */
	defauts: {
		parameter: '',
		name: '',
		type: '',
		contentType: '',
		contentList: '',
		contentLookup: ''
	},

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
    initialize: function() {
        this.linkFilters = new LinkFiltersCollection();
        this.linkFilters.parent = this;
    },

    /**
     * Return a shallow copy of the model's attributes for JSON
     *
     * @method toJSON
     * @public
     * @return {Object} Return attributes
     */
    toJSON: function() {
        var attr = _.clone(this.attributes);
        attr.linkFilters = this.linkFilters;
        return attr;
    }
});

/**
 * Link Filters Collection
 *
 * @class LinkFiltersCollection
 */
var LinkFiltersCollection = Backbone.Collection.extend({
    /**
     * Raw access to the JavaScript array of models inside of the collection
     *
     * @property model
     * @type {Object}
     * @private
     */
	model: LinkFilterModel
});

/**
 * Link Filter Model
 *
 * @class LinkFilterModel
 */
var LinkFilterModel = Backbone.Model.extend({
    /**
     * The defaults hash (or function) can be used to specify the default attributes for your model
     *
     * @property defauts
     * @type {Object}
     * @private
     */
	defauts: {
		report: '',
		parameter: '',
		parentHtmlObject: '',
		htmlObject: '',
		file: '',
		render: ''
	}
});