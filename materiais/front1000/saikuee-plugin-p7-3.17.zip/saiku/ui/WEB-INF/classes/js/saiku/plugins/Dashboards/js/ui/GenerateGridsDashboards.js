/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Generate grids in dashboards
 *
 * @class GenerateGridsDashboards
 */
var GenerateGridsDashboards = Backbone.View.extend({
    /**
     * Class name of element `<div>`
     *
     * @property className
     * @type {String}
     * @private
     */
    className: 'gridster',

    /**
     * Main template of workspace
     *
     * @property template
     * @type {String}
     * @private
     */
    template: _.template(
        '<ul><%= obj.lists %></ul>'
    ),

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);

        // Maintain `this` in callbacks
        _.bindAll(this, 'render', 'calculate_grid');

        var rows = this.numberRows;
        var cols = this.numberCols;
        var sizex = this.calculate_grid(cols);
        var sizey = ((rows === '1') ? 4 : this.calculate_grid(rows));
        this.lists = this.lists_template(rows, cols, sizex, sizey);
    },

    /**
     * Calculate grid
     *
     * @method calculate_grid
     * @public
     * @param  {String} val Value of size x or y
     * @return {Number}     Widget size
     */
    calculate_grid: function(val) {
        if (Math.round(6 / val) === 0) {
            return 3;
        }
        else {
            return Math.round(6 / val);
        }
    },

    /**
     * Method that create the template of widgets
     *
     * @method lists_template
     * @private
     * @param  {String} rows  Number of lines
     * @param  {String} cols  Number of cols
     * @param  {Number} sizex Size x
     * @param  {Number} sizey Size y
     * @return {[type]}       HTML template
     */
    lists_template: function(rows, cols, sizex, sizey) {
        return _.template(
            '<% for (var i = 1; i <= obj.rows; i++) { %>' +
                '<% for (var j = 1; j <= obj.cols; j++) { %>' +
                    '<li data-title="Widget <%= _.uniqueId() %>" data-htmlobject="<%= _.uniqueId("#panel-body-") %>" data-row="<%= i %>" data-col="<%= j %>" data-sizex="<%= obj.sizex %>" data-sizey="<%= obj.sizey %>">' +
                        '<div class="panel-title">' +
                            '<h3>Widget <%= (_.uniqueId() - 2) %></h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="<%= _.uniqueId("panel-body-") %>"></div>' +
                    '</li>' +
                '<% } %>' +
            '<% } %>'
        )({ rows: rows, cols: cols, sizex: sizex, sizey: sizey });
    },

    /**
     * Method that will load template into the view's `el` property using jQuery
     *
     * @method render
     * @public
     * @chainable
     */
    render: function() {
        var outputHtml = this.template({ lists: this.lists });
        this.$el.html(outputHtml);
        // TODO: Update code
        if (this.dialog.dialog) {
            this.dialog.dialog.$el.find('.dashboard-title').show();
            this.dialog.dialog.$el.find('.dashboard-title > h1').text('');
            this.dialog.dialog.dashboardsModel.set({ title: '' });
        }
        else {
            this.dialog.$el.find('.dashboard-title').show();
            this.dialog.$el.find('.dashboard-title > h1').text('');
            this.dialog.dashboardsModel.set({ title: '' });
        }
        return this;
    }
});
