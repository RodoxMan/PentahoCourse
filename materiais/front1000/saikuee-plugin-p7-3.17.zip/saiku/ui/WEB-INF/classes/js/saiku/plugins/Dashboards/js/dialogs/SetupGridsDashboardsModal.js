/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Setup for create grids
 *
 * @class SetupGridsDashboardsModal
 */
var SetupGridsDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'setup-grids',

    /**
     * Property with main template of modal
     *
     * @property message
     * @type {String}
     * @private
     */
    message: '<form class="form-group-inline">' +
                '<p class="i18n">Enter the number of rows and columns that you want for your dashboards:</p>' +
                '<label for="number-rows" class="i18n">No. of rows:</label>' +
                '<input type="number" min="0" id="number-rows"><br>' +
                '<span class="error err-1 i18n" hidden>This field is required</span><br>' +
                '<label for="number-cols" class="i18n">No. of columns:</label>' +
                '<input type="number" min="0" id="number-cols"><br>' +
                '<span class="error err-2 i18n" hidden>This field is required</span>' +
             '</form>',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Create', method: 'create' },
        { text: 'Layouts', method: 'layouts' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click  .dialog_footer a' : 'call',
        'keyup  #number-rows'     : 'remove_error',
        'change #number-rows'     : 'remove_error',
        'keyup  #number-cols'     : 'remove_error',
        'change #number-cols'     : 'remove_error'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.dialog = args.dialog.dialog;
        this.options.title = 'Setup Grids';
        this.bind('open', function() {
            if (isFF) {
                this.$el.find('.err-1, .err-2').css({ marginLeft: '100px' });
            }
        });
    },

    /**
     * [check_fields description]
     *
     * @method check_fields
     * @private
     * @param  {String}  numberRows Number of rows
     * @param  {String}  numberCols Number of cols
     * @return {Boolean}            If element input contains a value
     */
    check_fields: function(numberRows, numberCols) {
        var isPassed = 0;

        if (numberRows) {
            if (numberRows === '0') {
                isPassed--;
                this.$el.find('.form-group-inline .err-1').text('Can not be zero').show();
            }
            else {
                isPassed++;
            }
        }
        else {
            isPassed--;
            this.$el.find('.form-group-inline .err-1').text('This field is required').show();
        }

        if (numberCols) {
            if (numberCols === '0') {
                isPassed--;
                this.$el.find('.form-group-inline .err-2').text('Can not be zero').show();
            }
            else {
                isPassed++;
            }
        }
        else {
            isPassed--;
            this.$el.find('.form-group-inline .err-2').text('This field is required').show();
        }

        return isPassed === 2 ? true : false;
    },

    /**
     * Remove message of error
     *
     * @method remove_error
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    remove_error: function(event) {
        var $currentTarget = $(event.currentTarget);

        switch ($currentTarget.attr('id')) {
        case 'number-rows':
            this.$el.find('.form-group-inline .err-1').hide();
            break;

        case 'number-rows':
            this.$el.find('.form-group-inline .err-2').hide();
            break;

        default:
            this.$el.find('.form-group-inline .error').hide();
        }
    },

    /**
     * Open dialog `Layouts Dashboards`
     *
     * @method layouts
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    layouts: function(event) {
        event.preventDefault();
        (new LayoutsDashboardsModal({ dialog: this.dialog })).render().open();
        this.$el.dialog('close');
    },

    /**
     * Create grids
     *
     * @method create
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    create: function(event) {
        event.preventDefault();

        this.$el.find('.form-group .error').hide();

        this.dialog.numberRows = this.$el.find('#number-rows').val();
        this.dialog.numberCols = this.$el.find('#number-cols').val();

        if (this.check_fields(this.dialog.numberRows, this.dialog.numberCols)) {
            if (!this.dialog.openDashboards) {
                var generateGrids = new GenerateGridsDashboards({
                    dialog: this,
                    numberRows: this.dialog.numberRows,
                    numberCols: this.dialog.numberCols
                });
                generateGrids.render();
                this.dialog.$el.find('.grids-view').html(generateGrids.el);

                this.dialog.panel_gridster();

                // Trigger event when create grids
                this.dialog.trigger('workspaceToolbar:disable', { dialog: this });

                this.$el.dialog('close');
            }
            else {
                Saiku.tabs.add(new Dashboards({
                    newDashboards: true,
                    numberRows: this.dialog.numberRows,
                    numberCols: this.dialog.numberCols
                }));

                this.$el.dialog('close');
            }
        }
    }
});
