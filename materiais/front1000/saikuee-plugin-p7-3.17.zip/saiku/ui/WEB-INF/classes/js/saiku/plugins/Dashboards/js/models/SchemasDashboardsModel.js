/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Schemas Object Model
 *
 * @class SchemasObject
 */
var SchemasObject = Backbone.Model.extend({
    /**
     * Returns the relative URL where the model's resource would be located on the server
     *
     * @property url
     * @type {String}
     * @private
     */
	url: 'admin/discover',

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
	initialize: function(args, options) {
        if (options && options.dialog) {
        	this.dialog = options.dialog;
        }
	},

	/**
	 * Parse is called whenever a model's data is returned by the server, in fetch, and save
	 *
	 * @method parse
	 * @private
	 * @param  {Array} response Returned data from the server
	 */
	parse: function(response) {
		var dataCubes = this.fetch_cubes(response);
        if (this.dialog) {
        	this.dialog.dataCubes = dataCubes;
            this.dialog.populate_schemas(dataCubes);
        }
	},

	/**
	 * Fetch cubes
	 *
	 * @method fetch_cubes
	 * @private
	 * @param  {Array}  data Data from the server
	 * @return {Object}      Data with information of cubes
	 */
	fetch_cubes: function(data) {
		var connections = data;
		var schemas = [];
		var cubes = [];
		var dataCubes = {};

		for (var i = 0, iLen = connections.length; i < iLen; i++) {
			var connection = connections[i];
			for (var j = 0, jLen = connection.catalogs.length; j < jLen; j++) {
				var catalog = connection.catalogs[j];
				for (var k = 0, kLen = catalog.schemas.length; k < kLen; k++) {
					var schema = catalog.schemas[k];
					for (var l = 0, lLen = schema.cubes.length; l < lLen; l++) {
						var cube = schema.cubes[l];
						schemas.push(schema.name);
						cubes.push({
							schema: schema.name,
							cube: cube.name,
							key: connection.name + '/' + catalog.name + '/' +
		                         ((schema.name === '' || schema.name === null) ? null : schema.name) +
		                         '/' + encodeURIComponent(cube.name)
						});
					}
				}
			}
		}
		
		dataCubes.schemas = _.uniq(schemas);
		dataCubes.cubes = cubes;

		return dataCubes;
	}
});

/**
 * Dimensions Object Model
 *
 * @class DimensionsObject
 */
var DimensionsObject = Backbone.Model.extend({
    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
	initialize: function(args, options) {
        if (options && options.dialog) {
        	this.dialog = options.dialog;
        	this.key = options.key;
        }
	},

	/**
	 * Parse is called whenever a model's data is returned by the server, in fetch, and save
	 *
	 * @method parse
	 * @private
	 * @param  {Array} response Returned data from the server
	 */
	parse: function(response) {
        if (this.dialog) {
            this.dialog.populate_dimensions(response);
        }
	},

	/**
	 * Returns the relative URL where the model's resource would be located on the server
	 *
	 * @method url
	 * @private
	 * @return {String} Relative URL
	 */
	url: function() {
		return 'admin/discover/' + this.key + '/dimensions';
	}
});

/**
 * Hierarchies Object Model
 *
 * @class HierarchiesObject
 */
var HierarchiesObject = Backbone.Model.extend({
    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
	initialize: function(args, options) {
        if (options && options.dialog) {
        	this.dialog = options.dialog;
        	this.key = options.key;
        	this.dimension = options.dimension;
        }
	},

	/**
	 * Parse is called whenever a model's data is returned by the server, in fetch, and save
	 *
	 * @method parse
	 * @private
	 * @param  {Array} response Returned data from the server
	 */
	parse: function(response) {
        if (this.dialog) {
            this.dialog.populate_hierarchies(response);
        }
	},

	/**
	 * Returns the relative URL where the model's resource would be located on the server
	 *
	 * @method url
	 * @private
	 * @return {String} Relative URL
	 */
	url: function() {
		return 'admin/discover/' + this.key + '/dimensions/' + this.dimension + '/hierarchies';
	}
});

/**
 * Levels Object Model
 *
 * @class LevelsObject
 */
var LevelsObject = Backbone.Model.extend({
    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
	initialize: function(args, options) {
        if (options && options.dialog) {
        	this.dialog = options.dialog;
        	this.key = options.key;
        	this.dimension = options.dimension;
        	this.hierarchy = options.hierarchy;
        }
	},

	/**
	 * Parse is called whenever a model's data is returned by the server, in fetch, and save
	 *
	 * @method parse
	 * @private
	 * @param  {Array} response Returned data from the server
	 */
	parse: function(response) {
        if (this.dialog) {
            this.dialog.populate_levels(response);
        }
	},

	/**
	 * Returns the relative URL where the model's resource would be located on the server
	 *
	 * @method url
	 * @private
	 * @return {String} Relative URL
	 */
	url: function() {
		return 'admin/discover/' + this.key + '/dimensions/' + this.dimension + '/hierarchies/' +
			   this.hierarchy + '/levels';
	}
});

/**
 * Query File Object Model
 *
 * @class QueryFileObject
 */
var QueryFileObject = Backbone.Model.extend({
    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
    initialize: function(args, options) {
        if (options && options.dialog) {
            this.dialog = options.dialog;
            this.file = options.file;
        }
    },

    /**
     * Parse is called whenever a model's data is returned by the server, in fetch, and save
     *
     * @method parse
     * @private
     * @param  {Array} response Returned data from the server
     */
    parse: function(response) {
        if (this.dialog) {
            this.dialog.populate_select(response);
        }
    },

    /**
     * Returns the relative URL where the model's resource would be located on the server
     *
     * @method url
     * @private
     * @return {String} Relative URL
     */
    url: function() {
        return 'embed/export/saiku/json?formatter=flattened&file=' + this.file;
    }
});

/**
 * Mondrian Version
 *
 * @class MondrianVersion
 */
var MondrianVersion = Backbone.Model.extend({
    /**
     * Returns the relative URL where the model's resource would be located on the server
     *
     * @property url
     * @type {String}
     * @private
     */
	url : 'statistics/mondrian/server/version',

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     */
	initialize: function(args, options) {
        if (options && options.dialog) {
        	this.dialog = options.dialog;
        }
	},

	/**
	 * Parse is called whenever a model's data is returned by the server, in fetch, and save
	 *
	 * @method parse
	 * @private
	 * @param  {Object} response Returned data from the server
	 */
	parse: function(response) {
        if (this.dialog) {
	        if (response && response.majorVersion === 3) {
            	this.dialog.mondrianVersion = 'mondrianVersion3';
	        }
	        else {
	            this.dialog.mondrianVersion = 'mondrianVersion4';
	        }
        }
	}
});