/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */
var SaikuChartRenderer = function(data, options) {
    this.workspace = options.workspace;
    this.rawdata = data;
    this.cccOptions = {};
    // this.mapOptions = {};

    this.data = null;
    this.hasProcessed = false;
    this.hasRendered = false;

    if (!options && !options.hasOwnProperty('htmlObject')) {
        throw("You need to supply a html object in the options for the SaikuChartRenderer!");
    }
    this.el = $(options.htmlObject);
    this.id = _.uniqueId("chart_");
    $(this.el).html('<div class="canvas_wrapper" style="display:none;"><div id="canvas_' + this.id + '"></div></div>');
    this.zoom = options.zoom;

    if (options.zoom) {

        var self = this;
        var btns = "<span style='float:left;' class='zoombuttons'><a href='#' class='button rerender i18n' title='Re-render chart'></a><a href='#' class='button zoomout i18n' style='display:none;' title='Zoom back out'></a></span>";
        $( btns).prependTo($(this.el).find('.canvas_wrapper'));
        $(this.el).find('.zoomout').on('click', function(event) {
            event.preventDefault();
            self.zoomout();
        });
        $(this.el).find('.zoomin').on('click', function(event) {
            event.preventDefault();
            self.zoomin();
        });
        $(this.el).find('.rerender').on('click', function(event) {
            event.preventDefault();
            $(self.el).find('.zoomout').hide();
            self.switch_chart(self.type);
        });
    }

    if (options.chartDefinition) {
        this.chartDefinition = options.chartDefinition;
    }
    this.cccOptions.canvas = 'canvas_' + this.id;
    this.data = null;


    this.adjustSizeTo = null;
    if (options.adjustSizeTo) {
        this.adjustSizeTo = options.adjustSizeTo;
    } else {
        this.adjustSizeTo = options.htmlObject;
    }

    if (this.rawdata) {
        if (this.type == "sunburst") {
            this.process_data_tree( { data : this.rawdata });
        } else {
            this.process_data_tree( { data : this.rawdata }, true, true);
        }
    }

    if (options.mode) {
        this.switch_chart(options.mode);
    } else {
        // default
        this.switch_chart("stackedBar");
    }

    this.adjust();

};

SaikuChartRenderer.prototype.adjust = function () {
    var self = this;
    var calculateLayout = function() {
        if (self.hasRendered && $(self.el).is(':visible')) {
            self.switch_chart(self.type);
        }
    };

    var lazyLayout = _.debounce(calculateLayout, 300);
    $(window).resize(function() {
        $(self.el).find('.canvas_wrapper').fadeOut(150);
        lazyLayout();
    });
};

SaikuChartRenderer.prototype.zoomin = function() {
        $(this.el).find('.canvas_wrapper').hide();
        var chart = this.chart.root;
        var data = chart.data;
        data
        .datums(null, {selected: false})
        .each(function(datum) {
            datum.setVisible(false);
        });
        data.clearSelected();
        chart.render(true, true, false);
        this.render_chart_element();
};

SaikuChartRenderer.prototype.zoomout = function() {
        var chart = this.chart.root;
        var data = chart.data;
        var kData = chart.keptVisibleDatumSet;

        if (kData === null || kData.length === 0) {
            $(this.el).find('.zoomout').hide();
        }
        else if (kData.length == 1) {
            $(this.el).find('.zoomout').hide();
            chart.keptVisibleDatumSet = [];
            pvc.data.Data.setVisible(data.datums(null, { visible : false}), true);

        } else if (kData.length > 1) {
            chart.keptVisibleDatumSet.splice(kData.length - 1, 1);
            var nonVisible = data.datums(null, { visible : false}).array();
            var back = chart.keptVisibleDatumSet[kData.length - 1];
            _.intersection(back, nonVisible).forEach(function(datum) {
                    datum.setVisible(true);
            });
        }
        chart.render(true, true, false);
};

SaikuChartRenderer.prototype.render = function() {
    _.delay(this.render_chart_element, 0, this);
};
// SaikuChartRenderer.prototype.render_map = function() {
//     _.delay(this.render_map_element, 0, this);
// };
// SaikuChartRenderer.prototype.remove_map = function() {
//     $(this.el).find('.map_div').hide();
//     $(this.el).find('.map_div').empty();
// };
SaikuChartRenderer.prototype.remove_chart = function() {
    $(this.el).find('[id*="canvas_chart_"]').hide();
};


SaikuChartRenderer.prototype.switch_chart = function(key, override) {

	if((override != null || override != undefined) && (override.chartDefinition!=null || override.chartDefinition != undefined)) {
		this.chartDefinition = override.chartDefinition;
        if(override.chartDefinition.type!=undefined) {
            this.type = override.chartDefinition.type;
        }
        if(override.workspace !=null || override.workspace != undefined){
                this.workspace = override.workspace;
        }

        if(override.hasProcessed != undefined){
            this.hasProcessed = override.hasProcessed;
        }
	}

    var keyOptions =
    {
                "stackedBar" : {
                    type: "BarChart",
                    stacked: true
                },
                "bar" : {
                    type: "BarChart",
                },
                "multiplebar" : {
                    type: "BarChart",
                    multiChartIndexes: [1],
                    dataMeasuresInColumns: true,
                    orientation: "vertical",
                    smallTitlePosition: "top",
                    multiChartMax: 30,
                    multiChartColumnsMax: Math.floor( this.cccOptions.width / 200),
                    smallWidth: 200,
                    smallHeight: 150
                },
                "line" : {
                    type: "LineChart"
                },
                "pie" : {
                    type: "PieChart",
                    multiChartIndexes: [0] // ideally this would be chosen by the user (count, which)
                },
                "heatgrid" : {
                    type: "HeatGridChart"
                },
                "stackedBar100" : {
                    type: "NormalizedBarChart"
                },
                "area" : {
                    type: "StackedAreaChart"
                },
                "dot" : {
                    type: "DotChart"
                },
                "waterfall" : {
                    type: "WaterfallChart"
                },
                "treemap" : {
                    type: "TreemapChart"
                },
                "sunburst" : {
                    type: "SunburstChart"
                    //multiChartColumnsMax: Math.floor( this.cccOptions.width / 200)
                },
                "multiplesunburst": {
                    type: "SunburstChart",
                    multiChartIndexes: [1],
                    dataMeasuresInColumns: true,
                    orientation: "vertical",
                    smallTitlePosition: "top",
                    multiChartMax: 30,
                    multiChartColumnsMax: Math.floor(this.cccOptions.width / 200),
                    smallWidth: 200,
                    smallHeight: 150,
                    seriesInRows: false
                }
                // "map_geo": {
                //     type: "map_geo"
                // },
                // "map_heat":{
                //     type: "map_heat"
                // },
                // "map_marker":{
                //     type: "map_marker"
                // }
    };

	if(key === null || key === ''){

	}
    else if (key == "sunburst") {
        $(this.el).find('.zoombuttons a').hide();
        this.type = key;
        this.sunburst();
        if (this.hasProcessed) {
            this.render();
        }
    }
    //     else if(key == "map_geo" || key =="map_heat" || key == "map_marker"){
    //         var o = keyOptions[key];
    //         this.mapOptions = this.getQuickOptions(o)
    //         this.define_map();


    // }
    else if (keyOptions.hasOwnProperty(key)) {
        $(this.el).find('.zoombuttons a').hide();
        this.type = key;
        var o = keyOptions[key];
		this.cccOptions = this.getQuickOptions(o);
        if(this.chartDefinition!=undefined) {
            this.chartDefinition.type = o.type;
        }
        this.define_chart();
        if (this.hasProcessed) {
            this.render();
        }

    } else {
        if (key !== 'charteditor' && key !== 'map') {
            alert("Do not support chart type: '" + key + "'");
        }
    }

};

SaikuChartRenderer.prototype.sunburst = function() {
    this.type = "sunburst";

    var data = this.process_data_tree({ data: this.rawdata });
    var options = this.getQuickOptions({});
    function title(d) {
      return d.parentNode ? (title(d.parentNode) + "." + d.nodeName) : d.nodeName;
    }

    var re = "",
        nodes = pv.dom(data).nodes(); // .root("flare").nodes();

    var tipOptions = {
          delayIn: 200,
          delayOut:80,
          offset:  2,
          html:    true,
          gravity: "nw",
          fade:    false,
          followMouse: true,
          corners: true,
          arrow:   false,
          opacity: 1
    };

    var color = pv.colors(options.colors).by(function(d) { return d.parentNode && d.parentNode.nodeName; });

    var vis = new pv.Panel()
        .width(options.width)
        .height(options.height)
        .canvas(options.canvas);

    var partition = vis.add(pv.Layout.Partition.Fill)
        .nodes(nodes)
        .size(function(d) { return d.nodeValue; })
        .order("descending")
        .orient("radial");

    partition.node.add(pv.Wedge)
        .fillStyle( pv.colors(options.colors).by(function(d) { return d.parentNode && d.parentNode.nodeName; }))
        .visible(function(d) { return d.depth > 0; })
        .strokeStyle("#000")
        .lineWidth(0.5)
        .text(function(d) {
            var v = "";
            if (typeof d.nodeValue != "undefined") {
                v = " : " + d.nodeValue;
            }
            return (d.nodeName + v);
        } )
                .cursor('pointer')
                .events("all")
                .event('mousemove', pv.Behavior.tipsy(tipOptions) );

    partition.label.add(pv.Label)
        .visible(function(d) { return d.angle * d.outerRadius >= 6; });


        this.chart = vis;
};


// Default static style-sheet
SaikuChartRenderer.prototype.cccOptionsDefault = {
        Base: {
            animate: false,
            selectable: true,
            valuesVisible: false,
            legend:  true,
            legendPosition: "top",
            legendAlign: "right",
            compatVersion: 2,
            legendSizeMax: "30%",
            axisSizeMax: "40%",
            plotFrameVisible : false,
            orthoAxisMinorTicks : false,
            colors: ["#1f77b4", "#aec7e8", "#ff7f0e", "#ffbb78", "#2ca02c", "#98df8a", "#d62728", "#ff9896", "#9467bd", "#c5b0d5", "#8c564b", "#c49c94", "#e377c2", "#f7b6d2", "#7f7f7f", "#c7c7c7", "#bcbd22", "#dbdb8d", "#17becf", "#9edae5" ]
        },

        HeatGridChart: {
            orientation: "horizontal",
            useShapes: true,
            shape: "circle",
            nullShape: "cross",
            colorNormByCategory: false,
            sizeRole: "value",
            legendPosition: "right",
            legend: true,
            hoverable: true,
            axisComposite: true,
            colors: ["red", "yellow", "lightgreen", "darkgreen"],
            yAxisSize: "20%"

        },

        WaterfallChart: {
            orientation: "horizontal"
        },

        PieChart: {
            multiChartColumnsMax: 3,
            multiChartMax: 30,
            smallTitleFont: "bold 14px sans-serif",
            valuesVisible: true,
            valuesMask: "{value.percent}",
            explodedSliceRadius: "10%",
            extensionPoints: {
                slice_innerRadiusEx: '40%',
                 slice_offsetRadius: function(scene) {
                       return scene.isSelected() ? '10%' : 0;
                }
            },
            clickable: true
            //valuesLabelStyle: 'inside'
        },

        LineChart: {
            extensionPoints: {
                area_interpolate: "monotone", // cardinal
                line_interpolate: "monotone"
            }
        },

        StackedAreaChart: {
            extensionPoints: {
                area_interpolate: "monotone",
                line_interpolate: "monotone"
            }
        },
        TreemapChart: {
            legendPosition: "right",
             multiChartIndexes: 0,
            extensionPoints: {
                leaf_lineWidth : 2
            },
            layoutMode: "slice-and-dice",
            valuesVisible: true
        },
        SunburstChart: {
            valuesVisible: false,
            hoverable: false,
            selectable: true,
            clickable: false,
            multiChartIndexes: [0],
            multiChartMax: 30
        }
};

SaikuChartRenderer.prototype.getQuickOptions = function(baseOptions) {
        var chartType = (baseOptions && baseOptions.type) || "BarChart";
        var options = _.extend({
                type:   chartType,
                canvas: 'canvas_' + this.id
            },
            this.cccOptionsDefault.Base,
            this.cccOptionsDefault[chartType], // may be undefined
            baseOptions);

        if (this.adjustSizeTo) {
            var al = $(this.adjustSizeTo);
//al.appendTo(document.body);
//var width = al.width();
//al.remove();
            if (al && al.length > 0) {
                var runtimeWidth = al.width() - 40;
                var runtimeHeight = al.height() - 40;
                if (runtimeWidth > 0) {
                    options.width = runtimeWidth;
                }
                if (runtimeHeight > 0) {
                    options.height = runtimeHeight;
                }
            }
        }

        if(this.data !== null && this.data.resultset.length > 5) {
            if(options.type === "HeatGridChart") {
//                options.xAxisSize = 200;
            } else if(options.orientation !== "horizontal") {
                options.extensionPoints = _.extend(Object.create(options.extensionPoints || {}),
                    {
                        xAxisLabel_textAngle: -Math.PI/2,
                        xAxisLabel_textAlign: "right",
                        xAxisLabel_textBaseline:  "middle"
                    });
            }
        }

	options.colors = ['#BB0000', '#007070', '#74AF00'];
        return options;
};
// SaikuChartRenderer.prototype.define_map = function(displayOptions) {
//     if (!this.hasProcessed) {
//         this.process_data_tree( { data : this.rawdata }, true, true);
//     }
//     var self = this;
//     var workspaceResults = (this.adjustSizeTo ? $(this.adjustSizeTo) : $(this.el));
//     var runtimeHeight = workspaceResults.height() - 40;

//     this.mapOptions.height = runtimeHeight;
//     if(this.mapOptions.type==="map_geo") {
//         google.load("visualization", "1", {
//             packages: ["geochart"], callback: function () {
//                 $(self.el).find('.canvas_wrapper').append("<div class='map_div'></div>");

//                 self.map = new google.visualization.GeoChart($(self.el).find('.map_div')[0]);
//                 if (self.hasProcessed) {
//                     self.render_map();
//                 }
//             }
//         });
//     }
//     else if(this.mapOptions.type==="map_heat"||this.mapOptions.type==="map_marker"){
//         self.render_map();
//     }
// };

SaikuChartRenderer.prototype.define_chart = function(displayOptions) {
        if (!this.hasProcessed) {
            this.process_data_tree( { data : this.rawdata }, true, true);
        }
        var self = this;
        var workspaceResults = (this.adjustSizeTo ? $(this.adjustSizeTo) : $(this.el));
        var isSmall = (this.data !== null && this.data.height < 80 && this.data.width < 80);
        var isMedium = (this.data !== null && this.data.height < 300 && this.data.width < 300);
        var isBig = (!isSmall && !isMedium);
        var animate = false;
        var hoverable =  isSmall;

        var runtimeWidth = workspaceResults.width() - 40;
        var runtimeHeight = workspaceResults.height() - 40;

        var runtimeChartDefinition = _.clone(this.cccOptions);

        if (displayOptions && displayOptions.width) {
            runtimeWidth = displayOptions.width;
        }
        if (displayOptions && displayOptions.height) {
            runtimeHeight = displayOptions.height;
        }

        if (runtimeWidth > 0) {
            runtimeChartDefinition.width = runtimeWidth;
        }
        if (runtimeHeight > 0) {
            runtimeChartDefinition.height = runtimeHeight;
        }

         if (isBig) {
            if (runtimeChartDefinition.hasOwnProperty('extensionPoints') && runtimeChartDefinition.extensionPoints.hasOwnProperty('line_interpolate'))
                delete runtimeChartDefinition.extensionPoints.line_interpolate;
            if (runtimeChartDefinition.hasOwnProperty('extensionPoints') && runtimeChartDefinition.extensionPoints.hasOwnProperty('area_interpolate'))
                delete runtimeChartDefinition.extensionPoints.area_interpolate;
         }
         var zoomDefinition = {
            legend: {
                    scenes: {
                        item: {
                            execute: function() {

                                var chart = this.chart();

                                if (!chart.hasOwnProperty('keptVisibleDatumSet')) {
                                    chart.keptVisibleDatumSet = [];
                                }

                                var keptSet = chart.keptVisibleDatumSet.length > 0 ? chart.keptVisibleDatumSet[chart.keptVisibleDatumSet.length - 1] : [];
                                var zoomedIn = keptSet.length > 0;

                                if (zoomedIn) {
                                    _.intersection(this.datums().array(), keptSet).forEach(function(datum) {
                                        datum.toggleVisible();
                                    });

                                } else {
                                    pvc.data.Data.toggleVisible(this.datums());
                                }

                                this.chart().render(true, true, false);

                            }
                        }
                    }
                },
                userSelectionAction: function(selectingDatums) {
                    if (selectingDatums.length === 0) {
                        return [];
                    }

                    var chart = self.chart.root;
                    var data = chart.data;
                    var selfChart = this.chart;

                    if (!selfChart.hasOwnProperty('keptVisibleDatumSet')) {
                        selfChart.keptVisibleDatumSet = [];
                    }

                    // we have too many datums to process setVisible = false initially
                    if (data.datums().count() > 1500) {
                        pvc.data.Data.setSelected(selectingDatums, true);
                    } else if (data.datums(null, {visible: true}).count() == data.datums().count()) {
                        $(self.el).find('.zoomout, .rerender').show();

                        var all = data.datums().array();

                        _.each( _.difference(all, selectingDatums), function(datum) {
                            datum.setVisible(false);
                        });

                        selfChart.keptVisibleDatumSet = [];
                        selfChart.keptVisibleDatumSet.push(selectingDatums);

                    } else {
                        var kept = selfChart.keptVisibleDatumSet.length > 0 ? selfChart.keptVisibleDatumSet[selfChart.keptVisibleDatumSet.length - 1] : [];

                        var visibleOnes = data.datums(null, { visible: true }).array();

                        var baseSet = kept;
                        if (visibleOnes.length < kept.length) {
                            baseSet = visibleOnes;
                            selfChart.keptVisibleDatumSet.push(visibleOnes);
                        }

                        var newSelection = [];
                        _.each( _.difference(visibleOnes, selectingDatums), function(datum) {
                            datum.setVisible(false);
                        });
                        _.each( _.intersection(visibleOnes, selectingDatums), function(datum) {
                            newSelection.push(datum);
                        });

                        if (newSelection.length > 0) {
                            selfChart.keptVisibleDatumSet.push(newSelection);
                        }
                    }


                chart.render(true, true, false);
                return [];

                }
        };

    // if(this.chartDefinition != undefined && this.chartDefinition.type != "map_geo" &&
    //     this.chartDefinition.type != "map_heat" && this.chartDefinition.type != "map_marker"){
    //     runtimeChartDefinition = _.extend(runtimeChartDefinition, {
    //         hoverable: hoverable,
    //         animate: animate
    //     }, this.chartDefinition);
    // }
    // else if(this.chartDefinition != undefined){
        runtimeChartDefinition = _.extend(runtimeChartDefinition, {
            hoverable: hoverable,
            animate: animate
        }, this.chartDefinition);
    // }
    // else{

        // runtimeChartDefinition = _.extend(runtimeChartDefinition, {
        //     hoverable: hoverable,
        //     animate: animate
        // }, null);

    // }

//	if(this.chartDefinition != undefined && this.chartDefinition.legend == true){
         if (self.zoom) {
			 var l = runtimeChartDefinition.legend;
            runtimeChartDefinition = _.extend(runtimeChartDefinition, zoomDefinition);
			 if(l === false){
				 runtimeChartDefinition.legend = false;
			 }
         }
//}

        if (runtimeChartDefinition.type == "TreemapChart" && runtimeChartDefinition.legend) {
            runtimeChartDefinition.legend.scenes.item.labelText = function() {
                 var indent = "";
                    var group  = this.group;
                    if(group) {
                        var depth = group.depth;
                        // 0 ""
                        // 1 "text"
                        // 2 "└ text"
                        // 3 "  └ text"
                        switch(depth) {
                            case 0: return "";
                            case 1: break;
                            case 2: indent = " └ "; break;
                            default:
                                indent = new Array(2*(depth-2) + 1).join(" ") + " └ ";
                        }
                    }
                    return indent + this.base();
            };
        }
        this.chart = new pvc[runtimeChartDefinition.type](runtimeChartDefinition);
        this.chart.setData(this.data, {
            crosstabMode: true,
            seriesInRows: false
        });

};

SaikuChartRenderer.prototype.render_chart_element = function(context) {
        var self = context || this;
        var isSmall = (self.data !== null && self.data.height < 80 && self.data.width < 80);
        var isMedium = (self.data !== null && self.data.height < 300 && self.data.width < 300);
        var isBig = (!isSmall && !isMedium);
        var animate = false;
        // self.remove_map();

    if (self.chart.options && self.chart.options.animate) {
            animate = true;
        }
    // self.remove_map();

    if ($(self.el).find('.canvas_wrapper').find('#' + 'canvas_' + self.id).length === 0 &&
        $(self.el).find('.canvas_wrapper').find('.map-render').length === 1 &&
        $(self.el).find('.canvas_wrapper').find('.map-render').data('action') === 'querytoolbar') {

        $(self.el).html('<div class="canvas_wrapper" style="display:none;"><div id="canvas_' + self.id + '"></div></div>');

        if (self.zoom) {
            var btns = "<span style='float:left;' class='zoombuttons'><a href='#' class='button rerender i18n' style='display:none;' title='Re-render chart'></a><a href='#' class='button zoomout i18n' style='display:none;' title='Zoom back out'></a></span>";
            $(btns).prependTo($(self.el).find('.canvas_wrapper'));
            $(self.el).find('.zoomout').on('click', function (event) {
                event.preventDefault();
                self.zoomout();
            });
            $(self.el).find('.zoomin').on('click', function (event) {
                event.preventDefault();
                self.zoomin();
            });
            $(self.el).find('.rerender').on('click', function (event) {
                event.preventDefault();
                $(self.el).find('.zoomout').hide();
                self.switch_chart(self.type);
            })
        }
    }

    if (!animate || $(self.el).find('.canvas_wrapper').is(':visible')) {
            $(self.el).find('.canvas_wrapper').hide();
        }

        try {
            if (animate) {
                $(self.el).find('.canvas_wrapper').show();
            }

            self.chart.render();
            self.hasRendered = true;
        } catch (e) {
            $('#' + 'canvas_' + self.id).text("Could not render chart" + e);
        }
        if (self.chart.options && self.chart.options.animate) {
            return false;
        }
        if (isIE || isBig) {
            $(self.el).find('.canvas_wrapper').show();
        } else {
            $(self.el).find('.canvas_wrapper').fadeIn(400);
        }
    if(self.workspace!=null) {
        self.workspace.trigger("report:rendered");
    }
        return false;
};

// SaikuChartRenderer.prototype.render_map_element = function(context) {
//     var self = context || this;
//     var workspaceResults = (this.adjustSizeTo ? $(this.adjustSizeTo) : $(this.el));
//     var h = workspaceResults.height() - 40;
//     var isSmall = (self.data !== null && self.data.height < 80 && self.data.width < 80);
//     var isMedium = (self.data !== null && self.data.height < 300 && self.data.width < 300);
//     var isBig = (!isSmall && !isMedium);
//     var animate = false;
//     if (!animate || $(self.el).find('.canvas_wrapper').is(':visible')) {
//         //$(self.el).find('.canvas_wrapper').hide();
//     }
//     self.remove_chart();
//     var bounds = null;
//     var series = [];
//     var column = [];
//     var z = 0;
//     var keys = [];
//     for (var i = 0; i < self.data.metadata.length; i++) {
//         if(self.chartDefinition.lookupfields!= undefined) {
//             if (self.chartDefinition.lookupfields.indexOf(self.data.metadata[i].colName) > -1) {
//                 column[z] = self.data.metadata[i].colName;
//                 series[0] = column;
//                 z++;
//             }
//             else if (self.chartDefinition.metric === self.data.metadata[i].colName) {
//                 column[z] = self.data.metadata[i].colName;
//                 series[0] = column;
//                 z++;
//             }
//             else {
//                 keys.push(z);
//             }
//         }
//         else{
//             if (self.chartDefinition.latfield.indexOf(self.data.metadata[i].colName) > -1) {
//                 column[z] = self.data.metadata[i].colName;
//                 series[0] = column;
//                 z++;
//             }
//             else if (self.chartDefinition.lonfield.indexOf(self.data.metadata[i].colName) > -1) {
//                 column[z] = self.data.metadata[i].colName;
//                 series[0] = column;
//                 z++;
//             }
//             else if (self.chartDefinition.metric === self.data.metadata[i].colName) {
//                 column[z] = self.data.metadata[i].colName;
//                 series[0] = column;
//                 z++;
//             }
//             else {
//                 keys.push(z);
//             }
//         }
//     }

//     if (self.data.resultset.length > 0) {
//         $.each(self.data.resultset, function (key, value) {
//             val2 = value;
//             _.each(keys, function(k){
//                     val2.splice(k,1);
//             });

//             series[key + 1] = val2;
//         });
//     }

//     if(self.mapOptions.type==="map_geo") {
//         try {


//             var groupedCars = _.groupBy(series, function(car) {
//                 return car[0];
//             });

//             var c = [];
//             var l = 0;
//             _.each(groupedCars, function(val){
//                 var tot = 0;
//                 _.each(val, function(t){
//                     tot = tot+t[1].v;
//                 })

//                 if(l!=0){
//                     c.push([val[0][0], tot]);
//                 }
//                 else{
//                     c.push([val[0][0], val[0][1]]);
//                 }
//                 l++

//             });

//             var data1 = google.visualization.arrayToDataTable(c);

//             var options1 = {};
//             self.map.draw(data1, options1);
//             self.hasRendered = true;
//         } catch (e) {
//             $('#' + 'canvas_' + self.id).text("Could not render chart" + e);
//         }
//     }
//     else if(self.mapOptions.type === "map_marker"){
//         var map;
//         var geocoder = new google.maps.Geocoder();
//         var s;
//         var metid = -1;
//         var metname = "";
//         initialize2();

//         function codeAddress2() {
//             if (self.chartDefinition.latfield == null || self.chartDefinition.latfield == undefined) {
//                 var i = 1;

//                 function go() {
//                     s = series[i];
//                     var addr = "";
//                     var j = 0;

//                     _.each(s, function (el) {
//                         var col = series[0][j];
//                         if (self.chartDefinition.lookupfields.indexOf(col) > -1) {
//                             addr += el + ",";
//                         }
//                         else {
//                             metname = col;
//                             metid = j;
//                         }
//                         j++;
//                     });
//                     addr = addr.replace(/,\s*$/, "");

//                     var res = geoCode(addr, s, map);
//                     if (i++ < series.length) {
//                         setTimeout(go, 250);
//                     }
//                 }
//                 go();


//             }


//             else {
//                 var fields = series[0];
//                 var latid = -1;
//                 var lonid = -1;

//                 var z = 0;
//                 _.each(fields, function(f){
//                    if(f===self.chartDefinition.latfield){
//                        latid = z;
//                    }
//                     else if(self.chartDefinition.lonfield){
//                         lonid = z;
//                    }
//                     else{
//                        metname = f;
//                        metid = z;
//                    }
//                     z++;
//                 });

//                 for(i=1; i<series.length; i++) {
//                     s = series[i];

//                     var marker = new google.maps.Marker({
//                         position: new google.maps.LatLng(s[latid], s[lonid]),
//                         map: map,
//                         title: metname+": "+s[metid].f
//                     });
//                     bounds.extend(new google.maps.LatLng(s[latid], s[lonid]));
//                     map.fitBounds(bounds);
//                     var infowindow = new google.maps.InfoWindow({
//                         content: metname+": "+s[metid].f
//                     });
//                     google.maps.event.addListener(marker, 'click', function () {
//                         infowindow.setContent(metname+": "+s[metid].f);
//                         infowindow.open(map, this);
//                     });
//                 }
//             }
//         }
//         codeAddress2();

//         function initialize2() {
//             var mapOptions = {
//                 zoom: 1,
//                 center: new google.maps.LatLng(37.774546, -122.433523),
//                 styles: [{"elementType":"geometry","stylers":[{"hue":"#ff4400"},{"saturation":-68},{"lightness":-4},{"gamma":0.72}]},{"featureType":"road","elementType":"labels.icon"},{"featureType":"landscape.man_made","elementType":"geometry","stylers":[{"hue":"#0077ff"},{"gamma":3.1}]},{"featureType":"water","stylers":[{"hue":"#00ccff"},{"gamma":0.44},{"saturation":-33}]},{"featureType":"poi.park","stylers":[{"hue":"#44ff00"},{"saturation":-23}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"hue":"#007fff"},{"gamma":0.77},{"saturation":65},{"lightness":99}]},{"featureType":"water","elementType":"labels.text.stroke","stylers":[{"gamma":0.11},{"weight":5.6},{"saturation":99},{"hue":"#0091ff"},{"lightness":-86}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"lightness":-48},{"hue":"#ff5e00"},{"gamma":1.2},{"saturation":-23}]},{"featureType":"transit","elementType":"labels.text.stroke","stylers":[{"saturation":-64},{"hue":"#ff9100"},{"lightness":16},{"gamma":0.47},{"weight":2.7}]}]

//             };


//             $(self.el).find('.canvas_wrapper').append("<div class='map_div'></div>");

//         map = new google.maps.Map($(self.el).find('.map_div')[0],
//                 mapOptions);

//             $(self.el).find('.canvas_wrapper').height(self.mapOptions.height);
//             $(self.el).find('.map_div').height(self.mapOptions.height);

//             self.hasRendered = true;



//         }


//     }
//     else if(self.mapOptions.type === "map_heat"){
//         var map, pointarray, heatmap;
//         var geocoder = new google.maps.Geocoder();
//         var taxiData = [];
//         function codeAddress() {
//             for(i=1; i<series.length; i++) {
//                 var b = self.mapOptions.bias;
//                 var address = series[i][0] + ", " + series[i][1] + ", " + series[i][2];
//                 geocoder.geocode({'address': address, region: b}, function (results, status) {
//                     if (status == google.maps.GeocoderStatus.OK) {
//                         taxiData.push(results[0].geometry.location);
//                         bounds.extend(results[0].geometry.location);

//                     } else {
//                         alert('Geocode was not successful for the following reason: ' + status);
//                         console.log('Geocode was not successful for the following reason: ' + status);
//                         if(status === "OVER_QUERY_LIMIT"){
//                         }
//                     }
//                     if(i == series.length) {
//                         initialize();
//                     }

//                 });
//             }
//         }
//         codeAddress();


//         function geoCode(addr, s, map){
//             var b = self.mapOptions.bias;
//             geocoder.geocode({'address': addr, region: b}, function (results, status) {
//                 if (status == google.maps.GeocoderStatus.OK) {
//                     //console.log(results[0].geometry.location);
//                     var marker = new google.maps.Marker({
//                         position: results[0].geometry.location,
//                         map: map,
//                         title: results[0].formatted_address+ " / "+ metname+": "+s[metid].f
//                     });
//                     if(bounds === null || bounds === undefined){
//                         bounds = new google.maps.LatLngBounds(results[0].geometry.location);
//                         map.fitBounds(bounds);
//                     }
//                     else {
//                         bounds.extend(results[0].geometry.location);
//                         map.fitBounds(bounds);
//                     }
//                     var infowindow = new google.maps.InfoWindow({
//                         content: "<b>"+results[0].formatted_address +"</b><br/>"+results[0].geometry.location_type +"<br/>"+metname+": "+s[metid].f
//                     });
//                     google.maps.event.addListener(marker, 'click', function () {
//                         infowindow.setContent("<b>"+results[0].formatted_address +"</b><br/>"+results[0].geometry.location_type +"<br/>"+metname+": "+s[metid].f);
//                         infowindow.open(map, this);
//                     });
//                     return true;
//                 } else {
//                     console.log('Geocode was not successful for the following reason: ' + status);
//                     alert('Geocode was not successful for the following reason: ' + status);
//                     return false;
//                 }
//                 if (i == series.length) {
//                 }

//             });
//         }
//         function initialize() {
//             var mapOptions = {
//                 zoom: 1,
//                 center: new google.maps.LatLng(37.774546, -122.433523),
//                 mapTypeId: google.maps.MapTypeId.SATELLITE
//             };

//             $(self.el).find('.canvas_wrapper').append("<div class='map_div'></div>");

//             map = new google.maps.Map($(self.el).find('.map_div')[0],
//                 mapOptions);

//             $(self.el).find('.canvas_wrapper').height(self.mapOptions.height);
//             $(self.el).find('.map_div').height(self.mapOptions.height);





//             var pointArray = new google.maps.MVCArray(taxiData);

//             heatmap = new google.maps.visualization.HeatmapLayer({
//                 data: pointArray
//             });

//             heatmap.setMap(map);
//         }

//         function toggleHeatmap() {
//             heatmap.setMap(heatmap.getMap() ? null : map);
//         }

//         function changeGradient() {
//             var gradient = [
//                 'rgba(0, 255, 255, 0)',
//                 'rgba(0, 255, 255, 1)',
//                 'rgba(0, 191, 255, 1)',
//                 'rgba(0, 127, 255, 1)',
//                 'rgba(0, 63, 255, 1)',
//                 'rgba(0, 0, 255, 1)',
//                 'rgba(0, 0, 223, 1)',
//                 'rgba(0, 0, 191, 1)',
//                 'rgba(0, 0, 159, 1)',
//                 'rgba(0, 0, 127, 1)',
//                 'rgba(63, 0, 91, 1)',
//                 'rgba(127, 0, 63, 1)',
//                 'rgba(191, 0, 31, 1)',
//                 'rgba(255, 0, 0, 1)'
//             ]
//             heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
//         }

//         function changeRadius() {
//             heatmap.set('radius', heatmap.get('radius') ? null : 20);
//         }

//         function changeOpacity() {
//             heatmap.set('opacity', heatmap.get('opacity') ? null : 0.2);
//         }

//     }
//     if (self.chart.options && self.chart.options.animate) {
//         return false;
//     }
//     if (isIE || isBig) {
//         $(self.el).find('.canvas_wrapper').show();
//     } else {
//         $(self.el).find('.canvas_wrapper').show();//fadeIn(400);
//     }
//     if(self.mapOptions.type==="map_heat" || self.mapOptions.type==="map_marker"){
//         setTimeout(function() {google.maps.event.trigger(map, 'resize'); map.fitBounds(bounds);}, 100);
//     }
//     return false;
// };

SaikuChartRenderer.prototype.process_data_tree = function(args, flat, setdata) {
    var self = this;
        var data = {};
        if (flat) {
            data.resultset = [];
            data.metadata = [];
            data.height = 0;
            data.width = 0;
        }

        var currentDataPos = data;
        if (typeof args == "undefined" || typeof args.data == "undefined") {
            return;
        }

        if (args.data !== null && args.data.error !== null) {
            return;
        }
        // Check to see if there is data
        if (args.data === null || (args.data.cellset && args.data.cellset.length === 0)) {
            return;
        }

        var cellset = args.data.cellset;
        if (cellset && cellset.length > 0) {
            var lowest_level = 0;
            var data_start = 0;
            var hasStart = false;
            var row,
                rowLen,
                labelCol,
                reduceFunction = function(memo, num){ return memo + num; };

            for (row = 0, rowLen = cellset.length; data_start === 0 && row < rowLen; row++) {
                    for (var field = 0, fieldLen = cellset[row].length; field < fieldLen; field++) {
                        if (!hasStart) {
                            while (cellset[row][field].type == "COLUMN_HEADER" && cellset[row][field].value == "null") {
                                row++;
                            }
                        }
                        hasStart = true;
                        if (cellset[row][field].type == "ROW_HEADER_HEADER") {
                            while(cellset[row][field].type == "ROW_HEADER_HEADER") {
                                if (flat) {
                                    data.metadata.push({
                                        colIndex: field,
                                        colType: "String",
                                        colName: cellset[row][field].value
                                    });
                                }
                                field++;
                            }
                            lowest_level = field - 1;
                        }
                        if (cellset[row][field].type == "COLUMN_HEADER") {
                            var lowest_col_header = 0;
                            var colheader = [];
                            while(lowest_col_header <= row) {
                                if (cellset[lowest_col_header][field].value !== "null") {
                                    colheader.push(cellset[lowest_col_header][field].value);
                                }
                                lowest_col_header++;
                            }
                            if (flat) {
                                data.metadata.push({
                                    colIndex: field,
                                    colType: "Numeric",
                                    colName: colheader.join(' ~ ')
                                });
                            }
                            data_start = row+1;
                        }
                    }
            }
            var labelsSet = {};
            var rowlabels = [];
            for (labelCol = 0; labelCol <= lowest_level; labelCol++) {
                rowlabels.push(null);
            }
            for (row = data_start, rowLen = cellset.length; row < rowLen; row++) {
            if (cellset[row][0].value !== "") {
                    var record = [];
                    var flatrecord = [];
                    var parent = null;
                    var rv = null;

                    for (labelCol = 0; labelCol <= lowest_level; labelCol++) {
                        if (cellset[row] && cellset[row][labelCol].value === 'null') {
                            currentDataPos = data;
                            var prevLabel = 0;
                            for (; prevLabel < lowest_level && cellset[row][prevLabel].value === 'null'; prevLabel++) {
                                currentDataPos = currentDataPos[ rowlabels[prevLabel] ];
                            }
                            if (prevLabel > labelCol) {
                                labelCol = prevLabel;
                            }

                        }
                        if (cellset[row] && cellset[row][labelCol].value !== 'null') {
                            if (labelCol === 0) {
                                for (var xx = 0; xx <= lowest_level; xx++) {
                                    rowlabels[xx] = null;
                                }
                            }
                            if (typeof currentDataPos == "number") {
                                parent[rv] = {};
                                currentDataPos = parent[rv];
                            }
                            rv = cellset[row][labelCol].value;
                            rowlabels[labelCol] = rv;

                            if (!currentDataPos.hasOwnProperty(rv)) {
                                currentDataPos[rv] = {};
                            }
                            parent = currentDataPos;
                            currentDataPos = currentDataPos[rv];
                        }
                    }
                    flatrecord = _.clone(rowlabels);
                    for (var col = lowest_level + 1, colLen = cellset[row].length; col < colLen; col++) {
                        var cell = cellset[row][col];
                        var value = cell.value || 0;
                        var maybePercentage = (value !== 0);
                        // check if the resultset contains the raw value, if not try to parse the given value
                        var raw = cell.properties.raw;
                        if (raw && raw !== "null") {
                            value = parseFloat(raw);
                        } else if (typeof(cell.value) !== "number" && parseFloat(cell.value.replace(/[^a-zA-Z 0-9.]+/g,''))) {
                            value = parseFloat(cell.value.replace(/[^a-zA-Z 0-9.]+/g,''));
                            maybePercentage = false;
                        }
                        if (value > 0 && maybePercentage) {
                            value = cell.value && cell.value.indexOf('%')>= 0 ? value * 100 : value;
                        }
                        record.push(value);

                        flatrecord.push({ f: cell.value, v: value});
                    }
                    if (flat) data.resultset.push(flatrecord);
                    var sum = _.reduce(record, reduceFunction, 0);
                    rv =  (rv === null ? "null" : rv);
                    parent[rv] = sum;
                    currentDataPos = data;
                }
            }
            if (setdata) {
                self.rawdata = args.data;
                self.data = data;
                self.hasProcessed = true;
                self.data.height = self.data.resultset.length;
            }
            return data;
        } else {
            $(self.el).find('.canvas_wrapper').text("No results").show();
        }
};
