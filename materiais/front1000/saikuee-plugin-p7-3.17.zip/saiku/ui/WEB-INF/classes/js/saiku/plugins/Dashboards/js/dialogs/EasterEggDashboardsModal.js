/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Dialog with promotion code
 *
 * @class EasterEggDashboardsModal
 */
var EasterEggDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'easteregg',

    /**
     * Property with main template of modal
     *
     * @property message
     * @type {String}
     * @private
     */
    message: '<p>Thanks for trying Saiku Enterprise Dashboard Designer Release Candidate, as a reward use the code <b>DASHBOARD10</b> at checkout for 10% off your order.</p>',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Get Saiku EE', method: 'get_saikuee' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Promotion Code';
        this.bind('open');
    },

    /**
     * Get Saiku EE
     *
     * @method get_saikuee
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    get_saikuee: function(event) {
        event.preventDefault();
        window.open('http://www.meteorite.bi/saiku-pricing');
    }
});
