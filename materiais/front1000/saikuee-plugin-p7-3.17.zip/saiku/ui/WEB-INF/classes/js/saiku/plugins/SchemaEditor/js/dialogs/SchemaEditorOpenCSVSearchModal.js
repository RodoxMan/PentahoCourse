/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorOpenCSVSearchModal = Modal.extend({
    type: 'search',

    events: {
        'click .dialog_footer a' : 'call',
        'click li.folder'        : 'toggle_folder',
        'click .query'           : 'select_name',
        'keyup .search_file'     : 'search_file',
        'click .cancel_search'   : 'cancel_search'
    },

    buttons: [
        { text: 'Choose', method: 'choose_folder' },
        { text: 'Cancel', method: 'close' }
    ],

    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Search Folder';

        var self = this;

        // Initialize repository
        this.repository = new Repository({}, { dialog: this, type: 'csv' });

        // Maintain `this` in callbacks
        _.bindAll(this, 'populate');

        this.message =  '<div class="box-search-file form-inline" style="padding-top:10px; height:35px; line-height:25px;"><label class="i18n">Search:</label> &nbsp;' +
                        ' <input type="text" class="form-control search_file"></input><span class="cancel_search"></span></div>' +
                        '<div class="RepositoryObjects"><span class="i18n">Loading...</span></div>' +
                        '<br>' +
                        '<b><div class="query_name"><span class="i18n">Please select a folder or file...</span></div></b><br>';

        this.bind('open', function() {
            var height = ($('body').height() / 2) + ($('body').height() / 6);
            var perc = (((($('body').height() - 600) / 2) * 100) / $('body').height());

            if (height > 420) {
                height = 420;
            }

            // Settings.ICON_16 = './images/src/csv.png';

            this.$el.find('.RepositoryObjects').height( height );
            this.$el.dialog('option', 'position', 'center');
            this.$el.parents('.ui-dialog').css({ width: '550px', top: perc + '%' });
            self.repository.fetch();

            if (Settings.REPOSITORY_LAZY) {
                this.$el.find('.box-search-file').hide();
            }
        });
    },

    populate: function(repository) {
        var self = this;

        this.$el.find('.RepositoryObjects').html(
            _.template($('#template-repository-objects').html())({
                repoObjects: repository
            })
        );

        this.$el.find('li.query span').attr('style', 'background-image: url(/images/src/csv.png)');

        self.queries = {};

        function getQueries(entries) {
            _.forEach(entries, function(entry) {
                self.queries[entry.path] = entry;
                if (entry.type === 'FOLDER') {
                    getQueries(entry.repoObjects);
                }
            });
        }

        getQueries(repository);
    },

    toggle_folder: function(event) {
        var $target = $(event.currentTarget);
        var path = $target.children('.folder_row').find('a').attr('href');

        path = path.replace('#', '');
        this.unselect_current_selected_folder();
        $target.children('.folder_row').addClass('selected');

        var $queries = $target.children('.folder_content');
        var isClosed = $target.children('.folder_row').find('.sprite').hasClass('collapsed');

        if (isClosed) {
            $target.children('.folder_row').find('.sprite').removeClass('collapsed');
            $queries.removeClass('hide');
            if (Settings.REPOSITORY_LAZY) {
                this.fetch_lazyload($target, path);
            }
        }
        else {
            $target.children('.folder_row').find('.sprite').addClass('collapsed');
            $queries.addClass('hide');
            if (Settings.REPOSITORY_LAZY) {
                $target.find('.folder_content').remove();
            }
        }

        this.$el.find('.query_name').html(path);
        this.$el.find('.query_name').data('path', path);

        return false;
    },

    fetch_lazyload: function(target, path) {
        var repositoryLazyLoad = new RepositoryLazyLoad({}, { dialog: this, folder: target, path: path });

        repositoryLazyLoad.fetch();
        Saiku.ui.block('Loading...');
    },

    template_repository_folder_lazyload: function(folder, repository) {
        folder.find('.folder_content').remove();
        folder.append(
            _.template($('#template-repository-folder-lazyload').html())({
                repoObjects: repository
            })
        );
    },

    populate_lazyload: function(folder, repository) {
        Saiku.ui.unblock();
        this.template_repository_folder_lazyload(folder, repository);
    },

    select_name: function(event) {
        var $currentTarget = $(event.currentTarget);
        var filePath;

        this.unselect_current_selected_folder();
        $currentTarget.parent().parent().has('.folder').children('.folder_row').addClass('selected');
        filePath = $currentTarget.find('a').attr('href');
        filePath = filePath.replace('#', '');
        this.$el.find('.query_name').html(filePath);
        this.$el.find('.query_name').data('path', filePath);

        return false;
    },

    unselect_current_selected_folder: function() {
        this.$el.find('.selected').removeClass('selected');
    },

    search_file: function(event) {
        var filter = this.$el.find('.search_file').val().toLowerCase();
        var isEmpty = (typeof filter === undefined || filter === '' || filter === null);

        if (isEmpty || event.which === 27 || event.which === 9) {
            this.cancel_search();
        }
        else {
            if (this.$el.find('.search_file').val()) {
                this.$el.find('.cancel_search').show();
            }
            else {
                this.$el.find('.cancel_search').hide();
            }

            this.$el.find('li.query').removeClass('hide');
            this.$el.find('li.query a').filter(function(index) {
                return $(this).text().toLowerCase().indexOf(filter) === -1;
            }).parent().addClass('hide');
            this.$el.find('li.folder').addClass('hide');
            this.$el.find('li.query').not('.hide').parents('li.folder').removeClass('hide');
            this.$el.find('li.folder .folder_row').find('.sprite').removeClass('collapsed');
            this.$el.find('li.folder .folder_content').removeClass('hide');
        }

        return false;
    },

    cancel_search: function(event) {
        this.$el.find('input.search_file').val('');
        this.$el.find('.cancel_search').hide();
        this.$el.find('li.query, li.folder').removeClass('hide');
        this.$el.find('.folder_row').find('.sprite').addClass('collapsed');
        this.$el.find('li.folder .folder_content').addClass('hide');
        this.$el.find('.search_file').val('').focus();
        this.$el.find('.cancel_search').hide();
    },

    choose_folder: function(event) {
        var path = this.$el.find('.query_name').data('path');

        if (path) {
            this.dialog.$el.find('input[name="csvpath"]').val(path);
        }

        this.$el.dialog('close');
    }
});
