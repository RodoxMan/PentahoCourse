/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Open tab in mode `Show`
 *
 * @class DashboardViewTab
 */
var DashboardViewTab = Backbone.View.extend({
    /**
     * Main template of workspace
     *
     * @property template
     * @type {String}
     * @private
     */
    template: _.template(
        '<div class="iframetab">' +
            '<iframe src="<%= obj.frame_url %>" style="position: relative; height: 100%; width: 100%; background-color: white;"></iframe>' +
        '</div>'
    ),

    /**
     * Subtitle Tab with name of file salved
     * 
     * @method caption
     * @private
     * @return {String} Subtitle Tab
     */
    caption: function() {
        return this.file.replace(/^.*[\\\/]/, '').split('.')[0] + ' (Show)';
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);

        // Maintain `this` in callbacks
        _.bindAll(this, 'render');

        Saiku.ui.unblock();
    },

    /**
     * Method that will load template into the view's `el` property using jQuery
     *
     * @method render
     * @public
     * @chainable
     */
    render: function() {
        var url = '/embed/dashboard.html?file=';
        var outputHtml;
        
        Saiku.ui.unblock();

        if (Settings.BIPLUGIN) {
            url = window.location.origin + '/pentaho/content/saiku-ui/embed/dashboard_biserver.html?file=';
        }

        outputHtml = this.template({ frame_url: url + this.file });

        this.$el.html(outputHtml);

        return this;
    }
});
