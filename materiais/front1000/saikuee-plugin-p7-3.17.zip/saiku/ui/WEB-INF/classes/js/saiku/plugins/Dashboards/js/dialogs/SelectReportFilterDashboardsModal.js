/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Select Report and Parameter
 *
 * @class SelectReportFilterDashboardsModal
 */
var SelectReportFilterDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'select-report',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Save', method: 'save' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click  .dialog_footer a'  : 'call',
        'change #select-report'    : 'select_report',
        'change #select-parameter' : 'select_parameter',
        'click .delete-item'       : 'delete_item'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Select Report and Parameter';
        this.reports = '';
        this.isLinkFilters = false;
        var self = this;
        var htmlObject = this.dialog.$el.find('.sidebar-filter').find('form').data('htmlobject');
        var parameter = this.dialog.$el.find('.sidebar-filter').find('form').data('parameter');
        var objLinkFilters;
        var $list;

        // Maintain `this` in callbacks
        _.bindAll(this, 'list_template');

        this.dialog.set_dashboards_model();
        this.filterModel = this.dialog.dashboardsModel.get('filters').get(htmlObject + '_-_' + parameter);
        this.objPanels = this.dialog.dashboardsModel.get('panels').toJSON();

        if (this.filterModel.attributes.linkFilters) {
            if (this.filterModel.attributes.linkFilters.length > 0 && this.filterModel.linkFilters.length === 0) {
                objLinkFilters = this.filterModel.attributes.linkFilters;
            }
            else {
                objLinkFilters = this.filterModel.linkFilters.toJSON();
            }
        }
        else {
            objLinkFilters = this.filterModel.linkFilters.toJSON();
        }

        if (objLinkFilters[0]) {
            this.isLinkFilters = true;
        }

        $list = this.list_template(objLinkFilters[0], true);

        this.message = _.template(
            '<form class="form-group-inline">' +
                '<div class="form-group">' +
                    '<label for="select-report" class="i18n">Report:</label>' +
                    '<select class="form-control" id="select-report"></select>' +
                '</div>' +
                '<div class="form-group">' +
                    '<label for="select-parameter" class="i18n">Parameter:</label>' +
                    '<select class="form-control" id="select-parameter" disabled></select>' +
                '</div>' +
            '</form>' +
            '<div class="group-list">' +
                '<ul class="list"><%= obj %></ul>' +
            '</div>'
        )($list);

        // console.log(this.filterModel);
        // console.log(this.objPanels);

        this.bind('open', function() {
            self.populate_report(htmlObject);
        });
    },

    /**
     * Populate report
     *
     * @method populate_report
     * @private
     * @param  {String} htmlObject Element HTML object
     */
    populate_report: function(htmlObject) {
        var len = _.size(this.objPanels);
        var reports = [];
        var $options;
        var i;

        for (i = 0; i < len; i++) {
            if (this.objPanels[i] && this.objPanels[i].htmlObject !== htmlObject && this.objPanels[i].parametersValues.length > 2) {
                reports.push({
                    report: this.objPanels[i].title,
                    htmlObject: this.objPanels[i].htmlObject,
                    file: this.objPanels[i].file,
                    render: this.objPanels[i].render,
                    mode: this.objPanels[i].mode,
                    chartDefinition: this.objPanels[i].chartDefinition ? this.objPanels[i].chartDefinition.replace(/"/g, '\'') : '',
                    mapDefinition: this.objPanels[i].mapDefinition ? this.objPanels[i].mapDefinition.replace(/"/g, '\'') : ''
                });
            }
        }

        $options = this.option_template(reports);
        this.reports = reports;
        this.$el.find('#select-report').empty();
        this.$el.find('#select-report').append($options);
    },

    /**
     * Template for create element <option>
     *
     * @method option_template
     * @private
     * @param  {Object} data Data with file, render, mode and etc
     * @return {String}      HTML template
     */
    option_template: function(data) {
        return _.template(
            '<option value="">-- Select --</option>' +
            '<% _.each(obj, function(value) { %>' +
                '<% if (value.htmlObject) { %>' +
                    '<option value="<%= value.htmlObject %>" data-file="<%= value.file %>" data-render="<%= value.render %>" data-mode="<%= value.mode %>" data-chartdefinition="<%= value.chartDefinition %>" data-mapdefinition="<%= value.mapDefinition %>"><%= value.report %></option>' +
                '<% } else { %>' +
                    '<option value="<%= value %>"><%= value %></option>' +
                '<% } %>' +
            '<% }); %>'
        )(data);
    },

    /**
     * Template with list of values
     *
     * @method list_template
     * @public
     * @param  {Object} list List of values
     * @return {String}      HTML template
     */
    list_template: function(list, isDialog) {
        if (isDialog) {
            return _.template(
                '<% _.each(obj, function(value) { %>' +
                    '<li><b>Report: </b><span class="list-report"><%= value.report %></span> &nbsp; ' +
                    '<b>Parameter: </b><span class="list-parameter"><%= value.parameter %></span>' +
                    '<a href="#delete_item" class="delete-item">x</a></li>' +
                '<% }); %>'
            )(list);
        }
        else {
            return _.template(
                '<% _.each(obj, function(value) { %>' +
                    '<li><%= value %></li>' +
                '<% }); %>'
            )(list);
        }
    },

    /**
     * Select report
     *
     * @method select_report
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    select_report: function(event) {
        event.preventDefault();
        var $currentTarget = $(event.currentTarget);
        var len = _.size(this.objPanels);
        var parameters;
        var $options;
        var i;

        for (i = 0; i < len; i++) {
            if (this.objPanels[i] && this.objPanels[i].htmlObject === $currentTarget.val()) {
                parameters = _.keys(JSON.parse(this.objPanels[i].parametersValues));
            }
        }

        $options = this.option_template(parameters);

        this.$el.find('#select-parameter').empty();
        this.$el.find('#select-parameter').append($options);
        this.$el.find('#select-parameter').prop('disabled', false);
    },

    /**
     * [select_parameter description]
     *
     * @method select_parameter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    select_parameter: function(event) {
        event.preventDefault();
        var $currentTarget = $(event.currentTarget);
        var selectedReport = this.$el.find('#select-report option:selected').text();
        var htmlObject = this.$el.find('#select-report option:selected').val();
        var file = this.$el.find('#select-report option:selected').data('file');
        var render = this.$el.find('#select-report option:selected').data('render');
        var mode = this.$el.find('#select-report option:selected').data('mode');
        var chartDefinition = this.$el.find('#select-report option:selected').data('chartdefinition');
        var mapDefinition = this.$el.find('#select-report option:selected').data('mapdefinition');
        var $li;

        if (this.$el.find('#select-report option:selected').val()) {
            $li = ('<li><b>Report: </b><span class="list-report" data-htmlobject="' + htmlObject + '" data-file="' + file + '" data-render="' + render + '" data-mode="' + mode + '" data-chartdefinition="' + chartDefinition + '" data-mapdefinition="' + mapDefinition + '">' + selectedReport + '</span> &nbsp; ' +
                   '<b>Parameter: </b><span class="list-parameter">' + $currentTarget.val() + '</span>' +
                   '<a href="#delete_item" class="delete-item">x</a></li>');

            this.$el.find('.list').append($li);
            this.$el.find('#select-report').prop('selectedIndex', 0);
            this.$el.find('#select-parameter').prop('selectedIndex', 0);
            this.$el.find('#select-parameter').prop('disabled', true);
        }
    },

    /**
     * Get a list of values
     *
     * @method get_list
     * @private
     * @return {Array} List of values
     */
    get_list: function() {
        var parentHtmlObject = this.dialog.$el.find('.sidebar-filter').find('form').data('htmlobject');
        var list = [];
        var arr;

        this.$el.find('.list > li').each(function(key, value) {
            list.push({
                report: $(value).find('.list-report').text(),
                parameter: $(value).find('.list-parameter').text(),
                parentHtmlObject: parentHtmlObject,
                htmlObject: $(value).find('.list-report').data('htmlobject'),
                file: $(value).find('.list-report').data('file'),
                render: $(value).find('.list-report').data('render'),
                mode: $(value).find('.list-report').data('mode'),
                chartDefinition: $(value).find('.list-report').data('chartdefinition'),
                mapDefinition: $(value).find('.list-report').data('mapdefinition')
            });
        });

        if (this.isLinkFilters && list.length > 0) {
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].file === undefined) {
                    arr = _.where(this.reports, { report: list[i].report });
                    _.extend(list[i], arr[0]);
                }
            }
        }

        return list;
    },

    /**
     * [get_reports description]
     *
     * @method get_reports
     * @private
     * @param  {Array} list [description]
     * @return {Array}      List of reports
     */
    get_reports: function(list) {
        var len = list.length;
        var reports = [];
        var i;

        for (i = 0; i < len; i++) {
            reports.push(list[i].report);
        }

        reports = _.uniq(reports);

        return reports;
    },

    /**
     * Delete a item of list
     *
     * @method delete_item
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    delete_item: function(event) {
        event.preventDefault();
        var $currentTarget = $(event.currentTarget);
        $currentTarget.closest('li').remove();
    },

    /**
     * Save list in filter
     *
     * @method save
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    save: function(event) {
        event.preventDefault();
        var list = this.get_list();
        var reports = this.get_reports(list);
        var $list = this.list_template(reports, false);

        if (_.isEmpty(list)) {
            this.dialog.$el.find('.sidebar-filter').find('.group-link-filters > ol').empty();
        }
        else {
            this.dialog.$el.find('.sidebar-filter').find('.group-link-filters > ol').empty();
            this.dialog.$el.find('.sidebar-filter').find('.group-link-filters > ol').append($list);
        }

        this.filterModel.linkFilters.reset();
        this.filterModel.linkFilters.add(new LinkFilterModel(list));
        this.$el.dialog('close');
    }
});
