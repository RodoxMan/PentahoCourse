/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

var SaveDashboardsModal = Modal.extend({
    type: 'save',

    buttons: [
        { text: 'Save', method: 'save' },
        { text: 'Cancel', method: 'close' }
    ],

    events: {
        'click .dialog_footer a' : 'call',
        'click li.folder'        : 'toggle_folder',
        'click .query'           : 'select_name',
        'keyup .search_file'     : 'search_file',
        'click .cancel_search'   : 'cancel_search',
        'submit form'            : 'save'
    },

    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Save Dashboards';
        this.folderName = null;
        this.fileName = null;
        this.filePath;

        var self = this;

        // Initialize repository
        this.repository = new Repository({}, { dialog: this, type: 'sdb' });

        // Maintain `this` in callbacks
        _.bindAll(this, 'populate');

  //       this.message = _.template(
        //  '<form id="save_query_form">' +
        //      '<label for="name" class="i18n">File:</label>&nbsp;' +
        //      '<input type="text" name="name" value="">' +
        //      '<div class="RepositoryObjects"><span class="i18n">Loading...</span></div>' +
        //      '<br>'+
        //  '</form>'+
        //  '<div style="height: 25px; line-height: 25px;">' +
        //      '<b><span class="i18n">Search:</span></b> &nbsp;' +
        //      '<span class="search">' +
        //          '<input type="text" class="search_file"><span class="cancel_search"></span>' +
        //      '</span>' +
        //  '</div>'
        // )({});

        this.message = _.template(
            '<div class="box-search-file form-inline" style="padding-top:10px; height:35px; line-height:25px;"><label class="i18n">Search:</label> &nbsp;' +
            ' <input type="text" class="form-control search_file"></input><span class="cancel_search"></span></div>' +
            '<form id="save_query_form">' +
                '<div class="RepositoryObjects"><span class="i18n">Loading...</span></div>' +
                '<label for="name" class="i18n">File:</label>&nbsp;' +
                '<input type="text" name="name" value="">' +
                '<br>'+
            '</form>'
        )({});

        this.bind('open', function() {
            var height = ($('body').height() / 2) + ($('body').height() / 6);
            if (height > 420) {
                height = 420;
            }
            var perc = (((($('body').height() - 600) / 2) * 100) / $('body').height());
            this.$el.find('.RepositoryObjects').height(height);
            this.$el.dialog('option', 'position', 'center');
            this.$el.parents('.ui-dialog').css({ width: '550px', top: perc + '%' });
            self.repository.fetch();
            if (Settings.REPOSITORY_LAZY) {
                this.$el.find('.box-search-file').hide();
            }
        });

        // Fix event listening in IE < 9
        if (isIE && isIE < 9) {
            this.$el.find('form').on('submit', this.save);
        }
    },

    populate: function( repository ) {
        this.$el.find('.RepositoryObjects').html(
            _.template($('#template-repository-objects').html())({
                repoObjects: repository
            })
        );
    },

    unselect_current_selected_folder: function() {
        this.$el.find('.selected').removeClass('selected');
    },

    toggle_folder: function(event) {
        var $target = $(event.currentTarget);
        var path = $target.children('.folder_row').find('a').attr('href');

        path = path.replace('#', '');
        this.unselect_current_selected_folder();
        $target.children('.folder_row').addClass('selected');

        var folderName = $target.find('a').attr('href').replace('#', '');

        this.set_name(folderName, null);

        var $queries = $target.children('.folder_content');
        var isClosed = $target.children('.folder_row').find('.sprite').hasClass('collapsed');

        if (isClosed) {
            $target.children('.folder_row').find('.sprite').removeClass('collapsed');
            $queries.removeClass('hide');
            if (Settings.REPOSITORY_LAZY) {
                this.fetch_lazyload($target, path);
            }
        }
        else {
            $target.children('.folder_row').find('.sprite').addClass('collapsed');
            $queries.addClass('hide');
            if (Settings.REPOSITORY_LAZY) {
                $target.find('.folder_content').remove();
            }
        }

        return false;
    },

    fetch_lazyload: function(target, path) {
        var repositoryLazyLoad = new RepositoryLazyLoad({}, { dialog: this, folder: target, path: path });
        repositoryLazyLoad.fetch();
        Saiku.ui.block('Loading...');
    },

    template_repository_folder_lazyload: function(folder, repository) {
        folder.find('.folder_content').remove();
        folder.append(
            _.template($('#template-repository-folder-lazyload').html())({
                repoObjects: repository
            })
        );
    },

    populate_lazyload: function(folder, repository) {
        Saiku.ui.unblock();
        this.template_repository_folder_lazyload(folder, repository);
    },

    set_name: function(folder, file) {
        if (folder !== null) {
            this.folderName = folder;
            var name = (this.folderName !== null ? this.folderName + '/' : '') + (this.fileName !== null ? this.fileName : '');
            this.$el.find('input[name="name"]').val(name);
        }

        if (file !== null) {
            this.$el.find('input[name="name"]').val(file);
        }
    },

    search_file: function(event) {
        var filter = this.$el.find('.search_file').val().toLowerCase();
        var isEmpty = (typeof filter === undefined || filter === '' || filter === null);

        if (isEmpty || event.which === 27 || event.which === 9) {
            this.cancel_search();
        }
        else {
            if (this.$el.find('.search_file').val()) {
                this.$el.find('.cancel_search').show();
            }
            else {
                this.$el.find('.cancel_search').hide();
            }

            this.$el.find('li.query').removeClass('hide');
            this.$el.find('li.query a').filter(function(index) {
                return $(this).text().toLowerCase().indexOf(filter) === -1;
            }).parent().addClass('hide');
            this.$el.find('li.folder').addClass('hide');
            this.$el.find('li.query').not('.hide').parents('li.folder').removeClass('hide');
            this.$el.find('li.folder .folder_row').find('.sprite').removeClass('collapsed');
            this.$el.find('li.folder .folder_content').removeClass('hide');
        }

        return false;
    },

    cancel_search: function(event) {
        this.$el.find('input.search_file').val('');
        this.$el.find('.cancel_search').hide();
        this.$el.find('li.query, li.folder').removeClass('hide');
        this.$el.find('.folder_row').find('.sprite').addClass('collapsed');
        this.$el.find('li.folder .folder_content').addClass('hide');
        this.$el.find('.search_file').val('').focus();
        this.$el.find('.cancel_search').hide();
    },

    select_name: function(event) {
        var $currentTarget = $(event.currentTarget);
        this.unselect_current_selected_folder();
        $currentTarget.parent().parent().has('.folder').children('.folder_row').addClass('selected');
        var name = $currentTarget.find('a').attr('href').replace('#', '');
        this.set_name(null, name);
        return false;
    },

    save: function(event) {
        var self = this;
        var foldername = '';
        var name = this.$el.find('input[name="name"]').val();

        if (name !== null && name.length > 0) {
            this.repository.fetch({
                success: function(collection, response) {
                    var paths = [];
                    paths.push.apply(paths, self.get_files(response));

                    if (paths.indexOf(name) > -1) {
                        new OverwriteModal({ name: name, foldername: foldername, parent: self }).render().open();
                    }
                    else {
                        self.filePath = name;
                        self.copy_to_repository();
                        event.stopPropagation();
                        event.preventDefault();
                        return false;
                    }
                }
            });
        }
        else {
            alert('You need to enter a name!');
        }

        return false;
    },

    save_remote: function(name, foldername, parent) {
        this.filePath = name;
        parent.copy_to_repository();
        return false;
    },

    get_files: function(response) {
        var self = this;
        var paths = [];

        _.each(response, function(entry) {
            if (entry.type === 'FOLDER') {
                paths.push.apply(paths, self.get_files(entry.repoObjects));
            }
            else {
                paths.push(entry.path);
            }
        });

        return paths;
    },

    copy_to_repository: function() {
        this.dialog.dashboardsModel.get('panels').set(this.dialog.gridster.serialize());
        // console.log(JSON.stringify(this.dialog.dashboardsModel.toJSON()));

        var self = this;
        var file = this.filePath;
        var objPanels = this.dialog.dashboardsModel.toJSON();
        var success = function(data, textStatus, jqXHR) {
            if (textStatus && textStatus.status === 500 && textStatus.responseText) {
                alert(textStatus.responseText);
            }
            else {
                self.close();
            }
            return true;
        };
        var error = function(data, textStatus, jqXHR) {
            if (textStatus && textStatus.status === 403 && textStatus.responseText) {
                alert(textStatus.responseText);
            }
            else {
                self.close();
            }
            return true;
        };

        file = file.length > 4 && file.indexOf('.sdb') === file.length - 4 ? file : file + '.sdb';

        // Rename tab
        this.dialog.tab.$el.find('.saikutab').text(file.replace(/^.*[\\\/]/, '').split('.')[0]);

        // Trigger event when create grids
        this.dialog.trigger('showDashboards:open', { file: file });

        (new SavedQuery({
            name: file,
            file: file,
            content: JSON.stringify(objPanels)
        })).save({}, { success: success, error: error, dataType: 'text' });
    }
});
