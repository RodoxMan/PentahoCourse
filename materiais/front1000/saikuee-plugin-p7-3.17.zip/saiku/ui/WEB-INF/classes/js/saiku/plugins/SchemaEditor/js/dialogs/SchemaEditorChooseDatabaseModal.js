/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorChooseDatabaseModal = Modal.extend({
  type: 'schema-editor',

  message: '<form onsubmit="return false;">' +
             '<div class="form-group">' +
               '<label for="databases-available" class="i18n">Databases Available:</label>' +
               '<select class="form-control" id="databases-available"></select>' +
             '</div>' +
             '<div class="form-group">' +
               '<label for="database-schema" class="i18n">Database Schema:</label>' +
               '<select class="form-control" id="database-schema" disabled></select>' +
             '</div>' +
           '</form>',

  buttons: [
    { text: 'Save', method: 'save' },
    { text: 'Cancel', method: 'close' }
  ],

  events: {
    'click .dialog_footer a'      : 'call',
    'change #databases-available' : 'get_schema'
  },

  MODAL_TITLE: 'Choose Database',

  initialize: function(args) {
    _.extend(this, args);

    var self = this;

    this.options.title = this.MODAL_TITLE;

    this.bind('open', function() {
      var $optionsDB = self.option_template({ data: self.databases });

      self.$el.find('.dialog_body').css({
        'padding': '20px'
      });

      self.$el.find('#databases-available').empty();
      self.$el.find('#databases-available').append($optionsDB);
    });
  },

  option_template: function(obj) {
    return _.template(
      '<option value="">-- Select --</option>' +
      '<% _.each(obj.data, function(entry) { %>' +
        '<option value="<%= entry %>"><%= entry %></option>' +
      '<% }); %>'
    )(obj);
  },

  set_modal_title: function(name) {
    var title = name || this.MODAL_TITLE;

    this.$el.parents('.ui-dialog').find('.ui-dialog-title').text(title);
  },

  get_schema: function(event) {
    event.preventDefault();

    var self = this;
    var $currentTarget = $(event.currentTarget);
    var database = $currentTarget.val();
    var dbSchemas = new SchemaEditorDBSchemaModel({}, { database: database });
    var $optionsSchema;

    if (database) {
      dbSchemas.fetch({
        success: function(model, response) {
          $optionsSchema = self.option_template({ data: model.attributes });
          self.$el.find('#database-schema').empty();
          self.$el.find('#database-schema').prop('disabled', false);
          self.$el.find('#database-schema').append($optionsSchema);
        },
        error: function(model, response) {
          console.error(response.statusText);
        }
      });
    }
    else {
      this.$el.find('#database-schema').empty();
      this.$el.find('#database-schema').prop('disabled', true);
    }
  },

  get_jdbc_type() {
    var regexp = /jdbc:mysql:|jdbc:postgresql:|jdbc:oracle:|jdbc:drill:|jdbc:jtds:sqlserver:/i;
    var jdbcUrl = this.jdbcUrl;
    var jdbcTypes = {
      'mysql'      : false,
      'postgresql' : true,
      'oracle'     : true,
      'drill'      : true,
      'mssql'      : true
    };
    var db = {};
    var dbName;

    if (!!jdbcUrl.match(regexp)) {
      dbName = jdbcUrl.match(regexp)[0].split(':')[1];
      db[dbName] = jdbcTypes[dbName];

      return db;
    }

    return db;
  },

  save: function(event) {
    event.preventDefault();

    var self = this;
    var database = this.$el.find('#databases-available').val();
    var schema = this.$el.find('#database-schema').val();
    var dbTables = new SchemaEditorDBTablesModel({}, { database: database, schema: schema });
    var alertMsg = '';

    if (_.isEmpty(database)) {
      alertMsg += '<li>You have to choose a Database Available!</li>';
    }
    if (_.isEmpty(schema)) {
      alertMsg += '<li>You have to choose a Database Schema!</li>';
    }
    if (alertMsg !== '') {
      (new WarningModal({
          title: '<span class="i18n">Required Fields</span>',
          message: '<ul>' + alertMsg + '</ul>'
      })).render().open();

      this.$el.parents('.ui-dialog').find('.ui-dialog-title').text('Choose Database');
    }
    else {
      dbTables.fetch({
        success: function(model, response, options) {
          var database = model.database;

          if (response && response.tables.length > 0) {
            (new SchemaEditor({
              action: self.action,
              dataSourceName: self.dataSourceName,
              data: {
                database: database,
                schema: schema,
                tables: response.tables,
                databaseType: self.get_jdbc_type()
              },
              connectionType: 'DB',
              adminConsole: self.adminConsole
            })).render().open();

            self.$el.dialog('close');
          }
          else {
            (new WarningModal({
              title: '<span class="i18n">Warning</span>',
              message: '<p class="i18n">The <b>'+ database +'</b> database is empty!</p>'
            })).render().open();

            self.set_modal_title();
          }
        },
        error: function(model, response) {
          console.error(response.statusText);
        }
      });
    }
  }
});
