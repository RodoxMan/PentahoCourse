/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorCSVMetadataModel = Backbone.Model.extend({
  url: function() {
    return 'api/csv/metadata/' + this.dataSourceName;
  },

  initialize: function(args, options) {
    this.schemaMock = new SchemaEditorSchemaMock();

    if (options && options.dialog) {
      this.dialog = options.dialog;
      this.pluginName = options.pluginName;
      this.dataSourceName = options.dataSourceName;
    }
  },

  parse: function(response) {
    if (this.pluginName === 'admin-console') {
      this.setCSVSchemaModel(response);
    }
    else {
      // if `this.pluginName` is equals the 'schema-editor'
      this.setCSVSchemaEditModel(response);
    }

    Saiku.ui.block('<span class="i18n">Loading...</span>');

    if (this.dialog) {
      if (this.pluginName === 'admin-console') {
        this.dialog.schemaeditor_populate(response);
      }
      else {
        // if `this.pluginName` is equals the 'schema-editor'
        this.dialog.populate(response);
      }
    }
  },

  setCSVSchemaModel: function(data) {
    var schema = this.schemaMock.getSchema(data);
    var key = _.keys(data)[0];
    var tablesCollection = this.dialog.schemaEditorSchemaModel.get('tables');
    var measuresCollection = this.dialog.schemaEditorSchemaModel.get('measures');
    var dimensionsCollection = this.dialog.schemaEditorSchemaModel.get('dimensions');
    var dimensionCollection;

    // Mock count metric
    // TODO: This mock just works in connection type CSV
    //       If the table is >1, is necessary put this code in
    //       `SchemaEditorSchemaMock.prototype.getSchema`
    var mockMeasureRecordCount = {
      id: _.uniqueId('id_measure_'),
      name: 'Record Count',
      properties: {
        sourceColumn: data[key][0].name,
        defaultAggregation: 'count'
      }
    };

    // console.log(data);

    for (var t = 0, tLen = schema.tables.length; t < tLen; t++) {
      // Add table
      tablesCollection.add(new SchemaEditorTablesModel(schema.tables[t]));
    }

    for (var m = 0, mLen = schema.measures.length; m < mLen; m++) {
      // Add measure
      measuresCollection.add(new SchemaEditorMeasuresModel(schema.measures[m]));
    }

    // Add count metric to automatic schema generation
    measuresCollection.add(new SchemaEditorMeasuresModel(mockMeasureRecordCount));

    for (var d = 0, dLen = schema.dimensions.length; d < dLen; d++) {
      // Add dimension
      dimensionsCollection.add(new SchemaEditorDimensionsModel(schema.dimensions[d].dimension));

      // Add attribute
      dimensionCollection = dimensionsCollection.get(schema.dimensions[d].dimension.id);
      dimensionCollection.attribute.add(new SchemaEditorAttributeModel(schema.dimensions[d].attribute));
    }
  },

  setCSVSchemaEditModel: function(data) {
    var schema = this.schemaMock.getSchema(data);
    var key = _.keys(data)[0];
    var tablesCollection = this.dialog.schemaEditorSchemaModelClone.get('tables');
    var measuresCollection = this.dialog.schemaEditorSchemaModelClone.get('measures');
    var dimensionsCollection = this.dialog.schemaEditorSchemaModelClone.get('dimensions');
    var dimensionCollection;

    // Mock count metric
    var mockMeasureRecordCount = {
      id: _.uniqueId('id_measure_'),
      name: 'Record Count',
      properties: {
        sourceColumn: data[key][0].name,
        defaultAggregation: 'count'
      }
    };

    // console.log(data);

    for (var t = 0, tLen = schema.tables.length; t < tLen; t++) {
      // Add table
      tablesCollection.add(new SchemaEditorTablesModel(schema.tables[t]));
    }

    for (var m = 0, mLen = schema.measures.length; m < mLen; m++) {
      // Add measure
      measuresCollection.add(new SchemaEditorMeasuresModel(schema.measures[m]));
    }

    // Add count metric to automatic schema generation
    measuresCollection.add(new SchemaEditorMeasuresModel(mockMeasureRecordCount));

    for (var d = 0, dLen = schema.dimensions.length; d < dLen; d++) {
      // Add dimension
      dimensionsCollection.add(new SchemaEditorDimensionsModel(schema.dimensions[d].dimension));

      // Add attribute
      dimensionCollection = dimensionsCollection.get(schema.dimensions[d].dimension.id);
      dimensionCollection.attribute.add(new SchemaEditorAttributeModel(schema.dimensions[d].attribute));
    }
  }
});

var SchemaEditorCSVMetadataEditModel = Backbone.Model.extend({
  url: function() {
    return 'api/mondrian2/' + this.dataSourceName;
  },

  initialize: function(args, options) {
    this.schemaMock = new SchemaEditorSchemaMock();

    if (options && options.dialog) {
      this.dialog = options.dialog;
      this.dataSourceName = options.dataSourceName;
    }
  },

  parse: function(response) {
    this.setCSVSchemaModel(response);

    Saiku.ui.block('<span class="i18n">Loading...</span>');

    if (this.dialog) {
      this.dialog.populate_edit(response);
    }
  },

  setCSVSchemaModel: function(data) {
    var schema = data;
    var factTable = schema.factTable;
    var tablesCollection = this.dialog.schemaEditorSchemaModel.get('tables');
    var measuresCollection = this.dialog.schemaEditorSchemaModel.get('measures');
    var dimensionsCollection = this.dialog.schemaEditorSchemaModel.get('dimensions');
    var dimensionCollection;
    var hierarchyCollection;

    // console.log(data);

    tablesCollection.reset();
    measuresCollection.reset();
    dimensionsCollection.reset();

    this.dialog.schemaEditorSchemaModel.set({ factTable: factTable });
    this.dialog.select_current_fact_table(factTable);

    for (var t = 0, tLen = schema.tables.length; t < tLen; t++) {
      // Add table
      tablesCollection.add(new SchemaEditorTablesModel(schema.tables[t]));
    }

    for (var m = 0, mLen = schema.measures.length; m < mLen; m++) {
      // Add measure
      measuresCollection.add(new SchemaEditorMeasuresModel(schema.measures[m]));
    }

    for (var d = 0, dLen = schema.dimensions.length; d < dLen; d++) {
      // Add dimension
      var dataSchemaDimension = this.schemaMock.schemaDimension(schema.dimensions[d]);
      dimensionsCollection.add(new SchemaEditorDimensionsModel(dataSchemaDimension.dimension));

      for (var a = 0, aLen = schema.dimensions[d].attribute.length; a < aLen; a++) {
        // Add attribute
        var dataSchemaAttribute = this.schemaMock.schemaAttribute(schema.dimensions[d].attribute[a]);
        dimensionCollection = dimensionsCollection.get(schema.dimensions[d].id);
        dimensionCollection.attribute.add(new SchemaEditorAttributeModel(dataSchemaAttribute));
      }

      for (var h = 0, hLen = schema.dimensions[d].hierarchy.length; h < hLen; h++) {
        // Add hierarchy
        var dataSchemaHierarchy = this.schemaMock.schemaHierarchy(schema.dimensions[d].hierarchy[h]);
        dimensionCollection = dimensionsCollection.get(schema.dimensions[d].id);
        dimensionCollection.hierarchy.add(new SchemaEditorHierarchyModel(dataSchemaHierarchy));

        for (var l = 0, lLen = schema.dimensions[d].hierarchy[h].level.length; l < lLen; l++) {
          // Add level
          var dataSchemaLevel = this.schemaMock.schemaLevel(schema.dimensions[d].hierarchy[h].level[l]);
          hierarchyCollection = dimensionCollection.hierarchy.get(schema.dimensions[d].hierarchy[h].id);
          hierarchyCollection.level.add(new SchemaEditorLevelModel(dataSchemaLevel));
        }
      }
    }
  }
});
