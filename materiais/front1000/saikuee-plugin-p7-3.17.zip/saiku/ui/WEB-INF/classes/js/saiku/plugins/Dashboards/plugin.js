/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * @module Saiku
 * @submodule Dashboards
 */
Saiku.Dashboards = {
    show: function() {
        Saiku.tabs.add(new Dashboards());
        return false;
    }
};

/**
 * Class that show reports and collections of sub reports on a single screen
 *
 * @class Dashboards
 */
var Dashboards = Backbone.View.extend({
    /**
     * Class name of element `<div>`
     *
     * @property className
     * @type {String}
     * @private
     */
    className: 'dashboards',

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        // 'click .sidebar_separator'          : 'toggle_sidebar',
        'click .toggle-sidebar-filter'      : 'toggle_sidebar_filter',
        'click .workspace_inner'            : 'hide_sidebar_filter',
        'click .sidebar'                    : 'hide_sidebar_filter',
        'click .folder_content > li.folder' : 'hide_sidebar_filter',
        'click .folder_content > li.query'  : 'hide_sidebar_filter',
        'keyup .search_file2'               : 'search_file',
        'click .cancel_search'              : 'cancel_search',
        'click li.folder'                   : 'toggle_folder',
        'click .toolbar-action-item'        : 'menu_action_item',
        'click .query'                      : 'view_query',
        'click .context-menu-options'       : 'context_menu_options',
        'change #type-filter'               : 'type_filter',
        'click #create-list-filter'         : 'create_list_filter',
        'click #lookup-filter'              : 'lookup_filter',
        'click #select-report-filter'       : 'select_report_filter',
        'keyup .name-filter'                : 'remove_filter_error',
        'change .type-filter'               : 'remove_filter_error',
        'click .content-type-filter'        : 'remove_filter_error',
        'click #save-filter'                : 'save_filter',
        'click #remove-filter'              : 'remove_filter'
    },

    /**
     * Subtitle Tab with name of `file.sdb` or `Unsaved dashboard`
     *
     * @method caption
     * @private
     * @return {String} Subtitle Tab
     */
    caption: function() {
        if (this.openDashboards) {
            return this.openFileName.split('.')[0];
        }
        else {
            return '<span class="i18n">Unsaved dashboard</span> (' + (Saiku.tabs.dashCount) + ')';
        }
    },

    /**
     * Method with main template of view
     *
     * @method template
     * @private
     * @return {String} HTML template
     */
    template: function() {
        return _.template(
            '<div class="workspace" style="margin-left: -305px">' +
                '<div class="workspace_inner" style="margin-left: 305px">' +
                    '<div class="workspace_toolbar">' +
                        '<ul>' +
                            '<li class="toolbar-action-item" data-action="open-dashboards"><a href="#open_dashboards" class="i18n open button sprite" title="Open Dashboards"></a></li>' +
                            '<li class="toolbar-action-item" data-action="save-dashboards"><a href="#save_dashboards" class="i18n save button disabled sprite" title="Save Dashboards"></a></li>' +
                            '<li class="seperator toolbar-action-item" data-action="new-dashboards"><a href="#new_dashboards" class="i18n new button sprite" title="New Dashboards"></a></li>' +
                            '<li class="seperator toolbar-action-item" data-action="create-widget"><a href="#create_widget" class="i18n create-widget disabled button" title="Create Widget"></a></li>' +
                            '<li class="toolbar-action-item" data-action="show-dashboards"><a href="#show_dashboards" class="i18n show-dashboards disabled button" title="Show Dashboards"></a></li>' +
                            // '<li class="seperator toolbar-action-item" data-action="easteregg"><a href="#easteregg" class="i18n easteregg button" title="Promotion Code"></a></li>' +
                            '<li class="seperator hide toolbar-action-item" style="list-style: none;" data-action="debug"><a href="#debug" class="i18n debug button">Debug</a></li>' +
                        '</ul>' +
                        '<ul style="float: right">' +
                            '<li class="toolbar-action-item" data-action="help-dashboards"><a href="#help" class="i18n help button" title="Help Wiki"></a></li>' +
                        '</ul>' +
                    '</div>' +
                    '<div class="sidebar-filter">' +
                        '<a class="toggle-sidebar-filter" href="#toggle_sidebar_filter"></a>' +
                        '<form class="form-group">' +
                            '<label for="name-filter" class="i18n">Name:</label>' +
                            '<input type="text" class="name-filter" id="name-filter">' +
                            '<span class="error filter-err-1 i18n" hidden>This field is required</span><br>' +
                            '<label for="type-filter" class="i18n">Type:</label>' +
                            '<select class="type-filter" id="type-filter">' +
                                '<option value="" class="i18n">-- Select --</option>' +
                                '<option value="radioButton" class="i18n">Radio button</option>' +
                                '<option value="textBox" class="i18n">Text box</option>' +
                                '<option value="dropdown" class="i18n">Dropdown Default</option>' +
                                '<option value="dropdownMultiselect" class="i18n">Dropdown Multiselect</option>' +
                            '</select>' +
                            '<span class="error filter-err-2 i18n" hidden>This field is required</span><br>' +
                            '<h3>Content</h3>' +
                            '<label><input type="radio" name="content-type-filter" class="i18n content-type-filter" id="create-list-filter" value="createList"> Create List</label>' +
                            '<label><input type="radio" name="content-type-filter" class="i18n content-type-filter" id="lookup-filter" value="lookup"> Lookup</label>' +
                            '<span class="error filter-err-3 i18n" hidden>This field is required</span><br>' +
                            '<h3>Link Filter</h3>' +
                            '<a class="form_button btn btn-default i18n" id="select-report-filter">Select Report and Parameter</a>' +
                            '<div class="group-link-filters">' +
                                '<ol></ol>' +
                            '</div>' +
                            '<div class="form-buttons">' +
                                '<a class="form_button btn btn-default i18n" id="save-filter">Save</a>' +
                                '<a class="form_button btn btn-default hide i18n" id="remove-filter">Remove</a>' +
                            '</div>' +
                        '</form>' +
                    '</div>' +
                    '<div class="workspace_results">' +
                        '<div class="dashboard-title edit-mode hide"><h1 class="i18n" data-text="Double clicking to add a title"></h1></div>' +
                        '<div class="grids-view"></div>' +
                    '</div>' +
                '</div>' +
            '</div>' +

            '<div class="sidebar queries" style="width: 300px">' +
            '<h3 class="top" style="padding-top:3px;padding-bottom:2px;">'+
            '<div class="form-inline">'+
            '<label class="i18n">Search:</label> &nbsp;'+
            '<input type="text" class="search_file2 form-control" style="padding-right:0px"></input>'+
            '<span class="cancel_search"></span>'+
            '</div>'+
            '</h3>'+
                '<div class="sidebar_inner">' +
                    '<ul id="queries" class="RepositoryObjects">' +
                        '<li class="i18n">Loading...</li>' +
                    '</ul>' +
                '</div>' +
            '</div>' +

            '<div class="sidebar_separator"></div>' +
            '<div class="clear"></div>'
        );
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        var self = this;
        var server = '/saiku';
        var path = '/rest/saiku/embed';
        this.pluginName = 'dashboards';
        this.numberRows = this.numberRows || 3;
        this.numberCols = this.numberCols || 3;

        // Google Analytics
        if (ga !== undefined) {
            ga('send', 'event', 'DashboardDesigner', 'Open');
        }

        // Maintain `this` in callbacks
        _.bindAll(this, 'repo_open_dashboards', 'adjust', 'fetch_queries', 'disable_workspace_toolbar', 'show_dashboards', 'generate_grids_reports');

        Saiku.ui.unblock();

        // Initialize dashboards model
        this.dashboardsModel = new DashboardsModel({
            // title: 'My Dashboard',
            panels: new PanelsModel(),
            filters: new FiltersCollection()
        });

        // Generate toolbar and append to workspace
        this.toolbar = new WorkspaceToolbar({ workspace: this });
        this.toolbar.render();

        // Initialize repository
        this.repository = new Repository({}, { dialog: this, type: 'saiku' });

        // If Saiku open in Pentaho BI Server, set new `server` and `path`
        if (Settings.BIPLUGIN) {
            server = '/pentaho';
            path = '/plugin/saiku/api/embed';
        }

        // Initialize saiku client
        this.saikuClient = new SaikuClient({
            server: server,
            path: path,
            user: null,
            password: null,
            dashboards: true,
            blockUI: true
        });

        // Listen to result event
        Saiku.session.bind('openQuery:open_query', this.repo_open_dashboards);
        this.bind('workspaceToolbar:disable', this.disable_workspace_toolbar);
        this.bind('showDashboards:open', this.show_dashboards);
    },

    /**
     * Method that will load template into the view's `el` property using jQuery
     *
     * @method render
     * @private
     */
    render: function() {
        var self = this;

        // Load template
        this.$el.html(this.template());

        // If new dashboards
        if (this.newDashboards) {
            var generateGrids = new GenerateGridsDashboards({
                dialog: this,
                numberRows: this.numberRows,
                numberCols: this.numberCols
            });
            generateGrids.render();
            this.$el.find('.grids-view').html(generateGrids.el);

            setTimeout(function() {
                self.panel_gridster();
            }, 100);

            // Trigger event when create grids
            this.trigger('workspaceToolbar:disable', { dialog: this });
            Saiku.i18n.translate();
        }
        // If load a layout
        else if (this.newLayouts) {
            this.$el.find('.grids-view').empty();
            this.$el.find('.grids-view').append(this.$gridster);
            this.$el.find('.grids-view').find('.gridster').find('ul').append(this.$list);

            setTimeout(function() {
                self.panel_gridster();
            }, 100);

            this.$el.find('.dashboard-title').show();

            // Trigger event when create grids
            this.trigger('workspaceToolbar:disable', { dialog: this });
        }

        // If open dashboards (.sdb)
        if (!this.openDashboards && !this.newDashboards && !this.newLayouts) {
            (new OptionsDashboardsModal({ dialog: this })).render().open();
        }
        else {
            var repositoryObject = new RepositoryObject({}, { dialog: this, file: this.openFilePath });
            repositoryObject.fetch();
            this.disable_workspace_toolbar();
            this.show_dashboards({ file: this.openFilePath });
            // console.log(this.dashboardsModel.toJSON());
        }

        // Easter Egg that show/hide promotion code
        var url = window.location.origin;
        url = url.indexOf('try');
        if (url !== -1) {
            this.$el.find('.workspace_toolbar ul').find('li .easteregg').hide();
        }

        // Add in url ?debug=true for mode debug (see console of browser)
        var paramsURI = Saiku.URLParams.paramsURI();
        if (_.has(paramsURI, 'debug')) {
            this.$el.find('.workspace_toolbar ul').find('li .debug').parent().show();
        }

        // Adjust tab when selected
        this.tab.bind('tab:select', this.fetch_queries);
        this.tab.bind('tab:select', this.adjust);
        $(window).resize(this.adjust);

        if (Settings.REPOSITORY_LAZY) {
            this.$el.find('.search_file').prop('disabled', true);
        }
    },

    /**
     * Open .sdb files from the repo browser
     *
     * @method repo_open_dashboards
     * @public
     * @param  {Object} args File Properties
     */
    repo_open_dashboards: function(args) {
        if (args.item.fileType === 'sdb') {
            if (args.viewState === 'edit') {
                Saiku.tabs.add(new Dashboards({
                    openDashboards: true,
                    openFilePath: args.item.path,
                    openFileName: args.item.name
                }));
            }
            else {
                Saiku.tabs.add(new DashboardViewTab({ file: args.item.path }));
            }
        }
    },

    /**
     * Repository with files of dashboards
     *
     * @method template_repository_objects
     * @private
     * @param  {Object} repository Files of querys (.saiku)
     */
    template_repository_objects: function(repository) {
        this.$el.find('.sidebar_inner ul').html(
            _.template($('#template-repository-objects').html())({
                repoObjects: repository
            })
        );
    },

    /**
     * Adjust resize workspace of dashboards
     *
     * @method adjust
     * @public
     */
    adjust: function() {
        // Adjust the height of the separator
        $separator = this.$el.find('.sidebar_separator');
        $separator.height($('body').height() - 87);
        this.$el.find('.sidebar').css({ 'width': 300, 'height': $('body').height() - 87 });
        this.$el.find('.workspace_inner').css({ 'margin-left': 305 });
        this.$el.find('.workspace').css({ 'margin-left': -305 });
        // Adjust the dimensions of the results window
        this.$el.find('.workspace_results').css({
            width: $(document).width() - this.$el.find('.sidebar').width() - 30,
            height: $(document).height() - $('#header').height() -
                this.$el.find('.workspace_toolbar').height() -
                this.$el.find('.workspace_fields').height() - 40
        });
    },

    /**
     * Toggle sidebar of repository
     *
     * @method toggle_sidebar
     * @private
     */
    toggle_sidebar: function() {
        // Toggle sidebar
        this.$el.find('.sidebar').toggleClass('hide');
        this.toolbar.$el.find('.toggle_sidebar').toggleClass('on');
        var calculatedMargin =
                (this.$el.find('.sidebar').is(':visible') ? this.$el.find('.sidebar').width() : 0) +
                (this.$el.find('.sidebar_separator').width()) + 1;
        var new_margin = calculatedMargin;
        this.$el.find('.workspace_inner').css({ 'margin-left': new_margin });
    },

    /**
     * Toggle sidebar of filter
     *
     * @method toggle_sidebar_filter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    toggle_sidebar_filter: function(event) {
        if (event) { event.preventDefault(); }
        if (this.$el.find('.sidebar-filter').hasClass('on')) {
            this.$el.find('.sidebar-filter').find('form').removeData('htmlobject');
            this.$el.find('.sidebar-filter').find('form').removeData('parameter');
            this.$el.find('.sidebar-filter').removeClass('on');
            this.$el.find('.sidebar-filter').find('form').find('#name-filter').val('');
            this.$el.find('.sidebar-filter').find('form').find('#type-filter').prop('selectedIndex', 0);
            this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').prop('disabled', false);
            this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').prop('checked', false);
            this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').prop('checked', false);
            this.$el.find('.sidebar-filter').find('form').find('.group-link-filters > ol').empty();
            this.$el.find('.sidebar-filter').find('form').find('.error').hide();
            this.$el.find('.sidebar-filter').find('form').find('#remove-filter').hide();
            this.$el.find('.sidebar-filter').toggle('slide');
        }
    },

    /**
     * Hide sidebar of filter
     *
     * @method hide_sidebar_filter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    hide_sidebar_filter: function(event) {
        var $target = $(event.target);
        if ($target.attr('class') !== 'sidebar-filter on' &&
            $target.closest('.sidebar-filter').attr('class') !== 'sidebar-filter on') {
            this.toggle_sidebar_filter(event);
        }
    },

    /**
     * Get repositorys
     *
     * @method fetch_queries
     * @public
     */
    fetch_queries: function() {
        this.repository.fetch();
    },

    /**
     * Populate folders with files of dashboards
     *
     * @method populate
     * @private
     * @param  {Object} repository Files of querys (.saiku)
     */
    populate: function(repository) {
        var self = this;
        this.template_repository_objects(repository);
        this.queries = {};
        function getQueries(entries) {
            _.each(entries, function(entry) {
                self.queries[entry.path] = entry;
                if (entry.type === 'FOLDER') {
                    getQueries(entry.repoObjects);
                }
            });
        }
        getQueries(repository);
        this.context_menu_disabled();
        this.draggable_file();
    },

    /**
     * Get action of toolbar
     *
     * @method menu_action_item
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    menu_action_item: function(event) {
        event.preventDefault();

        var $currentTarget = $(event.currentTarget);

        switch ($currentTarget.data('action')) {
        case 'open-dashboards':
            (new OpenDashboardsModal({ dialog: this })).render().open();
            break;

        case 'save-dashboards':
            if (!($currentTarget.find('.save').hasClass('disabled'))) {
                (new SaveDashboardsModal({ dialog: this })).render().open();
            }
            break;

        case 'new-dashboards':
            (new OptionsDashboardsModal({ dialog: this })).render().open();
            break;

        case 'create-widget':
            if (!($currentTarget.find('.create-widget').hasClass('disabled'))) {
                (new CreateWidgetDashboardsModal({ dialog: this })).render().open();
            }
            break;

        case 'show-dashboards':
            if (!($currentTarget.find('.show-dashboards').hasClass('disabled'))) {
                var host = window.location.origin;
                var file = $currentTarget.data('file');
                //window.open(host + '/embed/dashboard.html?file=' + file);
                Saiku.tabs.add(new DashboardViewTab({ file: file }));
            }
            break;

        case 'easteregg':
            var url = window.location.origin;
            url = url.indexOf('try');
            if (url === -1) {
                (new EasterEggDashboardsModal()).render().open();
            }
            break;

        case 'debug':
            console.log(this);
            console.log(this.dashboardsModel);
            console.log(this.dashboardsModel.get('filters').toJSON());
            console.log(JSON.stringify(this.dashboardsModel.toJSON()));
            console.log(JSON.stringify(this.gridster.serialize()));
            break;

        case 'help-dashboards':
            window.open('http://wiki.meteorite.bi/display/SAIK/Dashboards');
            break;
        }

        return false;
    },

    /**
     * Method that drag a file for a widget
     *
     * @method draggable_file
     * @private
     */
    draggable_file: function() {
        var self = this;
        this.$el.find('.queries').find('.query').draggable({
            appendTo: 'body',
            containment: '.workspace',
            cursorAt: { top: 10, left: 85 },
            helper: 'clone',
            opacity: 0.60,
            scroll: false,
            start: function() {
                self.toggle_sidebar_filter();
            }
        });
    },

    /**
     * Method for search a file
     *
     * @method search_file
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    search_file: function(event) {
        var filter = this.$el.find('.search_file2').val().toLowerCase();
        var isEmpty = (typeof filter === undefined || filter === '' || filter === null);

        if (isEmpty || event.which === 27 || event.which === 9) {
            this.cancel_search();
        }
        else {
            if (this.$el.find('.search_file').val()) {
                this.$el.find('.cancel_search').show();
            }
            else {
                this.$el.find('.cancel_search').hide();
            }

            this.$el.find('li.query').removeClass('hide');
            this.$el.find('li.query a').each(function(index) {
                if ($(this).text().toLowerCase().indexOf(filter) === -1) {
                    $(this).parent('li.query').addClass('hide');
                }
            });

            this.$el.find('li.folder').addClass('hide');
            this.$el.find('li.query').not('.hide').parents('li.folder').removeClass('hide');
            this.$el.find('li.folder .folder_row').find('.sprite').removeClass('collapsed');
            this.$el.find('li.folder .folder_content').removeClass('hide');
        }

        return false;
    },

    /**
     * Method for cancel a search
     *
     * @method cancel_search
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    cancel_search: function(event) {
        this.$el.find('input.search_file').val('');
        this.$el.find('.cancel_search').hide();
        this.$el.find('li.query, li.folder').removeClass('hide');
        this.$el.find('.folder_row').find('.sprite').addClass('collapsed');
        this.$el.find('li.folder .folder_content').addClass('hide');
        this.$el.find('.search_file').val('').focus();
        this.$el.find('.cancel_search').hide();
    },

    /**
     * Toggle folder with repository files
     *
     * @method toggle_folder
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    toggle_folder: function(event) {
        var $currentTarget = $(event.currentTarget);
        var path = $currentTarget.children('.folder_row').find('a').attr('href');

        path = path.replace('#', '');
        this.unselect_current_selected();
        $currentTarget.children('.folder_row').addClass('selected');

        var $queries = $currentTarget.children('.folder_content');
        var isClosed = $currentTarget.children('.folder_row').find('.sprite').hasClass('collapsed');

        if (isClosed) {
            $currentTarget.children('.folder_row').find('.sprite').removeClass('collapsed');
            $queries.removeClass('hide');
            if (Settings.REPOSITORY_LAZY) {
                this.fetch_lazyload($currentTarget, path);
            }
        }
        else {
            $currentTarget.children('.folder_row').find('.sprite').addClass('collapsed');
            $queries.addClass('hide');
            if (Settings.REPOSITORY_LAZY) {
                $currentTarget.find('.folder_content').remove();
            }
        }

        return false;
    },

    fetch_lazyload: function(target, path) {
        var repositoryLazyLoad = new RepositoryLazyLoad({}, { dialog: this, folder: target, path: path });
        repositoryLazyLoad.fetch();
        Saiku.ui.block('Loading...');
    },

    template_repository_folder_lazyload: function(folder, repository) {
        folder.find('.folder_content').remove();
        folder.append(
            _.template($('#template-repository-folder-lazyload').html())({
                repoObjects: repository
            })
        );
        this.draggable_file();

    },

    populate_lazyload: function(folder, repository) {
        Saiku.ui.unblock();
        this.template_repository_folder_lazyload(folder, repository);
    },

    /**
     * Unselect current selected
     *
     * @method unselect_current_selected
     * @private
     */
    unselect_current_selected: function() {
        this.$el.find('.selected').removeClass('selected');
    },

    /**
     * View query
     *
     * @method view_query
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    view_query: function(event) {
        event.preventDefault();
        var $currentTarget = $(event.currentTarget);
        return false;
    },

    /**
     * Disable buttons of toolbar
     *
     * @method disable_workspace_toolbar
     * @public
     */
    disable_workspace_toolbar: function() {
        this.$el.find('.workspace_toolbar').find('.toolbar-action-item')
            .find('.save, .create-widget').removeClass('disabled');
    },

    /**
     * Method that remove class `.disabled` and set path of file in icon for show dashboards
     *
     * @method show_dashboards
     * @public
     * @param  {Object} args Path of file
     */
    show_dashboards: function(args) {
        this.$el.find('.workspace_toolbar').find('.toolbar-action-item')
            .find('.show-dashboards').removeClass('disabled');

        this.$el.find('.workspace_toolbar').find('.toolbar-action-item')
            .find('.show-dashboards').parent().data('file', args.file);
    },

    /**
     * Edit dashboard title
     *
     * @method dashboard_title_editable
     * @private
     */
    dashboard_title_editable: function() {
        var self = this;
        this.$el.find('.dashboard-title > h1').editable({
            callback: function(data) {
                if (data.content !== false && data.content !== '') {
                    self.dashboardsModel.set({ title: data.content });
                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                    // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                }
                else {
                    self.dashboardsModel.set({ title: '' });
                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                    // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                }
            }
        });
    },

    /**
     * Method that calculate widget dimensions
     *
     * @method widget_dimensions
     * @private
     * @return {Object} Widget dimensions (width and height)
     */
    widget_dimensions: function() {
        var maxCols = 6;
        var widgetMargin = 15;
        var maxWidth = this.$el.find('.gridster ul').width();
        return {
            width: Math.floor((maxWidth / maxCols) - (widgetMargin * 2)),
            height: 100
        }
    },

    /**
     * Gridster is a jQuery plugin that allows building intuitive draggable
     * layouts from elements spanning multiple columns
     *
     * @method panel_gridster
     * @private
     * @return {Object} Gridster properties
     */
    panel_gridster: function() {
        var self = this;
        this.gridster = this.$el.find('.gridster ul').gridster({
            autogrow_cols: true,
            widget_margins: [15, 15],
            widget_base_dimensions: [this.widget_dimensions().width, this.widget_dimensions().height],
            max_cols: 6,
            min_cols: 1,
            serialize_params: function($w, wgd) {
                return {
                    /* new elements */
                    id: $w.data('htmlobject') || '',
                    title: $w.data('title') || 'Widget',
                    file: $w.data('file') || '',
                    htmlObject: $w.data('htmlobject') || '',
                    render: $w.data('render') || '',
                    mode: $w.data('mode') || '',
                    chartDefinition: $w.data('chartDefinition') || '',
                    mapDefinition: $w.data('mapDefinition') || '',
                    parametersLevels: $w.data('parametersLevels') || '',
                    parametersValues: $w.data('parametersValues') || '',
                    /* defaults */
                    col: wgd.col,
                    row: wgd.row,
                    size_x: wgd.size_x,
                    size_y: wgd.size_y
                }
            },
            draggable: {
                stop: function() {
                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                    // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                }
            },
            resize: {
                enabled: true,
                stop: function(e, ui, $widget) {
                    if ($widget.data('render') === 'chart') {
                        self.saikuClient.execute({
                            file: $widget.data('file'),
                            htmlObject: $widget.data('htmlobject'),
                            render: 'chart',
                            mode: $widget.data('mode'),
                            chartDefinition: $widget.data('chartDefinition') ? JSON.parse($widget.data('chartDefinition')) : {},
                            mapDefinition: $widget.data('mapDefinition') ? JSON.parse($widget.data('mapDefinition')) : {},
                            zoom: true
                        });
                    }

                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                    // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                }
            }
        }).data('gridster');

        this.dashboard_title_editable();
        this.panel_title_editable();
        this.panel_droppable();

        return this.gridster;
    },

    /**
     * Edit panel title
     *
     * @method panel_title_editable
     * @private
     */
    panel_title_editable: function() {
        var self = this;
        var htmlObject;
        this.$el.find('.gridster').find('.panel-title > h3').editable({
            emptyMessage: 'Widget',
            callback: function(data) {
                if (data.content !== false && data.content !== '') {
                    htmlObject = data.$el.closest('.gs-w').data('htmlobject');
                    data.$el.closest('.gs-w').data('title', data.content);
                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                    self.rename_linkfilters_report(htmlObject, data.content);
                    // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                }
            }
        });
    },

    /**
     * Method that create targets for draggable elements
     *
     * @method panel_droppable
     * @private
     */
    panel_droppable: function() {
        var self = this;
        this.$el.find('.gridster').find('.panel-body').droppable({
            accept: '.query',
            over: function(event, ui) {
                var $target = $(event.target);
                var fileName = $(ui.helper).find('a').text();

                if ($target.find('table').length === 0 &&
                    $target.find('.canvas_wrapper').length === 0 &&
                    $target.find('div').length === 0) {
                    $target.html('<span>' + fileName + '</span>');
                }
            },
            out: function(event, ui) {
                $(event.target).find('span').remove();
            },
            drop: function(event, ui) {
                var $target = $(event.target);
                var file = ui.helper.find('a')[0].hash.replace('#', '');
                var $htmlObject = '#' + event.target.id;

                self.saikuClient.execute({
                    dropDashboards: true,
                    file: file,
                    htmlObject: $htmlObject,
                    render: 'table'
                });

                self.dashboardsModel.get('panels').set(self.gridster.serialize());
                self.dashboardsModel.get('filters').remove($htmlObject);
                // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                // console.log(JSON.stringify(self.gridster.serialize()));
            }
        });
    },

    /**
     * Check changes in link filters and set render and mode
     *
     * @method change_linkfilters_render
     * @private
     * @param  {String} htmlObject HTML Element
     * @param  {Object} objRender  Type of rendering
     */
    change_linkfilters_render: function(htmlObject, objRender) {
        var objFilters = this.dashboardsModel.get('filters').toJSON();
        var lenFilters = objFilters.length;
        var lenLinkFilters;
        var i, j;

        for (i = 0; i < lenFilters; i++) {
            if (objFilters[i].linkFilters.models.length > 0) {
                lenLinkFilters = _.size(objFilters[i].linkFilters.models[0].attributes);
                for (j = 0; j < lenLinkFilters; j++) {
                    if (objFilters[i].linkFilters.models[0].attributes[j].htmlObject === htmlObject) {
                        if (objRender.render === 'table') {
                            objFilters[i].linkFilters.models[0].attributes[j].render = objRender.render;
                        }
                        else {
                            objFilters[i].linkFilters.models[0].attributes[j].render = objRender.render;
                            objFilters[i].linkFilters.models[0].attributes[j].mode = objRender.mode;
                        }
                    }
                }
            }
        }
    },

    /**
     * Check changes in link filters and set report name
     *
     * @method rename_linkfilters_report
     * @private
     * @param  {String} htmlObject HTML Element
     * @param  {String} report     Report name
     */
    rename_linkfilters_report: function(htmlObject, report) {
        var objFilters = this.dashboardsModel.get('filters').toJSON();
        var lenFilters = objFilters.length;
        var lenLinkFilters;
        var i, j;

        for (i = 0; i < lenFilters; i++) {
            if (objFilters[i].linkFilters.models.length > 0) {
                lenLinkFilters = _.size(objFilters[i].linkFilters.models[0].attributes);
                for (j = 0; j < lenLinkFilters; j++) {
                    if (objFilters[i].linkFilters.models[0].attributes[j].htmlObject === htmlObject) {
                        objFilters[i].linkFilters.models[0].attributes[j].report = report;
                    }
                }
            }
        }
    },

    /**
     * Disabled Context Menu
     *
     * @method context_menu_disabled
     * @private
     */
    context_menu_disabled: function() {
        this.$el.find('.RepositoryObjects').find('.folder_row, .query').addClass('context-menu-disabled');
    },

    /**
     * Context menu options
     *
     * @method context_menu_options
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    context_menu_options: function(event) {
        event.preventDefault();

        var self = this;
        var $widget = $(event.currentTarget).closest('.gs-w');
        var file = $widget.data('file') || undefined;
        var htmlObject = $widget.data('htmlobject');
        var render = $widget.data('render');
        var mode = $widget.data('mode');
        var chartDefinition = $widget.data('chartDefinition');
        var mapDefinition = $widget.data('mapDefinition');
        var parametersLevels = $widget.data('parametersLevels');
        var parametersValues = $widget.data('parametersValues');
        var chartDefinitionMode = {
            'bar'              : 'BarChart',
            'stackedBar'       : 'BarChart',
            'stackedBar100'    : 'NormalizedBarChart',
            'multiplebar'      : 'BarChart',
            'line'             : 'LineChart',
            'area'             : 'StackedAreaChart',
            'heatgrid'         : 'HeatGridChart',
            'treemap'          : 'TreemapChart',
            'sunburst'         : 'SunburstChart',
            'multiplesunburst' : 'SunburstChart',
            'dot'              : 'DotChart',
            'waterfall'        : 'WaterfallChart',
            'pie'              : 'PieChart'
        };

        parametersValues = parametersValues ? JSON.parse(parametersValues) : undefined;

        var menuItems = {
            'renderType': {
                name: 'Render Type',
                disabled: (file ? false : true),
                items: {
                    'renderTypeKey1': {
                        name: 'Table',
                        type: 'radio',
                        radio: 'radio',
                        value: 'renderTypeKey1',
                        selected: (render === 'table' ? true : false),
                        events: {
                            click: function(event) {
                                var $currentTarget = $(event.currentTarget);
                                var $this = $widget.find('.context-menu-options');

                                $this.data('chartOptionsDisabled', false);
                                $currentTarget.closest('.context-menu-item').parent().find('.chart-options').addClass('disabled');
                                self.remove_embed_code(htmlObject);
                                render = 'table';

                                if (file && htmlObject) {
                                    $widget.data('render', 'table');
                                    $widget.data('mode', '');
                                    self.saikuClient.execute({
                                        file: file,
                                        htmlObject: htmlObject,
                                        render: 'table'
                                    });
                                    self.change_linkfilters_render(htmlObject, { render: 'table' });
                                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                                    // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                                }
                            }
                        }
                    },
                    'renderTypeKey2': {
                        name: 'Chart',
                        type: 'radio',
                        radio: 'radio',
                        value: 'renderTypeKey2',
                        selected: (render === 'chart' ? true : false),
                        events: {
                            click: function(event) {
                                var $currentTarget = $(event.currentTarget);
                                var $this = $widget.find('.context-menu-options');
                                var clientData;

                                $this.data('chartOptionsDisabled', true);
                                $currentTarget.closest('.context-menu-item').parent().find('.chart-options').removeClass('disabled');
                                $currentTarget.closest('.context-menu-item').parent().find('.chart-editor').removeClass('disabled');
                                self.remove_embed_code(htmlObject);
                                render = 'chart';
                                mode = 'bar';

                                if (file && htmlObject) {
                                    $widget.data('render', 'chart');
                                    $widget.data('mode', mode);

                                    if (chartDefinition && !(_.isEmpty(chartDefinition))) {
                                        if (_.isString(chartDefinition)) {
                                            chartDefinition = JSON.parse(chartDefinition);
                                        }

                                        if (chartDefinition.type) {
                                            chartDefinition.type = chartDefinitionMode[mode];
                                            $widget.data('chartDefinition', JSON.stringify(chartDefinition));
                                        }
                                    }
                                    else {
                                        chartDefinition = {};
                                    }

                                    clientData = {
                                        file: file,
                                        htmlObject: htmlObject,
                                        render: 'chart',
                                        mode: mode,
                                        chartDefinition: chartDefinition,
                                        zoom: true
                                    };

                                    self.saikuClient.execute(self.client_options('chart', clientData));
                                    self.change_linkfilters_render(htmlObject, { render: 'chart', mode: mode });
                                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                                    // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                                }
                            }
                        }
                    },
                    'renderTypeKey3': {
                        name: 'Map',
                        type: 'radio',
                        radio: 'radio',
                        value: 'renderTypeKey3',
                        selected: (render === 'map' ? true : false),
                        disabled: (Settings.MAPS && Settings.MAPS_TYPE === 'OSM' ? false : true),
                        events: {
                            click: function(event) {
                                var $currentTarget = $(event.currentTarget);
                                var $this = $widget.find('.context-menu-options');

                                $currentTarget.closest('.context-menu-root').hide();

                                if (mapDefinition && !(_.isEmpty(mapDefinition))) {
                                    if (_.isString(mapDefinition)) {
                                        mapDefinition = JSON.parse(mapDefinition);
                                    }
                                }
                                else {
                                    mapDefinition = {};
                                }

                                (new MapEditorDashboardsModal({
                                    dialog: self,
                                    file: file,
                                    htmlObject: htmlObject,
                                    oldRender: render,
                                    mapDefinition: mapDefinition,
                                    currentTarget: $currentTarget,
                                    contextMenuOptions: $this
                                })).render().open();
                            }
                        }
                    },
                    'sep1': '---------',
                    'chartOptions': {
                        name: 'Chart Options',
                        className: 'chart-options',
                        disabled: function(key, opt) {
                            return (render === 'chart' ? false : true);
                        },
                        items: {
                            select: {
                                name: 'Mode',
                                type: 'select',
                                options: { 'bar': 'Bar', 'stackedBar': 'Stacked Bar', 'stackedBar100': 'Bar 100%',
                                           'multiplebar': 'Multiple Bar Chart', 'line': 'Line', 'area': 'Area',
                                           'heatgrid': 'Heat Grid', 'treemap': 'Tree Map', 'sunburst': 'Sunburst',
                                           'dot': 'Dot', 'waterfall': 'Waterfall', 'pie': 'Pie' },
                                selected: (mode ? mode : 'bar'),
                                events: {
                                    change: function(event) {
                                        var $currentTarget = $(event.currentTarget);
                                        var selectedMode = $currentTarget.val();
                                        var clientData;

                                        $widget.data('render', 'chart');
                                        $widget.data('mode', selectedMode);

                                        $currentTarget.closest('.context-menu-item').parent().find('.chart-editor').removeClass('disabled');
                                        self.remove_embed_code(htmlObject);
                                        render = 'chart';
                                        mode = selectedMode;

                                        if (chartDefinition && !(_.isEmpty(chartDefinition))) {
                                            if (_.isString(chartDefinition)) {
                                                chartDefinition = JSON.parse(chartDefinition);
                                            }

                                            if (chartDefinition.type) {
                                                chartDefinition.type = chartDefinitionMode[selectedMode];
                                                $widget.data('chartDefinition', JSON.stringify(chartDefinition));
                                            }
                                        }
                                        else {
                                            chartDefinition = {};
                                        }

                                        clientData = {
                                            file: file,
                                            htmlObject: htmlObject,
                                            render: 'chart',
                                            mode: selectedMode,
                                            chartDefinition: chartDefinition,
                                            zoom: true
                                        };

                                        self.saikuClient.execute(self.client_options('chart', clientData));
                                        self.change_linkfilters_render(htmlObject, { render: 'chart', mode: selectedMode });
                                        self.dashboardsModel.get('panels').set(self.gridster.serialize());
                                        // console.log(JSON.stringify(self.dashboardsModel.toJSON()));
                                    }
                                }
                            },
                            'sep1': '---------',
                            'chart-editor': {
                                name: 'Chart Editor',
                                className: 'chart-editor',
                                disabled: self.is_embed_code(htmlObject)
                            },
                        }
                    }
                }
            },
            'sep1': '---------',
            'filter': {
                name: 'Filter',
                disabled: (parametersValues && !(_.isEmpty(parametersValues)) ? false : true)
            },
            'sep2': '---------',
            'embed-code': {
                name: 'Embed Code',
                disabled: (file ? false : true)
            },
            'sep3': '---------',
            'remove-report': {
                name: 'Remove Report',
                disabled: (file ? false : true)
            },
            'sep4': '---------',
            'remove-widget': {
                name: 'Remove Widget'
            }
        };

        $.contextMenu('destroy', '.context-menu-options');
        $.contextMenu({
            selector: '.context-menu-options',
            trigger: 'left',
            callback: function(key, options) {
                if (key === 'filter') {
                    (new SelectParameterDashboardsModal({
                        dialog: self,
                        levels: parametersLevels,
                        parameters: parametersValues,
                        htmlObject: htmlObject
                    })).render().open();
                }
                else if (key === 'embed-code') {
                    (new EmbedCodeDashboardsModal({
                        dialog: self,
                        file: file,
                        htmlObject: htmlObject,
                        oldRender: render !== 'playground' ? render : ''
                    })).render().open();
                }
                else if (key === 'remove-report') {
                    var $element = options.$trigger.closest('.gs-w');
                    self.remove_report($element);
                    self.remove_filter({ type: 'contextMenu' }, htmlObject, parametersValues);
                }
                else if (key === 'remove-widget') {
                    self.gridster.remove_widget($widget);
                    self.dashboardsModel.get('panels').clear();
                    self.dashboardsModel.get('panels').set(self.gridster.serialize());
                }
                else if (key === 'chart-editor') {
                    (new ChartEditorDashboardsModal({
                        dialog: self,
                        file: file,
                        htmlObject: htmlObject,
                        mode: mode,
                        chartDefinition: chartDefinition
                    })).render().open();
                }
            },
            events: {
                show: function(opt) {
                    var $this = this;
                    if ($this.data() && !(_.isEmpty($this.data()))) {
                        if (render === 'table') {
                            $this.data('chartOptionsDisabled', false);
                            $this.data('radio', 'renderTypeKey1');
                            $this.data('select', 'bar');
                        }
                        else if (render === 'chart') {
                            $this.data('select', mode);
                        }

                        $.contextMenu.setInputValues(opt, $this.data());
                    }
                },
                hide: function(opt) {
                    var $this = this;
                    $.contextMenu.getInputValues(opt, $this.data());
                }
            },
            items: menuItems
        });
    },

    /**
     * Client options with data
     * Bugfix: < IE 11 and Safari don't work with the object `chartDefinition`
     *
     * @method client_options
     * @private
     * @example
     *     this.saikuClient.execute({
     *         file: file,
     *         htmlObject: htmlObject,
     *         render: 'chart',
     *         render: 'chart',
     *         mode: selectedMode,
     *         chartDefinition, <============== This is the problem!
     *         zoom: true
     *     });
     * @param  {String} render Type of render (table, chart, map etc)
     * @param  {Object} data   Data with values for execute client
     * @return {Object}        Data with values for execute client
     */
    client_options: function(render, data) {
        var opts = {};

        if (render === 'chart') {
            opts.file = data.file;
            opts.htmlObject = data.htmlObject;
            opts.render = data.render;
            opts.mode = data.mode;
            opts.chartDefinition = data.chartDefinition;
            opts.zoom = data.zoom;
        }

        return opts;
    },

    /**
     * Check if exists model in EmbedCodeModel
     *
     * @method is_embed_code
     * @private
     * @param  {String} htmlObject HTML element
     * @return {Boolean}           If exists model
     */
    is_embed_code: function(htmlObject) {
        var embedCodeCollection = this.dashboardsModel.get('panels').embedCode;
        var embedCodeModel = embedCodeCollection.get(htmlObject);

        if (embedCodeModel) {
            return true;
        }
        else {
            return false;
        }
    },

    /**
     * Remove model in EmbedCodeModel
     *
     * @method remove_embed_code
     * @private
     * @param  {String} htmlObject HTML element
     */
    remove_embed_code: function(htmlObject) {
        var embedCodeCollection = this.dashboardsModel.get('panels').embedCode;

        if (this.is_embed_code(htmlObject)) {
            embedCodeCollection.remove(htmlObject);
        }
    },

    /**
     * Check changes in link filters and remove attribute
     *
     * @method remove_linkfilter
     * @private
     * @param  {String} htmlObject HTML element
     */
    remove_linkfilter: function(htmlObject) {
        var objFilters = this.dashboardsModel.get('filters').toJSON();
        var lenFilters = objFilters.length;
        var lenLinkFilters;
        var i, j;

        htmlObject = '#' + htmlObject;

        for (i = 0; i < lenFilters; i++) {
            if (objFilters[i].linkFilters.models.length > 0) {
                lenLinkFilters = _.size(objFilters[i].linkFilters.models[0].attributes);
                for (j = 0; j < lenLinkFilters; j++) {
                    if (objFilters[i].linkFilters.models[0].attributes[j].htmlObject === htmlObject) {
                        delete(objFilters[i].linkFilters.models[0].attributes[j]);
                    }
                }
            }
        }
    },

    /**
     * Remove report of widget
     *
     * @method remove_report
     * @private
     * @param  {String} element HTML element
     */
    remove_report: function(element) {
        var $element = element;
        $element.removeData('file');
        $element.removeData('render');
        $element.removeData('mode');
        $element.removeData('chartDefinition');
        $element.removeData('mapDefinition');
        $element.removeData('parametersLevels');
        $element.removeData('parametersValues');
        $element.find('.panel-body').text('');
        $element.find('.panel-body').find('table').remove();
        $element.find('.panel-body').find('.canvas_wrapper').remove();
        this.remove_linkfilter($element.find('.panel-body').attr('id'));
    },

    /**
     * Generate grids with reports
     *
     * @method generate_grids_reports
     * @public
     * @param  {Object} data Data dashboards
     */
    generate_grids_reports: function(data) {
        var self = this;
        var embedCodeCollection = this.dashboardsModel.get('panels').embedCode;
        var len = data.filters.length;
        var $li = '';
        var $gridster;
        var i, j;

        // console.log(JSON.stringify(data));

        for (i = 0; i < len; i++) {
            this.dashboardsModel.get('filters').add(new FilterModel(data.filters[i]));
        }

        for (j = 0; j < data.panels.embedCode.length; j++) {
            embedCodeCollection.add(new EmbedCodeModel(data.panels.embedCode[j]));
        }

        this.$el.find('.grids-view').empty();

        _.each(data.panels, function(value, key, list) {
            if (key !== 'embedCode') {
                $li += '<li class="gs-w" data-title="' + value.title + '" data-row="' + value.row + '" data-col="' + value.col + '" data-sizex="' + value.size_x + '" data-sizey="' + value.size_y + '">' +
                    '<div class="panel-title">' +
                        '<h3>' + value.title + '</h3>' +
                        '<a href="#context_menu_options" class="context-menu-options"></a>' +
                    '</div>' +
                    '<div class="panel-body" id="' + value.htmlObject.replace('#', '') + '"></div>' +
                '</li>';
            }
        });

        $gridster = $('<div class="gridster ready" />').append('<ul />');
        this.$el.find('.grids-view').append($gridster);
        this.$el.find('.grids-view').find('.gridster').find('ul').append($li);

        this.panel_gridster();

        _.each(data.panels, function(value) {
            if (value.length && value.length > 0) {
                var len = value.length;
                var i;

                for (i = 0; i < len; i++) {
                    // When add a custom table styles, is changing rendering of table for playground, then
                    // the plugin Saiku Client (SaikuEmbed.js) does not render the table to apply the style.
                    if (value[i].oldRender && value[i].oldRender === 'table') {
                        self.saikuClient.execute({
                            openDashboards: true,
                            file: value[i].file,
                            htmlObject: value[i].id,
                            render: 'table'
                        });
                    }

                    self.saikuClient.execute({
                        openDashboards: true,
                        file: value[i].file,
                        htmlObject: value[i].id,
                        render: 'playground',
                        uris: value[i].uris,
                        codeJS: value[i].codeJS
                    });
                }
            }
            else {
                if (value.render === 'table') {
                    self.saikuClient.execute({
                        openDashboards: true,
                        file: value.file,
                        htmlObject: value.htmlObject,
                        render: value.render
                    });
                }
                else {
                    self.saikuClient.execute({
                        openDashboards: true,
                        file: value.file,
                        htmlObject: value.htmlObject,
                        render: value.render,
                        mode: value.mode,
                        chartDefinition: value.chartDefinition ? JSON.parse(value.chartDefinition) : {},
                        mapDefinition: value.mapDefinition ? JSON.parse(value.mapDefinition) : {},
                        zoom: true
                    });
                }
            }
        });

        this.$el.find('.dashboard-title').show();

        if (data.title) {
            this.$el.find('.dashboard-title > h1').text(data.title);
            this.dashboardsModel.set({ title: data.title });
        }

        this.set_dashboards_model();
        this.set_filters_model();
    },

    /**
     * Set dashboards model
     *
     * @method set_dashboards_model
     * @private
     */
    set_dashboards_model: function() {
        this.dashboardsModel.get('panels').clear();
        this.dashboardsModel.get('panels').set(this.gridster.serialize());
        // console.log(JSON.stringify(this.dashboardsModel.toJSON()));
    },

    /**
     * Set filters model
     *
     * @method set_filters_model
     * @private
     */
    set_filters_model: function() {
        var len = this.dashboardsModel.attributes.filters.length;
        var i;

        for (i = 0; i < len; i++) {
            if (this.dashboardsModel.attributes.filters.models[i].attributes.linkFilters.length > 0) {
                this.dashboardsModel.attributes.filters.models[i].linkFilters.reset();
                this.dashboardsModel.attributes.filters.models[i].linkFilters.add(
                    new LinkFilterModel(this.dashboardsModel.attributes.filters.models[i].attributes.linkFilters[0])
                );
            }
        }
    },

    /**
     * Type of filter
     *
     * @method type_filter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    type_filter: function(event) {
        event.preventDefault();
        var $currentTarget = $(event.currentTarget);

        if ($currentTarget.val() === 'textBox') {
            this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').prop('disabled', true);
            this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').prop('disabled', true);
        }
        else {
            this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').prop('disabled', false);
            this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').prop('disabled', false);
        }
    },

    /**
     * Show dialog for create a list in filter
     *
     * @method create_list_filter
     * @private
     */
    create_list_filter: function() {
        (new CreateListFilterDashboardsModal({ dialog: this })).render().open();
    },

    /**
     * Show dialog for lookup in filter
     *
     * @method lookup_filter
     * @private
     */
    lookup_filter: function() {
        (new LookupFilterDashboardsModal({ dialog: this })).render().open();
    },

    /**
     * Show dialog for select a report in filter
     *
     * @method select_report_filter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    select_report_filter: function(event) {
        event.preventDefault();
        (new SelectReportFilterDashboardsModal({ dialog: this })).render().open();
    },

    /**
     * Check fields in filter form
     *
     * @method check_filter_fields
     * @private
     * @param  {Object} fields Filter fields
     * @return {Boolean}       If the fields were filled
     */
    check_filter_fields: function(fields) {
        var isPassed = 0;

        if (fields.nameFilter) {
            isPassed++;
        }
        else {
            isPassed--;
            this.$el.find('.sidebar-filter').find('form').find('.filter-err-1').show();
        }
        if (this.$el.find('.sidebar-filter').find('form').find('#type-filter option:selected').val() === 'textBox' || fields.typeFilter) {
            isPassed++;
        }
        else {
            isPassed--;
            this.$el.find('.sidebar-filter').find('form').find('.filter-err-2').show();
        }

        if (this.$el.find('.sidebar-filter').find('form').find('#type-filter option:selected').val() === 'textBox' || fields.contentType) {
            isPassed++;
        }
        else {
            isPassed--;
            this.$el.find('.sidebar-filter').find('form').find('.filter-err-3').show();
        }

        return isPassed === 3 ? true : false;
    },

    /**
     * Remove filter error
     *
     * @method remove_filter_error
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    remove_filter_error: function(event) {
        if (event.target.type !== 'radio') {
            event.preventDefault();
        }

        var $currentTarget = $(event.currentTarget);

        switch ($currentTarget.attr('class')) {
        case 'name-filter':
            this.$el.find('.sidebar-filter').find('form').find('.filter-err-1').hide();
            break;

        case 'type-filter':
            this.$el.find('.sidebar-filter').find('form').find('.filter-err-2').hide();
            break;

        case 'content-type-filter':
            this.$el.find('.sidebar-filter').find('form').find('.filter-err-3').hide();
            break;

        default:
            this.$el.find('.sidebar-filter').find('form').find('.error').hide();
        }
    },

    /**
     * Save filter
     *
     * @method save_filter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    save_filter: function(event) {
        event.preventDefault();

        var htmlObject = this.$el.find('.sidebar-filter').find('form').data('htmlobject');
        var parameter = this.$el.find('.sidebar-filter').find('form').data('parameter');
        var filterModel = this.dashboardsModel.get('filters').get(htmlObject + '_-_' + parameter);
        var nameFilter = this.$el.find('.sidebar-filter').find('form').find('#name-filter').val();
        var typeFilter = this.$el.find('.sidebar-filter').find('form').find('#type-filter option:selected').val();
        var createList = this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').is(':checked');
        var lookup = this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').is(':checked');
        var contentType = '';
        var objLinkFilters;

        if (createList) {
            contentType = this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').val();
        }
        else if (lookup) {
            contentType = this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').val();
        }

        if (this.check_filter_fields({ nameFilter: nameFilter, typeFilter: typeFilter, contentType: contentType })) {
            if (filterModel.attributes.linkFilters) {
                if (filterModel.attributes.linkFilters.length > 0 && filterModel.linkFilters.length === 0) {
                    objLinkFilters = filterModel.attributes.linkFilters;
                    filterModel.linkFilters.add(new LinkFilterModel(objLinkFilters[0]));
                }
            }

            filterModel.set({
                name: nameFilter,
                type: typeFilter,
                contentType: contentType
            });

            this.toggle_sidebar_filter(event);
        }
    },

    /**
     * Edit filter
     *
     * @method edit_filter
     * @private
     */
    edit_filter: function() {
        var htmlObject = this.$el.find('.sidebar-filter').find('form').data('htmlobject');
        var parameter = this.$el.find('.sidebar-filter').find('form').data('parameter');
        var filterModel = this.dashboardsModel.get('filters').get(htmlObject + '_-_' + parameter);
        var objFilter;
        var objLinkFilters;
        var reports = [];
        var selectReport;
        var $list;

        if (filterModel) {
            objFilter = filterModel.toJSON();

            if (filterModel.attributes.linkFilters) {
                if (filterModel.attributes.linkFilters.length > 0 && objFilter.linkFilters.length === 0) {
                    objLinkFilters = filterModel.attributes.linkFilters;
                }
                else {
                    objLinkFilters = objFilter.linkFilters.toJSON();
                }
            }
            else {
                objLinkFilters = objFilter.linkFilters.toJSON();
            }

            if (objLinkFilters.length > 0) {
                for (var i = 0, len = _.size(objLinkFilters[0]); i < len; i++) {
                    if (objLinkFilters[0][i].parentHtmlObject === htmlObject) {
                        reports.push(objLinkFilters[0][i].report);
                    }
                }

                reports = _.uniq(reports);

                selectReport = new SelectReportFilterDashboardsModal({ dialog: this });
                $list = selectReport.list_template(reports, false);
                this.$el.find('.sidebar-filter').find('.group-link-filters > ol').empty();
                this.$el.find('.sidebar-filter').find('.group-link-filters > ol').append($list);
            }

            if (objFilter.name) {
                this.$el.find('.sidebar-filter').find('form').find('#name-filter').val(objFilter.name);
                this.$el.find('.sidebar-filter').find('form').find('#remove-filter').removeClass('hide');
                this.$el.find('.sidebar-filter').find('form').find('#remove-filter').show();
            }

            if (objFilter.type === 'radioButton') {
                this.$el.find('.sidebar-filter').find('form').find('#type-filter').prop('selectedIndex', 1);
            }
            else if (objFilter.type === 'textBox') {
                this.$el.find('.sidebar-filter').find('form').find('#type-filter').prop('selectedIndex', 2);
                this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').prop('disabled', true);
                this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').prop('checked', false);
                this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').prop('checked', false);
                this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').prop('disabled', true);
            }
            else if (objFilter.type === 'dropdown') {
                this.$el.find('.sidebar-filter').find('form').find('#type-filter').prop('selectedIndex', 3);
            }
            else if (objFilter.type === 'dropdownMultiselect') {
                this.$el.find('.sidebar-filter').find('form').find('#type-filter').prop('selectedIndex', 4);
            }

            if (objFilter.contentType === 'createList') {
                this.$el.find('.sidebar-filter').find('form').find('#create-list-filter').prop('checked', true);
            }
            else if (objFilter.contentType === 'lookup') {
                this.$el.find('.sidebar-filter').find('form').find('#lookup-filter').prop('checked', true);
            }
        }
    },

    /**
     * Remove filter
     *
     * @method remove_filter
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     * @param  {String} htmlObject       HTML Element
     * @param  {Object} parametersValues Parameters values for filters
     */
    remove_filter: function(event, htmlObject, parametersValues) {
        var self = this;

        if (event.type === 'click') {
            event.preventDefault();
            var htmlObject = this.$el.find('.sidebar-filter').find('form').data('htmlobject');
            var parameter = this.$el.find('.sidebar-filter').find('form').data('parameter');
            this.dashboardsModel.get('filters').remove(htmlObject + '_-_' + parameter);
            this.toggle_sidebar_filter(event);
        }
        else if (event.type === 'contextMenu') {
            _.each(parametersValues, function(value, key) {
                self.dashboardsModel.get('filters').remove(htmlObject + '_-_' + key);
            });
        }
    }
});

Saiku.events.bind('session:new', function() {
    // Load CSS
    Saiku.loadCSS('js/saiku/plugins/Dashboards/components/gridster/jquery.gridster.min.css');
    Saiku.loadCSS('js/saiku/plugins/Dashboards/css/plugin.css');
    // Load JS
    Saiku.loadJS('js/saiku/plugins/Dashboards/components/gridster/jquery.gridster.min.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/components/editable/jquery.editable.min.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/models/DashboardsModel.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/models/SchemasDashboardsModel.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/OptionsDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/SetupGridsDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/LayoutsDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/SaveDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/OpenDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/SelectParameterDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/CreateListFilterDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/LookupFilterDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/SelectReportFilterDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/CreateWidgetDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/EmbedCodeDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/ChartEditorDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/MapEditorDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/dialogs/EasterEggDashboardsModal.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/ui/GenerateGridsDashboards.js');
    Saiku.loadJS('js/saiku/plugins/Dashboards/js/ui/DashboardViewTab.js');

    if (!Settings.BIPLUGIN) {
        var $link = $('<a />')
            .attr({
                href: '#dashboards',
                title: 'Dashboards'
            })
            .click(Saiku.Dashboards.show)
            .addClass('dashboards i18n');

        var $li = $('<li />').append($link);
        Saiku.toolbar.$el.find('ul').append($li).append('<li class="separator">&nbsp;</li>');
    }

    function new_dashboards(args) {
        if (typeof args.dashboards === 'undefined') {
            args.dashboards = new Dashboards({});
        }
    }

    // New dashboards
    Saiku.session.bind('openQuery:new', new_dashboards);
});
