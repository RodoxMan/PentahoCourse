/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorSchemaModel = Backbone.Model.extend({
  url: 'api/mondrian2',

  defaults: {
    apiVersion: '1.0',
    dataSourceName: '',
    tables: [],
    factTable: '',
    measures: [],
    dimensions: []
  }
});

// Tables

var SchemaEditorTablesCollection = Backbone.Collection.extend({
  model: SchemaEditorTablesModel,

  getData: function(tableName) {
    if (this.findWhere({ name: tableName })) {
      return this.findWhere({ name: tableName }).toJSON();
    }
    else {
      return false;
    }
  }
});

var SchemaEditorTablesModel = Backbone.Model.extend();

// Measures

var SchemaEditorMeasuresCollection = Backbone.Collection.extend({
  model: SchemaEditorMeasuresModel,

  hasMeasure: function(measureName) {
    if (this.findWhere({ name: measureName })) {
      return true;
    }
    else {
      return false;
    }
  }
});

var SchemaEditorMeasuresModel = Backbone.Model.extend();

// Dimensions

var SchemaEditorDimensionsCollection = Backbone.Collection.extend({
  model: SchemaEditorDimensionsModel,

  hasDimension: function(dimensionName) {
    if (this.findWhere({ name: dimensionName })) {
      return true;
    }
    else {
      return false;
    }
  }
});

var SchemaEditorDimensionsModel = Backbone.Model.extend({
  initialize: function() {
    this.attribute = new SchemaEditorAttributeCollection();
    this.attribute.parent = this;
    this.hierarchy = new SchemaEditorHierarchyCollection();
    this.hierarchy.parent = this;
  },

  toJSON: function() {
    var attr = _.clone(this.attributes);
    attr.attribute = this.attribute;
    attr.hierarchy = this.hierarchy;
    return attr;
  }
});

// Attribute

var SchemaEditorAttributeCollection = Backbone.Collection.extend({
  model: SchemaEditorAttributeModel,

  hasAttribute: function(attributeName) {
    if (this.findWhere({ name: attributeName })) {
      return true;
    }
    else {
      return false;
    }
  }
});

var SchemaEditorAttributeModel = Backbone.Model.extend({
  defaults: {
    visible: true
  }
});

// Hierarchy

var SchemaEditorHierarchyCollection = Backbone.Collection.extend({
  model: SchemaEditorHierarchyModel,

  hasHierarchy: function(hierarchyName) {
    if (this.findWhere({ name: hierarchyName })) {
      return true;
    }
    else {
      return false;
    }
  }
});

var SchemaEditorHierarchyModel = Backbone.Model.extend({
  initialize: function() {
    this.level = new SchemaEditorLevelCollection();
    this.level.parent = this;
  },

  toJSON: function() {
    var attr = _.clone(this.attributes);
    attr.level = this.level;
    return attr;
  }
});

// Level

var SchemaEditorLevelCollection = Backbone.Collection.extend({
  model: SchemaEditorLevelModel,

  hasLevel: function(levelName) {
    if (this.findWhere({ name: levelName })) {
      return true;
    }
    else {
      return false;
    }
  }
});

var SchemaEditorLevelModel = Backbone.Model.extend({
  defaults: {
    properties: {
      uniqueMember: false
    }
  }
});
