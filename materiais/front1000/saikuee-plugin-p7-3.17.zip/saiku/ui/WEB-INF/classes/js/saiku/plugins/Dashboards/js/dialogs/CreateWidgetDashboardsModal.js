/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Create a widget for the dashboard
 *
 * @class CreateWidgetDashboardsModal
 */
var CreateWidgetDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'create-widget',

    /**
     * Property with main template of modal
     *
     * @property message
     * @type {String}
     * @private
     */
    message: '<form class="form-group">' +
                '<label for="number-widgets" class="i18n">Enter the number of widgets you want to create:</label>' +
                '<input type="number" min="0" id="number-widgets" style="width: 100px">' +
                '<span class="error i18n" hidden>This field is required</span><br>' +
             '</form>',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Create', method: 'create' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click  .dialog_footer a' : 'call',
        'keyup  #number-widgets'  : 'remove_error',
        'change #number-widgets'  : 'remove_error'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Create Widget';
        this.bind('open');
    },

    /**
     * Check the fields of form
     *
     * @method check_fields
     * @private
     * @param  {String} numberWidgets Value for add in list
     * @return {Boolean}              If element input contains a value
     */
    check_fields: function(numberWidgets) {
        var isPassed = false;

        if (numberWidgets) {
            if (numberWidgets === '0') {
                isPassed = false;
                this.$el.find('.form-group .error').text('Can not be zero').show();
            }
            else {
                isPassed = true;
            }
        }
        else {
            isPassed = false;
            this.$el.find('.form-group .error').text('This field is required').show();
        }

        return isPassed;
    },

    /**
     * Remove message of error
     *
     * @method remove_error
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    remove_error: function(event) {
        var $currentTarget = $(event.currentTarget);

        if ($currentTarget.attr('id') === 'number-widgets') {
            this.$el.find('.form-group .error').hide();
        }
    },

    /**
     * Create a new widget
     *
     * @method create
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    create: function(event) {
        event.preventDefault();

        var generateGrids = new GenerateGridsDashboards();
        var sizex = generateGrids.calculate_grid(this.dialog.numberRows);
        var sizey = generateGrids.calculate_grid(this.dialog.numberCols);
        var numberWidgets = this.$el.find('#number-widgets').val();
        var i;

        if (this.check_fields(numberWidgets)) {
            for (i = 0; i < numberWidgets; i++) {
                this.dialog.gridster.add_widget('<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="#' + _.uniqueId('panel-body-') + '">' +
                                                    '<div class="panel-title">' +
                                                        '<h3>Widget '+ (_.uniqueId() - 2) +'</h3>' +
                                                        '<a class="context-menu-options" href="#open_help"></a>' +
                                                    '</div>' +
                                                    '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                                                '</li>', sizex, sizey);
            }

            this.dialog.panel_gridster();
            this.dialog.dashboardsModel.get('panels').clear();
            this.dialog.dashboardsModel.get('panels').set(this.dialog.gridster.serialize());
            // console.log(JSON.stringify(this.dialog.dashboardsModel.toJSON()));
            this.$el.dialog('close');
        }
    }
});
