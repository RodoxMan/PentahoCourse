/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Create custom layout
 *
 * @class LayoutsDashboardsModal
 */
var LayoutsDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'layouts',

    /**
     * Property with main template of modal
     *
     * @property message
     * @type {String}
     * @private
     */
    message: '<div class="layouts-group">' +
                '<div class="img-thumbnail">' +
                    '<span class="i18n">Two and One</span>' +
                    '<a href="#layout_two_and_one" class="two_and_one"><img src="js/saiku/plugins/Dashboards/image/two_and_one.png" width="150" height="95"></a>' +
                '</div>' +
                '<div class="img-thumbnail">' +
                    '<span class="i18n">Thirds Grid</span>' +
                    '<a href="#layout_thirds_grid" class="thirds_grid"><img src="js/saiku/plugins/Dashboards/image/thirds_grid.png" width="150" height="95"></a>' +
                '</div>' +
                '<div class="img-thumbnail">' +
                    '<span class="i18n">Split Rows</span>' +
                    '<a href="#layout_split_rows" class="split_rows"><img src="js/saiku/plugins/Dashboards/image/split_rows.png" width="150" height="95"></a>' +
                '</div>' +
                '<div class="img-thumbnail">' +
                    '<span class="i18n">Hero Thirds</span>' +
                    '<a href="#layout_hero_thirds" class="hero_thirds"><img src="js/saiku/plugins/Dashboards/image/hero_thirds.png" width="150" height="95"></a>' +
                '</div>' +
             '</div>',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Back', method: 'back' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click .dialog_footer a' : 'call',
        'click .two_and_one'     : 'layout_two_and_one',
        'click .thirds_grid'     : 'layout_thirds_grid',
        'click .split_rows'      : 'layout_split_rows',
        'click .hero_thirds'     : 'layout_hero_thirds'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        this.options.title = 'Layouts';
        this.$gridster = $('<div class="gridster ready" />').append('<ul />');
        this.$li = '';
        this.bind('open');
    },

    /**
     * Append plugin Gridster in DOM
     *
     * @method append_gridster
     * @private
     */
    append_gridster: function() {
        this.dialog.$el.find('.grids-view').empty();
        this.dialog.$el.find('.grids-view').append(this.$gridster);
        this.dialog.$el.find('.grids-view').find('.gridster').find('ul').append(this.$li);
        this.dialog.panel_gridster();
        this.dialog.$el.find('.dashboard-title').show();
        this.dialog.set_dashboards_model();
        // Trigger event when create grids
        this.dialog.trigger('workspaceToolbar:disable', { dialog: this.dialog });
    },

    /**
     * Layout two and one
     *
     * @method layout_two_and_one
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    layout_two_and_one: function(event) {
        event.preventDefault();

        this.$li = '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="1" data-sizex="3" data-sizey="3">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="4" data-sizex="3" data-sizey="3">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="4" data-col="1" data-sizex="6" data-sizey="3">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>';

        if (!this.dialog.openDashboards) {
            this.append_gridster();
        }
        else {
            Saiku.tabs.add(new Dashboards({
                newLayouts: true,
                $gridster: this.$gridster,
                $list: this.$li
            }));
        }

        this.$el.dialog('close');
    },

    /**
     * Layout thirds grid
     *
     * @method layout_thirds_grid
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    layout_thirds_grid: function(event) {
        event.preventDefault();

        this.$li = '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="3" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="5" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="3" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="3" data-col="3" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="3" data-col="5" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="5" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="5" data-col="3" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="5" data-col="5" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>';

        if (!this.dialog.openDashboards) {
            this.append_gridster();
        }
        else {
            Saiku.tabs.add(new Dashboards({
                newLayouts: true,
                $gridster: this.$gridster,
                $list: this.$li
            }));
        }

        this.$el.dialog('close');
    },

    /**
     * Layout split rows
     *
     * @method layout_split_rows
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    layout_split_rows: function(event) {
        event.preventDefault();

        this.$li = '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="3" data-sizex="4" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="3" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="3" data-col="3" data-sizex="4" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="5" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="5" data-col="3" data-sizex="4" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="7" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="7" data-col="3" data-sizex="4" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>';

        if (!this.dialog.openDashboards) {
            this.append_gridster();
        }
        else {
            Saiku.tabs.add(new Dashboards({
                newLayouts: true,
                $gridster: this.$gridster,
                $list: this.$li
            }));
        }

        this.$el.dialog('close');
    },

    /**
     * Layout hero thirds
     *
     * @method layout_hero_thirds
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    layout_hero_thirds: function(event) {
        event.preventDefault();

        this.$li = '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="1" data-sizex="4" data-sizey="3">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="4" data-col="3" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="1" data-col="5" data-sizex="2" data-sizey="3">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="4" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="6" data-col="3" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="4" data-col="5" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="6" data-col="1" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>' +
                    '<li data-title="Widget ' + _.uniqueId() + '" data-htmlobject="' + _.uniqueId('#panel-body-') + '" data-row="6" data-col="5" data-sizex="2" data-sizey="2">' +
                        '<div class="panel-title">' +
                            '<h3>Widget ' + (_.uniqueId() - 2) + '</h3>' +
                            '<a href="#context_menu_options" class="context-menu-options"></a>' +
                        '</div>' +
                        '<div class="panel-body" id="' + _.uniqueId('panel-body-') + '"></div>' +
                    '</li>';

        if (!this.dialog.openDashboards) {
            this.append_gridster();
        }
        else {
            Saiku.tabs.add(new Dashboards({
                newLayouts: true,
                $gridster: this.$gridster,
                $list: this.$li
            }));
        }

        this.$el.dialog('close');
    },

    /**
     * Back for dialog `Setup Grids`
     *
     * @method back
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    back: function(event) {
        event.preventDefault();
        (new SetupGridsDashboardsModal({ dialog: this })).render().open();
        this.$el.dialog('close');
    }
});
