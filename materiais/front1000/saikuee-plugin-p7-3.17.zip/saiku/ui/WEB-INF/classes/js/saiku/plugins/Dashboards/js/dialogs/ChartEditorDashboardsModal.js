/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2015
 */

/**
 * Class for edit charts
 *
 * @class ChartEditorDashboardsModal
 */
var ChartEditorDashboardsModal = Modal.extend({
    /**
     * Type name
     *
     * @property type
     * @type {String}
     * @private
     */
    type: 'chart-editor',

    /**
     * Events of buttons
     *
     * @property buttons
     * @type {Array}
     * @private
     */
    buttons: [
        { text: 'Add Color Palette', method: 'add_color_palette' },
        { text: 'Save', method: 'save' },
        { text: 'Cancel', method: 'close' }
    ],

    /**
     * The events hash (or method) can be used to specify a set of DOM events
     * that will be bound to methods on your View through delegateEvents
     *
     * @property events
     * @type {Object}
     * @private
     */
    events: {
        'click  .dialog_footer a' : 'call',
        'change #trend-line'      : 'hide_periods'
    },

    /**
     * The constructor of view, it will be called when the view is first created
     *
     * @constructor
     * @private
     * @param  {Object} args Attributes, events and others things
     */
    initialize: function(args) {
        // Initialize properties
        _.extend(this, args);
        var self = this;
        this.options.title = 'Chart Settings';
        this.chartEditor = new ChartEditor();
        this.message = this.chartEditor.template_editor();
        this.bind('open', function() {
            this.chartEditor.get_chart_properties({
                element: this.$el,
                type: this.mode,
                chartDefinition: this.chartDefinition
            });
            this.$el.closest('.ui-dialog').on('keydown', function(event) {
                if (event.keyCode === $.ui.keyCode.ESCAPE) {
                    self.close(event);
                }
            });
        });
    },

    /**
     * Add color palette using spectrum plugin
     *
     * @method add_color_palette
     * @public
     * @param  {Object} event The Event interface represents any event of the DOM
     * @param  {String} color Color selected
     */
    add_color_palette: function(event) {
        event.preventDefault();
        this.chartEditor.add_color_palette(event);
    },

    /**
     * Show/hide periods
     *
     * @method hide_periods
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    hide_periods: function(event) {
        event.preventDefault();
        this.chartEditor.hide_periods(event);
    },

    /**
     * Save chart options
     *
     * @method save
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    save: function(event) {
        event.preventDefault();

        var self = this;
        var chartDefinition = {};
        var colors = [];

        if (this.$el.find('#chart-title').val() !== null) {
            chartDefinition.title = this.$el.find('#chart-title').val();
        }

        if (this.$el.find('#xtitle').val() !== null) {
            chartDefinition.baseAxisTitle = this.$el.find('#xtitle').val();
        }

        if (this.$el.find('#ytitle').val() !== null) {
            chartDefinition.orthoAxisTitle = this.$el.find('#ytitle').val();
        }

        $.each(this.$el.find('.container-colors > input[type="color"]'), function(key, value) {
            colors.push(self.$el.find('#' + $(value).attr('id')).spectrum('get').toHexString());
        });

        chartDefinition.colors = colors;
        chartDefinition.legend = this.$el.find('input:radio[name=legend]:checked').val() === 'true';

        if (this.$el.find('#trend-line').val() !== 'none') {
            chartDefinition.trend = {
                type: this.$el.find('#trend-line').val(),
                periods: this.$el.find('#trend-points').val()
            };
        }
        else {
            chartDefinition.trend = null;
        }

        if (this.chartEditor.renderer.type === 'multiplesunburst') {
            chartDefinition.multiChartMax = this.$el.find('#multiplesunburst-multichartmax').val() || 30;
        }

        if (this.chartEditor.renderer.type === 'pie') {
            chartDefinition.valuesLabelStyle = this.$el.find('#pie-values-label-style').val();
            chartDefinition.valuesMask = this.$el.find('#pie-values-mask').val() || '{value.percent}';
        }

        this.dialog.$el.find('.gs-w').find(this.htmlObject).parent().data('chartDefinition', JSON.stringify(chartDefinition));

        this.dialog.saikuClient.execute({
            file: this.file,
            htmlObject: this.htmlObject,
            render: 'chart',
            mode: this.mode,
            chartDefinition: chartDefinition,
            zoom: true
        });

        this.$el.dialog('close');
    },

    /**
     * Cloase dialog
     *
     * @method close
     * @private
     * @param  {Object} event The Event interface represents any event of the DOM
     */
    close: function(event) {
        event.preventDefault();
        $('.sp-container').addClass('sp-hidden');
        this.$el.dialog('close');
    }
});
