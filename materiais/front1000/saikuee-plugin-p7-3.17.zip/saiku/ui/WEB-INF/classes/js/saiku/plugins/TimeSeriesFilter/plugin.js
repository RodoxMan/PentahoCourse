/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2017
 */

/**
 * Plugin for temporal filter
 */
var TimeSeriesFilter = Backbone.View.extend({
  DATE_FORMAT: Settings.TIME_SERIES_FILTER.date_format,

  options: {
    width: 800,
    height: 30
  },

  dygraph: '',

  hasRendered: false,
  isClearFilter: false,
  isOpenFile: false,
  runOnceOpenFile: false,
  dygraphRangeAction: false,

  stepRenderClearQuery: true,
  stepRenderGetCsv: false,
  stepRenderSetDygraphRange: false,

  member: null,

  levelInfo: {
    dimension: '',
    hierarchy: '',
    level: ''
  },

  selectedDates: {
    startDateTime: '',
    endDateTime: ''
  },

  events: {
    'mouseup .dygraph-rangesel-zoomhandle' : 'dygraph_range',
    'mouseup .dygraph-rangesel-fgcanvas'   : 'dygraph_range'
  },

  initialize: function(args) {
    var self = this;

    // Keep track of parent workspace
    this.workspace = args.workspace;

    // Create a ID for use as the CSS selector
    this.id = _.uniqueId('timeSeriesFilter_');
    this.$el.attr({ id: this.id });

    // Maintain `this` in callbacks
    _.bindAll(this, 'show', 'render', 'resize', 'adjust', 'receive_data',
      'check_time_dimension', 'parse_success', 'parse_error');

    // Add template HTML in workspace
    this.template();

    // Listen to result event
    this.workspace.bind('query:result', this.receive_data);
    this.workspace.bind('table:rendered', this.show);
    this.workspace.bind('chart:rendered', this.show);

    if (Settings.OZP_IWC_ENABLED) {
      // Creating a client IWC.
      var iwc = new ozpIwc.Client(Settings.OZP_IWC_CLIENT_URI);

      // The Intents API is accessed through the intents property
      // of a connected IWC Client.
      var intents = iwc.intents;

      // Testing if the client can connect.
      iwc.connect().then(function() {
        console.log('PLUGIN TIME SERIES FILTER -> IWC client connected with address: ', iwc.address);
      }).catch(function(error) {
        console.error('PLUGIN TIME SERIES FILTER -> IWC client failed to connect: ', error);
      });

      // The IWC uses the concept of references when accessing resources.
      // References are objects with auto-generated functionality to perform
      // actions on a given resource.

      // If the registration node path matches
      // /{minor}/{major}/{action} ("/application/json/view")
      // the handler Id will be generated automatically and
      // returned in the promise resolution.

      // If the registration node path matches
      // /{minor}/{major}/{action}/{handlerId} ("/application/json/view/123")
      // the handler Id given will be used.
      var funcRef = new intents.Reference(Settings.OZP_IWC_REFERENCE_PATH.time_series_filter);

      // When registering an intent handler, two entity properties
      // are used to make choosing a handler easier for the end user:

      // 1 - label: A short string noting the widget handling the intent (typically the widget title);
      // 2 - icon: A url path to a icon to use for the widget.
      var config = {
        label: Settings.OZP_IWC_CONFIG.label,
        icon: Settings.OZP_IWC_CONFIG.icon
      };

      // The callback registered with the register action.
      var onInvoke = function(data, reply) {
        if (reply.entity.status === 'ok') {
          self.set_dygraph_range(data.startDateTime, data.endDateTime, false);
        }
      };

      // Registers a handler function to a node to be called when invoked by others.
      funcRef.register(config, onInvoke);
    }
  },

  template_mdx: 'Filter([{dimension}.{hierarchy}].[{level}].Members, ' +
    '[{dimension}.{hierarchy}].[{level}].CurrentMember.NAME >= "{startDateTime}" ' +
    'AND [{dimension}.{hierarchy}].[{level}].CurrentMember.NAME <= "{endDateTime}")',

  template: function() {
    // Create template HTML
    this.html = _.template('<div id="timeSeriesFilter_chart" style="margin-top: 20px; margin-bottom: 20px;"></div>');

    // Add template in this.$el
    this.$el.html(this.html);

    // Insert template in workspace results
    this.workspace.$el.find('.workspace_results').append(this.$el.hide());
  },

  show: function(show) {
    if (this.hasRendered || show) {
      this.$el.show();
      this.adjust();
      this.resize();
    }
  },

  resize: function() {
    this.options.width = (this.workspace.$el.find('.workspace_results').width() - 40);

    this.$el.find('#timeSeriesFilter_chart').width(this.options.width);
    this.$el.find('#timeSeriesFilter_chart').height(this.options.height);

    this.dygraph ? this.dygraph.resize(this.options.width, this.options.height) : null;

    this.$el.find('#timeSeriesFilter_chart').fadeIn(400);
  },

  adjust: function() {
    var self = this;
    var calculateLayout = function() {
      if (self.hasRendered && self.$el.is(':visible')) {
        self.resize();
      }
    };
    var lazyLayout = _.debounce(calculateLayout, 300);

    $(window).resize(function() {
      self.$el.find('#timeSeriesFilter_chart').fadeOut(150);
      lazyLayout();
    });
  },

  get_url: function() {
    var formatter = this.workspace.query.getProperty('saiku.olap.result.formatter');
    var url;

    if (this.workspace.query.name !== undefined) {
      var filename = this.workspace.query.name.substring(this.workspace.query.name.lastIndexOf('/') + 1).slice(0, -6);

      url = Settings.REST_URL +
        this.workspace.query.url() + '/export/csv/' + formatter +
        '?exportname=' + encodeURIComponent(filename);
    }
    else {
      url = Settings.REST_URL +
        this.workspace.query.url() + '/export/csv/' + formatter;
    }

    return url;
  },

  get_data_dimension: function (dimension, hierarchy, level) {
    if (this.workspace.metadata === undefined) {
      this.workspace.metadata = Saiku.session.sessionworkspace.cube[this.workspace.selected_cube];
    }

    var metadata = this.workspace.metadata.attributes.data;
    var value = {};

    value.dimensions = _.findWhere(metadata.dimensions, { name: dimension });

    if (hierarchy === undefined) {
      hierarchy = dimension;
    }

    value.hierarchies = _.findWhere(value.dimensions.hierarchies, { name: hierarchy });

    if (value.hierarchies === undefined || value.hierarchies === null) {
      value.hierarchies = _.findWhere(value.dimensions.hierarchies, { name: dimension + '.' + hierarchy })
        ? _.findWhere(value.dimensions.hierarchies, { name: dimension + '.' + hierarchy })
        : _.findWhere(value.dimensions.hierarchies, { name: dimension });
    }

    value.level = _.findWhere(value.hierarchies.levels, { name: level });

    if(value.level === null || value.level === undefined) {
      value.level = _.findWhere(value.hierarchies.levels, { caption: level });
    }

    return value;
  },

  get_date_format: function(formatString) {
    var newFormatString = Saiku.toPattern(formatString, 'AAAA/AA/AA AA:AA:AA');

    // MomentJS String + Format
    // Change `yyyy/mm/dd hh:mm:ss` => `YYYY/MM/DD HH:mm:ss`
    // link: https://momentjs.com/docs/#/parsing/string-format/
    newFormatString = newFormatString.replace(/yyyy/i, 'YYYY')
      .replace(/mm/i, 'MM')
      .replace(/dd/i, 'DD')
      .replace(/hh/i, 'HH')
      .replace(/:mm/i, ':mm')
      .replace(/:ss/i, ':ss');

    return newFormatString;
  },

  receive_data: function(args) {
    if (this.workspace.query.model.type !== 'MDX') {
      if (!this.hasRendered) {
        return _.delay(this.check_time_dimension, 1000, args);
      }
      else {
        if (this.dygraphRangeAction) {
          this.dygraphRangeAction = false;

          return false;
        }

        if (this.stepRenderClearQuery) {
          this.stepRenderClearQuery = false;
          this.stepRenderGetCsv = true;
          this.stepRenderSetDygraphRange = false;

          if (this.runOnceOpenFile) {
            this.runOnceOpenFile = false;
            this.receive_data();
          }
          else {
            var action = { re_render: true };

            return _.delay(this.check_time_dimension, 1000, action);
          }
        }
        else if (this.stepRenderGetCsv) {
          this.stepRenderClearQuery = true;
          this.stepRenderGetCsv = false;
          this.stepRenderSetDygraphRange = true;

          this.run_csv_parse();

          Saiku.ui.block('Loading Time Series Filter...');
        }
      }
    }
  },

  check_time_dimension: function(args) {
    var axisType = 'ROWS';
    var axisData = this.workspace.query.helper.getAxis(axisType);
    var dimensionData;
    var dimensionKey;

    if (axisData && axisData.hierarchies && axisData.hierarchies.length > 0) {
      for (var level in axisData.hierarchies[0].levels) {
        if (axisData.hierarchies[0].levels.hasOwnProperty(level)) {
          var dimensionName = axisData.hierarchies[0].dimension;
          var hierarchyName = axisData.hierarchies[0].caption;
          var dimensionCaptionName = axisData.hierarchies[0].name; // [dim].[hier]
          var levelName = axisData.hierarchies[0].levels[level].name || level;

          this.levelInfo = {
            dimension: dimensionName,
            hierarchy: hierarchyName,
            level: levelName
          };

          dimensionData = this.get_data_dimension(dimensionName, hierarchyName, levelName);

          dimensionKey = dimensionCaptionName + '/' + levelName;

          // Fetch available members
          this.member = new Member({}, {
            cube: this.workspace.selected_cube,
            dimension: dimensionKey
          });
        }
      }

      if (dimensionData && (dimensionData.level && dimensionData.level.annotations !== undefined && dimensionData.level.annotations !== null) &&
         (dimensionData.level.annotations.SaikuDayFormatString !== undefined)) {

        var timeSeriesFilterData = this.workspace.query.getProperty('saiku.ui.timeseriesfilter.data') || {};
        var formatString = dimensionData.level.annotations.SaikuDayFormatString;

        this.DATE_FORMAT = this.get_date_format(formatString);

        this.show(true);

        // Render chart in template HTML,
        // if the `.saiku` file has `timeSeriesFilterData`
        if (this.workspace.item &&
            this.workspace.item.type === 'FILE' &&
            this.workspace.item.fileType === 'saiku' &&
            !_.isEmpty(timeSeriesFilterData) &&
            !this.isOpenFile) {

          this.selectedDates = {
            startDateTime: timeSeriesFilterData.startDateTime,
            endDateTime: timeSeriesFilterData.endDateTime
          };

          this.hasRendered = true;
          this.isOpenFile = true;
          this.runOnceOpenFile = true;
          this.$el.find('#timeSeriesFilter_chart').empty();
          this.clear_filter();
        }
        else if (args.re_render && this.hasRendered) {
          this.isOpenFile = true;
          this.$el.find('#timeSeriesFilter_chart').empty();

          this.clear_filter();
        }
        else {
          this.isOpenFile = true;

          // Render chart in template HTML
          this.render();
        }
      }
      else {
        this.stepRenderClearQuery = true;
        this.stepRenderGetCsv = false;

        Saiku.ui.unblock();

        this.$el.hide();
      }
    }
  },

  render: function() {
    if (!this.hasRendered) {
      this.run_csv_parse();
    }
  },

  run_csv_parse: function() {
    var url = this.get_url();

    Papa.parse(url,
      // The Parse config object
      // link: http://papaparse.com/docs#config
      {
        dynamicTyping: true,
        worker: true,
        complete: this.parse_success,
        error: this.parse_error,
        download: true,
        skipEmptyLines: true
      }
    );
  },

  populate_mdx: function(data, selectedDates) {
    _.extend(data, selectedDates);

    var mdx = this.template_mdx.replace(/{(\w+)}/g, function(m, p) {
      return data[p];
    });

    return mdx;
  },

  parse_success: function(res) {
    var self = this;
    var data;

    _.defer(function() {
      data = self.data_analyzer(res.data);
    });

    _.delay(function(args) {
      if (!_.isEmpty(data)) {
        self.dygraph = new Dygraph(
          document.getElementById('timeSeriesFilter_chart'),
          data,
          // The dygraphs config object
          // link: http://dygraphs.com/options.html
          {
            xAxisHeight: 30,
            axes: {
              x: {
                drawAxis: false
              }
            },
            labels: res.data[0],
            showLabelsOnHighlight: false,
            showRangeSelector: true,
            drawCallback: function(dygraph, is_initial) {
              // is_initial: True if this is the initial draw, false for subsequent draws.
              if (!is_initial && dygraph.dateWindow_ !== null) {
                self.selectedDates = {
                  startDateTime: moment(dygraph.dateWindow_[0]).format(self.DATE_FORMAT),
                  endDateTime: moment(dygraph.dateWindow_[1]).format(self.DATE_FORMAT)
                };
              }
            },
            zoomCallback: function(startDateTime, endDateTime, yRanges) {
              self.selectedDates = {
                startDateTime: moment(startDateTime).format(self.DATE_FORMAT),
                endDateTime: moment(endDateTime).format(self.DATE_FORMAT)
              };
            }
          }
        );

        self.hasRendered = true;
        self.isClearFilter = false;

        if (self.stepRenderSetDygraphRange) {
          var startDateTime = self.selectedDates.startDateTime;
          var endDateTime = self.selectedDates.endDateTime;

          self.stepRenderSetDygraphRange = false;

          if (startDateTime !== '' || endDateTime !== '') {
            self.set_dygraph_range(startDateTime, endDateTime, false);
          }
          else {
            Saiku.ui.unblock();
          }
        }
      }
      else {
        Saiku.ui.unblock();
        console.log('PLUGIN TIME SERIES FILTER -> Data is empty');
      }
    }, 1000);
  },

  parse_error: function(err, file) {
    this.hasRendered = false;
    this.isClearFilter = false;
    console.error('PLUGIN TIME SERIES FILTER -> ERROR: ', err, file);
  },

  data_analyzer: function(data) {
    var newData = [];

    for (var row = 1, rowLen = data.length; row < rowLen; row++) {
      newData.push(data[row]);

      for (var col = 0, colLen = data[row].length; col < colLen; col++) {
        if (col === 0) {
          data[row][col] = new Date(data[row][col]);
        }

        if (data[row][col] === '' || _.isString(data[row][col])) {
          data[row][col] = null;
        }
      }
    }

    return newData;
  },

  set_mdx: function(mdx) {
    if (this.member) {
      var hierarchyName = decodeURIComponent(this.member.hierarchy);
      var levelName = decodeURIComponent(this.member.level);
      var hierarchy = this.workspace.query.helper.getHierarchy(hierarchyName);

      if (hierarchy && hierarchy.levels.hasOwnProperty(levelName)) {
        hierarchy.levels[levelName] = { mdx: mdx, name: levelName };
      }
    }
  },

  dygraph_range: function() {
    var mdx = this.populate_mdx(this.levelInfo, this.selectedDates);

    // It's the range action...
    this.dygraphRangeAction = true;

    // Saving selected dates...
    this.workspace.query.setProperty('saiku.ui.timeseriesfilter.data', this.selectedDates);

    this.set_mdx(mdx);
    this.run();
  },

  set_dygraph_range: function(startDateTime, endDateTime, hasDelay) {
    var self = this;
    var selectedDates = [new Date(startDateTime), new Date(endDateTime)];
    var time = hasDelay ? 3000 : 0;

    if (!_.isEmpty(this.selectedDates)) {
      _.delay(function() {
        self.dygraph
          ? self.dygraph.updateOptions({ dateWindow: selectedDates })
          : null;

        self.dygraph_range();

        Saiku.ui.unblock();
      }, time);
    }
  },

  clear_filter: function() {
    this.isClearFilter = true;
    this.set_mdx(null);
    this.run();
  },

  run: function() {
    this.workspace.query.run();
  }
});

if (Settings.TIME_SERIES_FILTER.enabled) {
  // Start TimeSeriesFilter
  Saiku.events.bind('session:new', function() {
    function new_workspace(args) {
      if (typeof args.workspace.timeSeriesFilter === 'undefined') {
        args.workspace.timeSeriesFilter = new TimeSeriesFilter({ workspace: args.workspace });
      }
    }

    function clear_workspace(args) {
      if (typeof args.workspace.timeSeriesFilter !== 'undefined') {
        args.workspace.timeSeriesFilter.$el.hide();
      }
    }

    // Add new tab content
    for (var i = 0, len = Saiku.tabs._tabs.length; i < len; i++) {
      var tab = Saiku.tabs._tabs[i];

      if ($(tab.caption).text() !== 'Home') {
        new_workspace({
          workspace: tab.content
        });
      }
    }

    // Attach TimeSeriesFilter to future tabs
    Saiku.session.bind('workspace:new', new_workspace);
    Saiku.session.bind('workspace:clear', clear_workspace);
  });
}
