/* Copyright (C) OSBI Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Breno Polanski, 2016
 */

var SchemaEditorSchemaMock = (function() {
  'use strict';

  function SchemaEditorSchemaMock(data, opts) {
    // enforces new
    if (!(this instanceof SchemaEditorSchemaMock)) {
      return new SchemaEditorSchemaMock(data, opts);
    }
  }

  function capitalize(str) {
    if (_.isString(str)) {
      str = str.replace(/[^a-zA-Z 0-9]/gi, ' ');
      return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }
  }

  function replaceMeasureAggregationColumn(columnName) {
    var measureName;
    var measureRegexp;
    var measureAggRegexp;

    if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN) &&
        !!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN)) {

      measureRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN);
      measureAggRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN);
      measureName = Saiku.replaceString(measureRegexp[0], '', columnName);
      measureName = Saiku.replaceString(measureAggRegexp[0], '', measureName);

      return measureName;
    }
    else if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN)) {
      measureRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN);
      measureName = Saiku.replaceString(measureRegexp[0], '', columnName);

      return measureName;
    }
    else {
      return columnName;
    }
  }

  function getMeasureAggregationColumn(columnName) {
    var agg = {
      '_sum': 'sum',
      '_avg': 'average',
      '_min': 'minimum',
      '_max': 'maximum',
      '_count': 'count',
      '_count_distinct': 'count-distinct'
    };
    var measureAggRegexp;

    if (!!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_COLUMN) &&
        !!columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN)) {

      measureAggRegexp = columnName.match(Settings.SCHEMA_EDITOR.STAR_SCHEMA_MEASURE_AGGREGATION_COLUMN);

      return agg[measureAggRegexp[0]];
    }
    else {
      return 'sum';
    }
  }

  SchemaEditorSchemaMock.prototype.schemaTable = function(data) {
    var mockTable = {
      id: data.id || _.uniqueId('id_table_'),
      name: data.name,
      sourceTable: data.name,
      keyColumn: data.attribute.length > 0 ? data.attribute[0] : '',
      linkTarget: '',
      linkTargetColumn: ''
    };

    return mockTable;
  };

  SchemaEditorSchemaMock.prototype.schemaMeasure = function(data, tableName) {
    var mockMeasure = {
      id: data.id || _.uniqueId('id_measure_'),
      name: capitalize(data.name || replaceMeasureAggregationColumn(data || _.uniqueId('measure_'))),
      properties: {
        sourceTable: data.sourceTable || tableName,
        sourceColumn: data.properties ? data.properties.sourceColumn : data,
        defaultAggregation: data.properties ? data.properties.defaultAggregation : getMeasureAggregationColumn(data)
      }
    };

    return mockMeasure;
  };

  SchemaEditorSchemaMock.prototype.schemaDimension = function(data, tableName) {
    var mockDimension = {
      dimension: {
        id: data.id || _.uniqueId('id_dimension_'),
        name: capitalize(data.name || data || _.uniqueId('dimension_')),
        key: data.key || '',
        factLinkColumn: data.factLinkColumn || '',
        properties: {
          sourceTable: data.sourceTable || tableName
        }
      }
    };

    mockDimension.attribute = this.schemaAttribute(data, tableName);

    return mockDimension;
  };

  SchemaEditorSchemaMock.prototype.schemaAttribute = function(data, sourceTable) {
    var mockAttribute = {
      id: data.id || _.uniqueId('id_attr_'),
      name: capitalize(data.name || data || _.uniqueId('attribute_')),
      sourceTable: data.sourceTable || sourceTable,
      sourceColumn: data.sourceColumn || data,
      visible: data.visible || true
    };

    return mockAttribute;
  };

  SchemaEditorSchemaMock.prototype.schemaHierarchy = function(data) {
    var mockHierarchy = {
      id: data.id,
      name: data.name
    };

    return mockHierarchy;
  };

  SchemaEditorSchemaMock.prototype.schemaLevel = function(data) {
    var mockLevel = {
      id: data.id,
      name: data.name,
      properties: {
        sourceTable: data.properties.sourceTable,
        sourceColumn: data.properties.sourceColumn || data.name,
        uniqueMember: data.properties.uniqueMember || false,
        ordinalTable: data.properties.ordinalTable,
        ordinalColumn: data.properties.ordinalColumn
      }
    };

    return mockLevel;
  };

  SchemaEditorSchemaMock.prototype.getSchema = function(data) {
    var self = this;
    var regexp = /Integer|INT|BIGINT|SMALLINT|DECIMAL|Double/i;
    var schema = {
      tables: [],
      measures: [],
      dimensions: []
    };
    var tableData = {
      name: '',
      attribute: []
    };

    _.each(data, function(table, tableName) {
      _.each(table, function(column) {
        if (!!column.type.match(regexp)) {
          schema.measures.push(self.schemaMeasure(column.name, tableName));
        }
        else {
          if (tableName.indexOf('agg_') !== 0) {
            schema.dimensions.push(self.schemaDimension(column.name, tableName));
          }
        }

        tableData.attribute.push(column.name);
      });

      tableData.name = tableName;

      schema.tables.push(self.schemaTable(tableData));
    });

    // console.log(schema);

    return schema;
  };

  return SchemaEditorSchemaMock;
}());
