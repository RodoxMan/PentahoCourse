/*
 *   Copyright 2018 OSBI Ltd
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

/**
 * Module Clear Session
 */
var clear = (function($, window, document, undefined) {

    // undefined is used here as the undefined global variable in ECMAScript 3 is
    // mutable (ie. it can be changed by someone else). undefined isn't really being
    // passed in so we can ensure the value of it is truly undefined. In ES5, undefined
    // can no longer be modified.

    // window and document are passed through as local variable rather than global
    // as this (slightly) quickens the resolution process and can be more efficiently
    // minified (especially when both are regularly referenced in your plugin).

    'use strict';

    var module = {
        _baseURL: window.location.origin + '/saiku/rest/saiku/session/clear',

        _notifyUser: function(alertType, msg) {
            $('#notification').removeClass();
            $('#notification').addClass(alertType);
            $('#notification').slideDown();
            module._setNotificationMessage(msg);
            setTimeout(function() {
                $('#notification').slideUp();
            }, 3000);
        },

        _setNotificationMessage: function(msg) {
            $('#notification p').text(msg);
        },

        _clearInputs: function() {
            $('#username, #password').val('');
        },

        _loading: function(isLoadBtn) {
            if (isLoadBtn) {
                $('#username, #password, .btn-clear').attr('disabled', 'disabled');
                $('.btn-clear').text('Clear session...');
            }
            else {
                $('#username, #password, .btn-clear').removeAttr('disabled');
                $('.btn-clear').text('Clear');
            }
        },

        _backLogin: function(isShow) {
            if (isShow) {
                $('.back-login').show();
                $('#btn-back-login').on('click', function() {
                    var url = window.location.origin;
                    window.open(url, '_self');
                });
            }
            else {
                $('.back-login').hide();
            }
        },

        _xhr: function(options, callback) {
            $.ajax({
                url: options.url,
                type: options.type,
                data: $.param(options.data),
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                success: function(data, status, jqXHR) {
                    module._clearInputs();
                    module._loading(false);
                    module._backLogin(true);
                    callback('alert-success', data);
                },
                error: function(jqXHR, status, errorThrown) {
                    module._clearInputs();
                    module._loading(false);
                    module._backLogin(false);
                    callback('alert-danger', jqXHR.responseText);
                }
            });
        },

        _clearSession: function() {
            var username = $('#username').val();
            var password = $('#password').val();

            module._loading(true);
            module._xhr({
                type: 'POST',
                url: module._baseURL,
                data: { 'username': username, 'password': password }
            }, module._notifyUser);
        },

        check: function() {
            $('body').on('keyup', function(event) {
                if (event.which === 13) {
                    module._clearSession();
                }
            });

            $('.btn-clear').on('click', function() {
                module._clearSession();
            });
        },

        init: function() {
            module.check();
        }
    };

    return {
        init: module.init
    };

}(jQuery, window, document));
